"""Validity said and read in HTTP (aimarket_hub/http_validity.py).

dawn@ietf.org, thread on draft-king-dawn-requirements-02 (2026-11-26): Riccardo Di Nuzzo asked for
discovery documents to state their validity with Cache-Control and ETag. The hub's signed catalogue
and both discovery documents sent neither. They now carry max-age, stale-if-error (= the period
this hub keeps other hubs' entries after a failed read) and a weak ETag that survives re-signing,
and answer If-None-Match with 304. The crawler reads a peer's Cache-Control and serves the peer's
rows no longer than the peer says, when that is shorter than its own bound.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi.testclient import TestClient

from aimarket_hub import http_validity
from aimarket_hub.api import create_app
from aimarket_hub.config import HubConfig
from aimarket_hub.crawler import Crawler
from aimarket_hub.database import HubDatabase, serve_until_for
from aimarket_hub.models import Capability, Peer
from aimarket_hub.signing import Signer


@pytest.mark.parametrize(("header", "expected"), [
    (None, None),
    ("", None),
    ("public", None),
    ("public, max-age=300", 300),
    ("public, max-age=300, stale-if-error=172800", 172_800 + 300),
    ("stale-if-error=600", 600),
    ('max-age="120"', 120),
    ("no-store", 0),
    ("no-cache, private", 0),
    ("max-age=abc, public", None),
])
def test_a_peers_cache_control_reads_as_a_period(header, expected):
    assert http_validity.stated_period(header) == expected


def test_serve_until_only_shortens_and_never_below_two_crawls(monkeypatch):
    monkeypatch.delenv("AIMARKET_FEDERATED_MAX_UNVERIFIED_S", raising=False)
    assert serve_until_for(None, 3600) is None                      # stated nothing: the hub's 48 h
    assert serve_until_for(7 * 86400, 3600) is None                 # longer than 48 h: the hub's 48 h
    assert serve_until_for(172_800, 3600) is None                   # equal: the hub's 48 h
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    short = datetime.strptime(serve_until_for(3 * 3600, 3600), "%Y-%m-%d %H:%M:%S")
    assert 3 * 3600 - 5 <= (short - now).total_seconds() <= 3 * 3600 + 5
    floor = datetime.strptime(serve_until_for(0, 3600), "%Y-%m-%d %H:%M:%S")
    assert 2 * 3600 - 5 <= (floor - now).total_seconds() <= 2 * 3600 + 5   # no-store: two crawls
    monkeypatch.setenv("AIMARKET_FEDERATED_MAX_UNVERIFIED_S", "0")
    assert serve_until_for(60, 3600) is None                        # bound off: nothing applies


@pytest.fixture
def hub(tmp_path, monkeypatch):
    monkeypatch.setenv("AIMARKET_AUTO_CRAWL", "0")
    monkeypatch.setenv("AIMARKET_FEDERATION_ASSAY", "0")
    monkeypatch.delenv("AIMARKET_FEDERATED_MAX_UNVERIFIED_S", raising=False)
    config = HubConfig()
    config.hub_url = "https://our-hub.example"
    config.db_path = str(tmp_path / "hub.db")
    config.signing_key_path = str(tmp_path / "hub.key")
    db = HubDatabase(config.db_path)
    db.upsert_capability(Capability(capability_id="weather@v1", product_id="weather", name="Weather",
                                    description="Weather for a city", price_per_call_usd=0.01,
                                    invoke_url="https://provider.example/invoke"))
    with TestClient(create_app(config=config, db=db, signer=Signer(config.signing_key_path))) as client:
        yield client, db


def test_the_signed_catalogue_states_its_validity_and_answers_304(hub):
    client, db = hub
    first = client.get("/ai-market/v2/manifest")
    assert first.status_code == 200
    etag = first.headers["etag"]
    assert etag.startswith('W/"')
    assert first.headers["cache-control"] == "public, max-age=300, stale-if-error=172800"
    assert any(t["name"] for t in first.json()["tools"])

    # Re-signed with a new generation time, same catalogue: same ETag, and 304 for a reader that has it.
    again = client.get("/ai-market/v2/manifest", headers={"If-None-Match": etag})
    assert again.status_code == 304 and again.content == b""
    assert again.headers["etag"] == etag and "stale-if-error=172800" in again.headers["cache-control"]
    assert client.get("/ai-market/v2/manifest", headers={"If-None-Match": '"other", ' + etag}).status_code == 304

    # Something new for sale: a different ETag, and the old one gets the full body.
    db.upsert_capability(Capability(capability_id="tides@v1", product_id="tides", name="Tides",
                                    description="Tide table", price_per_call_usd=0.02,
                                    invoke_url="https://provider.example/tides"))
    changed = client.get("/ai-market/v2/manifest", headers={"If-None-Match": etag})
    assert changed.status_code == 200 and changed.headers["etag"] != etag
    assert {t["name"] for t in changed.json()["tools"]} >= {t["name"] for t in first.json()["tools"]}


@pytest.mark.parametrize("path", ["/.well-known/ai-market.json", "/.well-known/agent-marketplace"])
def test_both_discovery_documents_state_their_validity_and_answer_304(hub, path):
    client, _db = hub
    first = client.get(path)
    assert first.status_code == 200 and first.json().get("generated_at")
    etag = first.headers["etag"]
    assert etag.startswith('W/"')
    assert first.headers["cache-control"] == "public, max-age=60, stale-if-error=172800"
    assert client.get(path, headers={"If-None-Match": etag}).status_code == 304
    assert client.get(path, headers={"If-None-Match": "*"}).status_code == 304
    assert client.head(path).headers["etag"] == etag


def test_stale_if_error_follows_the_federated_bound(tmp_path, monkeypatch):
    monkeypatch.setenv("AIMARKET_AUTO_CRAWL", "0")
    monkeypatch.setenv("AIMARKET_FEDERATED_MAX_UNVERIFIED_S", "0")
    config = HubConfig()
    config.hub_url = "https://our-hub.example"
    config.db_path = str(tmp_path / "hub.db")
    config.signing_key_path = str(tmp_path / "hub.key")
    with TestClient(create_app(config=config, db=HubDatabase(config.db_path),
                               signer=Signer(config.signing_key_path))) as client:
        assert client.get("/ai-market/v2/manifest").headers["cache-control"] == "public, max-age=300"


def _crawl_peer(tmp_path, monkeypatch, cache_control):
    """Crawl one peer whose manifest answers with ``cache_control``; return (db, peer_url)."""
    monkeypatch.setattr("aimarket_hub.crawler._url_is_safe", lambda url: url.startswith("https://"))
    monkeypatch.delenv("AIMARKET_FEDERATED_MAX_UNVERIFIED_S", raising=False)
    config = HubConfig()
    config.hub_url = "https://our-hub.example"
    config.db_path = str(tmp_path / "hub.db")
    config.signing_key_path = str(tmp_path / "hub.key")
    config.crawl_interval_s = 3600
    peer_url = "https://peer.example"
    peer_signer = Signer(tmp_path / "peer.key")
    db = HubDatabase(config.db_path)
    db.upsert_peer(Peer(url=peer_url, name="Peer", public_key=peer_signer.public_key_b64, trusted=True))
    wk = {"name": "Peer", "protocol_versions": ["v1", "v2"], "manifest_url": peer_url + "/manifest",
          "capabilities_count": 1, "signer_public_key": peer_signer.public_key_b64}
    manifest = {"protocol_version": "v2", "generated_at": datetime.now(timezone.utc).isoformat(),
                "capabilities_count": 1,
                "tools": [{"name": "weather", "capability_id": "weather@v1", "product_id": "weather",
                           "description": "Weather", "input_schema": {}, "price_per_call_usd": 0.003}]}
    manifest["signature"] = peer_signer.sign_manifest(manifest)
    crawler = Crawler(config=config, db=db, signer=Signer(config.signing_key_path))

    async def get(url):
        if ".well-known/" in url:
            return httpx.Response(200, json=wk)
        return httpx.Response(200, json=manifest, headers={"Cache-Control": cache_control} if cache_control else {})

    crawler._safe_get = AsyncMock(side_effect=get)
    assert asyncio.run(crawler._crawl_one(peer_url + "/.well-known/ai-market.json", 0, "test"))["capabilities_count"] == 1
    return db, peer_url


def _row(db, peer_url):
    return db.get_capability("weather", "weather@v1", peer_url, include_unverified=True)


def test_a_peer_that_states_a_short_validity_is_served_no_longer(tmp_path, monkeypatch):
    db, peer = _crawl_peer(tmp_path, monkeypatch, "public, max-age=600, stale-if-error=10200")  # 3 h
    row = _row(db, peer)
    assert row.serve_until and row.catalogue_evidence["stated_validity_s"] == 10_800
    assert db.get_capability("weather", "weather@v1", peer) is not None

    # Four hours later, no verified read since: past the peer's 3 h, inside the hub's 48 h.
    db._conn.execute("UPDATE capabilities SET serve_until = datetime('now', '-1 hours'), "
                     "updated_at = datetime('now', '-4 hours') WHERE source_hub = ?", (peer,))
    db._conn.commit()
    assert db.get_capability("weather", "weather@v1", peer) is None
    assert db.count_federated() == 0 and db.count_offerable(source_hub=peer) == 0
    assert db.expire_unverified_federated() == 1
    assert _row(db, peer) is None


@pytest.mark.parametrize("header", [None, "public, max-age=604800", "public, max-age=300, stale-if-error=259200"])
def test_a_peer_that_states_nothing_or_longer_keeps_the_hubs_own_bound(tmp_path, monkeypatch, header):
    db, peer = _crawl_peer(tmp_path, monkeypatch, header)
    row = _row(db, peer)
    assert row.serve_until is None
    assert ("stated_validity_s" in row.catalogue_evidence) == (header is not None)


def test_no_store_keeps_rows_for_two_crawl_intervals(tmp_path, monkeypatch):
    db, peer = _crawl_peer(tmp_path, monkeypatch, "no-store")
    until = datetime.strptime(_row(db, peer).serve_until, "%Y-%m-%d %H:%M:%S")
    left = (until - datetime.now(timezone.utc).replace(tzinfo=None)).total_seconds()
    assert 2 * 3600 - 10 <= left <= 2 * 3600 + 10
