"""Transparency, part C: how each feed answers public disputes of its records.

A dispute is an issue in the feed's public tracker, filed 2025-01-01 to 2026-10-27, that says a record
is wrong: the package is not malicious, the versions or the package are wrong, or the record should be
withdrawn to match its source. The analyst's reading of every candidate issue is data below
(DISPUTES; an issue not listed is not a dispute). For each dispute: the tools the disputed records
credit (from the pinned stage 1 records), the first answer by the feed (its maintainers, or the
operator of a tool the record credits), and the outcome:
  changed          the record was withdrawn or corrected (said in the thread, or the pinned
                   snapshot shows it withdrawn or its versions narrowed);
  kept             the feed answered that the record stands, with a reason;
  referred         the feed sent the reporter elsewhere (for npm malware, to npm support);
  closed_silent    the feed closed the issue without a word, and the change cannot be confirmed;
  reporter_closed  the reporter closed it before any answer;
  open             no outcome yet.
An answer is the first comment by the feed, or a close by the feed when it comes first.

    python3 disputes_measure.py ISSUES_DIR RECORDS_OV OUT_ROWS.jsonl OUT_SUMMARY.json
"""
import json
import re
import statistics
import sys
from collections import defaultdict
from datetime import datetime

T, RECORDS, OUT_ROWS, OUT_SUM = sys.argv[1:5]
END = "2026-10-27T23:59:59Z"

# The feed's own people per tracker; a tool's operator counts when the disputed record credits the tool.
MAINTAINERS = {
    "ossf/malicious-packages": {"calebbrown", "jeffmendoza", "6mile", "elitsa-gosst"},
    "github/advisory-database": {"taladrane", "shelbyc", "JonathanLEvans"},
    "Vulnetix/advisory-database": {"0x73746F66"},
}
OPERATORS = {"amazon-inspector": {"awsactran", "inspector-research"}, "kam193": {"kam193"}}

# The contributor of the disputed report answered for it (it credits no tool by name).
EXTRA_RESPONDERS = {("ossf/malicious-packages", 1667): {"vitaliichepurko-ox"}}
# Disputes without a record id in the text: the tools their packages' records credit.
TOOLS_BY_NAME = {("ossf/malicious-packages", 1173): ["amazon-inspector"],  # @schedaero/*
                 ("ossf/malicious-packages", 1116): ["unknown"],  # @healthbyro/design-tokens
                 ("ossf/malicious-packages", 1104): ["kam193", "reversing-labs"],  # anaconda-anon-usage
                 ("ossf/malicious-packages", 1039): ["ghsa-malware"]}  # @nexthink/*

# number -> outcome, per tracker (analyst's reading of title, body and thread); not listed = not a dispute
DISPUTES = {
    "ossf/malicious-packages": {
        1667: "open", 1560: "open", 1558: "open", 1537: "open", 1474: "open", 1471: "changed", 1470: "open",
        1449: "changed", 1448: "changed", 1445: "changed", 1442: "changed", 1430: "changed",
        1429: "closed_silent", 1406: "changed", 1390: "open", 1379: "changed", 1338: "changed", 1337: "changed",
        1324: "changed", 1311: "kept", 1308: "changed", 1298: "changed", 1297: "changed", 1280: "changed",
        1274: "changed", 1254: "changed", 1252: "changed", 1173: "open", 1171: "changed", 1153: "changed",
        1138: "open", 1130: "open", 1122: "kept", 1116: "open", 1115: "open", 1104: "changed", 1099: "changed",
        1039: "kept", 1036: "kept", 934: "kept", 912: "kept", 799: "changed", 798: "open", 752: "changed",
        1668: "open"},
    "github/advisory-database": {
        10534: "open", 10518: "open", 9654: "open", 9600: "open", 9373: "open", 9268: "open", 9256: "open",
        9255: "open", 9164: "open", 8871: "changed", 8859: "changed", 7896: "changed", 7878: "changed",
        7858: "changed", 7857: "changed", 7813: "changed", 7742: "changed", 7684: "changed", 7653: "changed",
        7495: "kept", 7436: "changed", 7377: "kept", 7284: "kept", 7118: "referred", 6993: "changed",
        6842: "changed", 6824: "kept", 6734: "referred", 6728: "referred", 6580: "kept", 6578: "referred",
        6556: "referred", 6564: "referred", 6533: "changed", 6259: "kept", 6140: "changed", 6132: "changed",
        6122: "changed", 6100: "changed", 6099: "changed", 6098: "changed", 5973: "changed", 5857: "changed",
        5846: "changed", 5736: "changed", 5478: "referred", 5404: "reporter_closed", 5342: "changed",
        5248: "changed"},
    "Vulnetix/advisory-database": {
        8: "changed", 7: "changed", 6: "changed", 5: "changed", 4: "changed", 3: "changed", 2: "changed",
        1: "changed"},
}
# (repo, number) -> the issue it repeats (same reporter or a closed duplicate); counted once
DUPLICATES = {("ossf/malicious-packages", 1668): 1667, ("github/advisory-database", 6564): 6556}
# Notes the table needs
NOTES = {("github/advisory-database", 8871): "advisory withdrawn (said in ossf/malicious-packages#1406, 2026-08-03); never answered here",
         ("github/advisory-database", 8859): "advisory withdrawn (said in ossf/malicious-packages#1406, 2026-08-03); never answered here",
         ("Vulnetix/advisory-database", 5): "filed by this study's owner about our own packages"}


def ts(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")


def days(a, b):
    return round((ts(b) - ts(a)).total_seconds() / 86400, 2)


by_id, by_name = {}, defaultdict(set)
for line in open(RECORDS, encoding="utf-8"):
    r = json.loads(line)
    srcs = r["sources"] or ["unknown"]
    by_id[r["id"]] = srcs
    by_name[(r["ecosystem"], r["name"].lower())].update(srcs)

rows = []
for repo, outcomes in DISPUTES.items():
    issues = {}
    for line in open(f"{T}/{repo.replace('/', '_')}.json.jsonl", encoding="utf-8"):
        r = json.loads(line)
        issues[r["number"]] = r
    for num, outcome in sorted(outcomes.items()):
        if (repo, num) in DUPLICATES:
            continue
        r = issues[num]
        k = f"{repo.replace('/', '_')}_{num}"
        comments = json.load(open(f"{T}/comments/{k}.json", encoding="utf-8"))
        text = (r["title"] or "") + "\n" + (r["body"] or "")
        tools = set()
        if repo == "ossf/malicious-packages":
            for mid in set(re.findall(r"MAL-\d{4}-\d+", text)):
                tools.update(by_id.get(mid, []))
            if not tools and re.search(r"GHSA-\w{4}-\w{4}-\w{4}", text):
                tools.add("ghsa-malware")
            tools.update(TOOLS_BY_NAME.get((repo, num), []))
        elif repo == "github/advisory-database":
            tools.add("ghsa-malware")
        else:
            tools.add("vulnetix")
        feed_people = set(MAINTAINERS[repo])
        for t in tools:
            feed_people |= OPERATORS.get(t, set())
        feed_people |= EXTRA_RESPONDERS.get((repo, num), set())
        first = next((c for c in comments if c["user"]["login"] in feed_people
                      and c["user"]["login"] != r["user"]["login"] and c["created_at"] <= END), None)
        events = json.load(open(f"{T}/events/{k}.json", encoding="utf-8"))
        feed_close = next((e["created_at"] for e in events if e["event"] == "closed" and e.get("actor")
                           and e["actor"]["login"] in feed_people and e["created_at"] <= END), None)
        answers = [x for x in (first["created_at"] if first else None, feed_close) if x]
        answered_at = min(answers) if answers else None
        rows.append({
            "repo": repo, "number": num, "created": r["created_at"], "author": r["user"]["login"],
            "title": r["title"], "tools": sorted(tools) or ["unattributed"], "outcome": outcome,
            "first_answer": answered_at, "first_answer_by": first["user"]["login"] if first else None,
            "days_to_answer": days(r["created_at"], answered_at) if answered_at else None,
            "closed": r.get("closed_at"),
            "days_to_outcome": days(r["created_at"], r["closed_at"]) if outcome == "changed" and r.get("closed_at") else None,
            "note": NOTES.get((repo, num)),
            "age_days_if_open": days(r["created_at"], END) if outcome == "open" else None,
        })

with open(OUT_ROWS, "w", encoding="utf-8") as fo:
    for x in rows:
        fo.write(json.dumps(x, ensure_ascii=False) + "\n")


def summarise(xs):
    ans = [x["days_to_answer"] for x in xs if x["days_to_answer"] is not None]
    done = [x["days_to_outcome"] for x in xs if x["outcome"] == "changed" and x["days_to_outcome"] is not None]
    return {
        "disputes": len(xs),
        "answered": len(ans),
        "median_days_to_answer": round(statistics.median(ans), 1) if ans else None,
        **{o: sum(x["outcome"] == o for x in xs)
           for o in ("changed", "kept", "referred", "closed_silent", "reporter_closed", "open")},
        "open_unanswered": sum(x["outcome"] == "open" and x["days_to_answer"] is None for x in xs),
        "median_days_to_change": round(statistics.median(done), 1) if done else None,
    }


summary = {"per_feed": {}, "per_tool_ossf": {}}
for repo in DISPUTES:
    summary["per_feed"][repo] = summarise([x for x in rows if x["repo"] == repo])
tools = sorted({t for x in rows if x["repo"] == "ossf/malicious-packages" for t in x["tools"]})
for t in tools:
    summary["per_tool_ossf"][t] = summarise([x for x in rows if x["repo"] == "ossf/malicious-packages" and t in x["tools"]])
json.dump(summary, open(OUT_SUM, "w"), indent=1)
print(json.dumps(summary, indent=1))
