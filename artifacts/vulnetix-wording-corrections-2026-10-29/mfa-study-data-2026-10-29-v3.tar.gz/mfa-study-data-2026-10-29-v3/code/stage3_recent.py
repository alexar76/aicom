#!/usr/bin/env python3
"""Stage 3 benign set B: random recent uploads (metadata only), as METHODOLOGY.md fixes it.

Packages with a release published in [WINDOW_START, WINDOW_END), drawn at random, that no feed in
the study lists. PyPI: the XML-RPC changelog since a serial before the window, "new release" rows
in the window, one release per project at random. npm: the replication feed's sequence numbers
bracketing the window are found by bisection on the change's publish time; random sequence numbers
in that range are drawn and a package is kept when a version of it was published in the window.

    python3 -I stage3_recent.py records.jsonl [records_ghsa.jsonl ...] --n 200 --seed 20261027 > recent.json
"""

from __future__ import annotations

import argparse
import json
import random
import socket
import sys
import urllib.parse
import urllib.request
import xmlrpc.client
from datetime import datetime, timezone

WINDOW_START = datetime(2026, 10, 10, tzinfo=timezone.utc)
WINDOW_END = datetime(2026, 10, 17, tzinfo=timezone.utc)
UA = {"User-Agent": "malware-feed-accuracy-study/1.0 (+https://modelmarket.dev; metadata only)"}


def get(url: str):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as resp:
        return json.loads(resp.read())


def pypi_recent(flagged: set, n: int, rng: random.Random) -> tuple[list[dict], int]:
    socket.setdefaulttimeout(300)
    rpc = xmlrpc.client.ServerProxy("https://pypi.org/pypi")
    last = rpc.changelog_last_serial()
    # ~38k serials a day (measured 2026-10-24); start well before the window and filter by time.
    days_back = (datetime.now(timezone.utc) - WINDOW_START).total_seconds() / 86400 + 2
    lo, hi = WINDOW_START.timestamp(), WINDOW_END.timestamp()
    # One call returns at most 50,000 rows (oldest first), so page from the last serial seen
    # until the rows pass the window's end.
    rows, since = [], int(last - days_back * 40_000)
    while True:
        page = rpc.changelog_since_serial(since)
        if not page:
            break
        rows.extend(page)
        since = page[-1][4]
        if page[-1][2] >= hi or len(page) < 50_000:
            break
    if not rows or rows[0][2] > lo or rows[-1][2] < hi:
        raise SystemExit("PyPI changelog does not cover the whole window; widen days_back")
    releases: dict[str, list[str]] = {}
    for name, version, ts, action, _serial in rows:
        if lo <= ts < hi and action == "new release" and version:
            releases.setdefault(name, []).append(version)
    names = sorted(k for k in releases if ("pypi", k.lower()) not in flagged)
    picked = rng.sample(names, min(n, len(names)))
    return [{"ecosystem": "pypi", "name": k, "version": rng.choice(sorted(releases[k]))} for k in picked], len(names)


def npm_change(seq: int):
    doc = get(f"https://replicate.npmjs.com/registry/_changes?since={seq}&limit=1")
    res = doc.get("results") or []
    return (res[0]["id"], res[0]["seq"]) if res else (None, None)


def npm_versions_in_window(name: str) -> list[str]:
    try:
        doc = get("https://registry.npmjs.org/" + urllib.parse.quote(name, safe="@"))
    except Exception:  # noqa: BLE001 - unpublished or unreadable: not a candidate
        return []
    out = []
    for version, ts in (doc.get("time") or {}).items():
        if version in ("created", "modified") or version not in (doc.get("versions") or {}):
            continue
        t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        if WINDOW_START <= t < WINDOW_END:
            out.append(version)
    return out


def npm_seq_at(target: datetime, lo: int, hi: int) -> int:
    """Bisection on sequence number: the change's package 'modified' time against the target."""
    for _ in range(30):
        if hi - lo < 2000:
            break
        mid = (lo + hi) // 2
        name, _ = npm_change(mid)
        try:
            modified = get("https://registry.npmjs.org/" + urllib.parse.quote(name, safe="@"))["time"]["modified"]
            t = datetime.fromisoformat(modified.replace("Z", "+00:00"))
        except Exception:  # noqa: BLE001
            lo = mid  # skip unreadable; move on
            continue
        if t < target:
            lo = mid
        else:
            hi = mid
    return lo


def npm_recent(flagged: set, n: int, rng: random.Random) -> tuple[list[dict], int]:
    last = get("https://replicate.npmjs.com/registry/_changes?limit=1&descending=true")["last_seq"]
    a = npm_seq_at(WINDOW_START, last - 6_000_000, last)
    b = npm_seq_at(WINDOW_END, a, last)
    out, seen, tries = [], set(), 0
    while len(out) < n and tries < n * 40:
        tries += 1
        name, _ = npm_change(rng.randrange(a, b))
        if not name or name in seen or ("npm", name.lower()) in flagged:
            continue
        seen.add(name)
        versions = npm_versions_in_window(name)
        if versions:
            out.append({"ecosystem": "npm", "name": name, "version": rng.choice(sorted(versions))})
    return out, tries


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("records", nargs="+")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20261027)
    ap.add_argument("--window-start", help="YYYY-MM-DD (default: run 1's window, 2026-10-10)")
    ap.add_argument("--window-end", help="YYYY-MM-DD, exclusive (default: 2026-10-17)")
    args = ap.parse_args()
    global WINDOW_START, WINDOW_END
    if args.window_start:
        WINDOW_START = datetime.fromisoformat(args.window_start).replace(tzinfo=timezone.utc)
    if args.window_end:
        WINDOW_END = datetime.fromisoformat(args.window_end).replace(tzinfo=timezone.utc)
    flagged = set()
    for path in args.records:
        for line in open(path):
            r = json.loads(line)
            flagged.add((r["ecosystem"], r["name"].lower()))
    rng = random.Random(args.seed)
    pypi, pypi_pool = pypi_recent(flagged, args.n, rng)
    npm, npm_tries = npm_recent(flagged, args.n, rng)
    json.dump({"window": [WINDOW_START.isoformat(), WINDOW_END.isoformat()], "pypi_pool": pypi_pool,
               "npm_draws": npm_tries, "packages": pypi + npm}, sys.stdout, indent=1)
    print(f"pypi {len(pypi)} of {pypi_pool}; npm {len(npm)} in {npm_tries} draws", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
