#!/usr/bin/env python3
"""Stage 2 adjudication: a reading digest of each whole unpacked package (no network, no execution).

For the adjudicator, not the raters: the file list; every install-time hook in full; every line
that matches a risky pattern, with three lines of context, across ALL files; and the full text of
small packages. Nothing about feeds or tools. Runs on the sandbox host.

    python3 stage2_digest.py ROOT_DIR OUT_DIR < manifest.jsonl
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from stage2_bundle import HOOK_NAMES, RISKY, is_text  # noqa: E402

SMALL = 40_000      # whole text of a package this small is included
HITS_CAP = 400      # matched lines per package
LINE_CAP = 300


def digest(root: Path) -> str:
    files = sorted(p for p in root.rglob("*") if p.is_file())
    rel = lambda p: str(p.relative_to(root))  # noqa: E731
    out = [f"FILES ({len(files)}):"] + [f"  {rel(p)} ({p.stat().st_size} B)" for p in files[:300]]
    texts = {p: p.read_text(errors="replace") for p in files if is_text(p)}
    total = sum(len(t) for t in texts.values())
    out.append("\nINSTALL HOOKS AND ENTRY FILES:")
    for p, t in texts.items():
        if p.name in HOOK_NAMES or p.suffix == ".pth":
            if p.name == "package.json":
                try:
                    scripts = json.loads(t).get("scripts") or {}
                except ValueError:
                    scripts = {}
                out.append(f"--- {rel(p)} scripts: {json.dumps(scripts)[:1500]}")
            else:
                out.append(f"--- {rel(p)}\n" + "\n".join(l[:LINE_CAP] for l in t.splitlines()[:250]))
    if total <= SMALL:
        out.append(f"\nFULL TEXT (package is {total} chars):")
        for p, t in texts.items():
            out.append(f"--- {rel(p)}\n" + "\n".join(l[:LINE_CAP] for l in t.splitlines()))
        return "\n".join(out)
    out.append(f"\nRISKY LINES WITH CONTEXT (package is {total} chars):")
    hits = 0
    for p, t in texts.items():
        lines = t.splitlines()
        marks = [i for i, l in enumerate(lines) if RISKY.search(l)]
        if not marks:
            continue
        out.append(f"--- {rel(p)} ({len(marks)} matches)")
        shown = set()
        for i in marks:
            for j in range(max(0, i - 3), min(len(lines), i + 4)):
                if j not in shown:
                    shown.add(j)
                    out.append(f"{j + 1:>5}: {lines[j][:LINE_CAP]}")
            hits += 1
            if hits >= HITS_CAP:
                out.append("…[match cap reached]")
                return "\n".join(out)
    return "\n".join(out)


def main() -> int:
    root, out_dir = Path(sys.argv[1]), Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)
    for line in sys.stdin:
        row = json.loads(line)
        if row.get("error"):
            continue
        (out_dir / f"{row['key']}.txt").write_text(digest(root / row["key"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
