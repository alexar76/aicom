#!/usr/bin/env python3
"""Stage 1 numbers, as METHODOLOGY.md defines them, from normalize.py and registry_check.py output.

    python3 -I analyze.py records.jsonl status.jsonl [--json summary.json] > results.md

Questions 1, 3 and 4 use every record; question 2 uses the stratified sample, per stratum with a
Wilson 95% interval, and stratum-weighted totals. Prints Markdown tables.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

ACTED = {"removed", "placeholder", "quarantined", "versions_gone"}
AGES = ((0, 7, "< 7 d"), (7, 30, "7–30 d"), (30, 180, "30–180 d"), (180, 10**6, "> 180 d"))


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float, float]:
    if n == 0:
        return (float("nan"),) * 3
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, max(0.0, c - h), min(1.0, c + h)


def pct(p: float) -> str:
    return "—" if p != p else f"{100 * p:.1f}%"


def ci(k: int, n: int) -> str:
    p, lo, hi = wilson(k, n)
    return f"{pct(p)} ({pct(lo)}–{pct(hi)})"


def parse(ts: str | None) -> datetime | None:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        return None


def age_bucket(published: str | None, checked: str) -> str:
    a, b = parse(published), parse(checked)
    if not a or not b:
        return "unknown"
    days = (b - a).total_seconds() / 86400
    return next(label for lo, hi, label in AGES if lo <= days < hi)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("records")
    ap.add_argument("status")
    ap.add_argument("--json")
    args = ap.parse_args()
    records = [json.loads(line) for line in open(args.records)]
    status = [json.loads(line) for line in open(args.status)]
    # The flag's date comes from the record as normalize.py reads it now, not from the copy the
    # status row carries (a status file drawn before a normalize.py fix keeps its old dates).
    published = {(r["feed"], r["id"], r["name"]): r["published"] for r in records}
    for s in status:
        s["published"] = published.get((s["feed"], s["id"], s["name"]), s.get("published"))
    out: dict = {}
    w = sys.stdout.write

    # Q1 kinds, Q3 withdrawals: all records, per feed, source and ecosystem.
    per = defaultdict(Counter)
    for r in records:
        for s in r["sources"]:
            key = (r["feed"], s, r["ecosystem"])
            per[key]["records"] += 1
            per[key][r.get("kind", "malicious")] += 1
            per[key]["withdrawn"] += bool(r["withdrawn"])
    w("## Records per detecting tool: kinds and withdrawals (all records)\n\n")
    w("| Feed | Tool | Ecosystem | Records | Malicious | Spam | Research | Static rule | Withdrawn by the feed |\n")
    w("|---|---|---|---:|---:|---:|---:|---:|---:|\n")
    for key in sorted(per, key=lambda k: -per[k]["records"]):
        c = per[key]
        n = c["records"]
        w(f"| {key[0]} | {key[1]} | {key[2]} | {n:,} | {pct(c['malicious'] / n)} | {pct(c['spam'] / n)} | "
          f"{pct(c['research'] / n)} | {pct(c['static-rule'] / n)} | {c['withdrawn']:,} ({pct(c['withdrawn'] / n)}) |\n")
    out["records"] = {"|".join(k): dict(v) for k, v in per.items()}

    # Q2 registry status: sample, per stratum, with age.
    strata = defaultdict(list)
    for s in status:
        strata[(s["feed"], s["source"], s["ecosystem"], s["kind"])].append(s)
    w("\n## Registry status today (stratified sample)\n\n")
    w("| Feed | Tool | Ecosystem | Kind | Stratum | Sampled | Registry acted (95% CI) | Removed | Placeholder | Versions gone | Live | Errors |\n")
    w("|---|---|---|---|---:|---:|---|---:|---:|---:|---:|---:|\n")
    q2 = {}
    for key in sorted(strata, key=lambda k: (k[2], k[0], k[1], k[3])):
        rows = [r for r in strata[key] if r["status"] != "error"]
        errs = len(strata[key]) - len(rows)
        c = Counter(r["status"] for r in rows)
        acted = sum(c[s] for s in ACTED)
        n = len(rows)
        size = strata[key][0]["stratum_size"]
        w(f"| {key[0]} | {key[1]} | {key[2]} | {key[3]} | {size:,} | {n} | {ci(acted, n)} | {c['removed']} | "
          f"{c['placeholder']} | {c['versions_gone']} | {c['live']} | {errs} |\n")
        q2["|".join(key)] = {"size": size, "n": n, "acted": acted, "errors": errs, **c}
    out["registry"] = q2

    w("\n### Registry acted, by age of the flag (stratified sample)\n\n")
    w("| Feed | Tool | Ecosystem | Kind | " + " | ".join(l for *_, l in AGES) + " |\n|---|---|---|---|" + "---|" * len(AGES) + "\n")
    for key in sorted(strata, key=lambda k: (k[2], k[0], k[1], k[3])):
        by = defaultdict(list)
        for r in strata[key]:
            if r["status"] != "error":
                by[age_bucket(r.get("published"), r["checked_at"])].append(r["status"] in ACTED)
        cells = []
        for *_, label in AGES:
            v = by.get(label, [])
            cells.append(f"{ci(sum(v), len(v))} n={len(v)}" if v else "—")
        w(f"| {key[0]} | {key[1]} | {key[2]} | {key[3]} | " + " | ".join(cells) + " |\n")

    # Weighted totals per ecosystem and kind.
    w("\n### Stratum-weighted share of flags the registry acted on\n\n| Ecosystem | Kind | Weighted share | Records covered |\n|---|---|---:|---:|\n")
    tot = defaultdict(lambda: [0.0, 0])
    for key, v in q2.items():
        feed, src, eco, kind = key.split("|")
        if v["n"]:
            tot[(eco, kind)][0] += v["size"] * v["acted"] / v["n"]
            tot[(eco, kind)][1] += v["size"]
    for (eco, kind), (acted, size) in sorted(tot.items()):
        w(f"| {eco} | {kind} | {pct(acted / size)} | {size:,} |\n")

    # Q4 agreement: package level, any other tool (any feed) flagging the same package.
    tools_per_pkg = defaultdict(set)
    for r in records:
        for s in r["sources"]:
            tools_per_pkg[(r["ecosystem"], r["name"].lower())].add(f"{r['feed']}:{s}")
    agree = defaultdict(lambda: [0, 0])
    for (eco, _), tools in tools_per_pkg.items():
        for t in tools:
            agree[(t, eco)][1] += 1
            agree[(t, eco)][0] += len(tools) > 1
    w("\n## Agreement: packages a tool flags that another tool also flags (all records)\n\n| Tool | Ecosystem | Packages | Also flagged by another tool |\n|---|---|---:|---:|\n")
    for (t, eco), (k, n) in sorted(agree.items(), key=lambda x: -x[1][1]):
        w(f"| {t} | {eco} | {n:,} | {pct(k / n)} |\n")
    out["agreement"] = {f"{t}|{e}": v for (t, e), v in agree.items()}

    # Vulnetix matched rules.
    rules = Counter(m for r in records if r["feed"] == "vulnetix" for m in r.get("matched") or [])
    if rules:
        total = sum(rules.values())
        w("\n## Vulnetix: rules behind its own malware records (all records)\n\n| Rule | Matches | Share |\n|---|---:|---:|\n")
        for rule, n in rules.most_common(25):
            w(f"| `{rule}` | {n:,} | {pct(n / total)} |\n")
        out["vulnetix_rules"] = dict(rules)

    if args.json:
        with open(args.json, "w") as fh:
            json.dump(out, fh, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
