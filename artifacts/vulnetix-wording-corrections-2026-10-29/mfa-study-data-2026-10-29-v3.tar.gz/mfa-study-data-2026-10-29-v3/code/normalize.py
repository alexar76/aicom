#!/usr/bin/env python3
"""Stage 1 of the malware-feed accuracy study: one row per (feed record, package).

Reads three public sources, already on disk (see README.md), and writes JSONL rows:

    {"feed": "ossf", "id": "MAL-2024-4720", "ecosystem": "pypi", "name": "...", "published": "...",
     "withdrawn": false, "sources": ["reversing-labs"], "versions": ["1.0.0"] | "all",
     "aliases": [...], "matched": [...]}

feed is the database a record comes from; sources are the detecting tools a record credits
(OpenSSF's malicious-packages-origins, GHSA credits, or the feed itself). Only metadata is read:
no package is downloaded, installed or run. Run with python3 -I.

    python3 -I normalize.py --ossf DIR --vulnetix DIR --ghsa DIR > records.jsonl
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ECOSYSTEMS = {"npm": "npm", "pypi": "pypi", "PyPI": "pypi", "NPM": "npm", "PYPI": "pypi", "pip": "pypi"}

# What a record says it found, from its own text. Feeds file token-farming spam and security-research
# probes under "Malicious code in …" too; the study counts them apart instead of calling either right
# or wrong. First match wins; anything else is "malicious".
KINDS = (
    ("spam", ("tea.xyz", "token reward", "token farming", "spam package", "spam packages", "autopublish")),
    ("research", ("security research", "bug bounty", "proof of concept", "proof-of-concept", "dependency confusion",
                  "pentest", "penetration test", "red team")),
)


def kind_of(text: str) -> str:
    low = (text or "").lower()
    for kind, words in KINDS:
        if any(w in low for w in words):
            return kind
    return "malicious"


def _versions(affected: dict) -> list[str] | str:
    if affected.get("versions"):
        return sorted(set(affected["versions"]))
    for r in affected.get("ranges") or []:
        events = r.get("events") or []
        if any(e.get("introduced") == "0" for e in events) and not any("fixed" in e or "last_affected" in e for e in events):
            return "all"
    return []


def ossf(root: Path):
    """osv/malicious/<eco>/<name>/<id>.json and osv/withdrawn/… (withdrawn records are rows too)."""
    for state in ("malicious", "withdrawn"):
        base = root / "osv" / state
        if not base.is_dir():
            continue
        for path in base.rglob("*.json"):
            try:
                rec = json.loads(path.read_text())
            except (OSError, ValueError):
                continue
            origins = (rec.get("database_specific") or {}).get("malicious-packages-origins") or []
            for aff in rec.get("affected") or []:
                pkg = aff.get("package") or {}
                eco = ECOSYSTEMS.get(pkg.get("ecosystem", ""))
                if not eco:
                    continue
                yield {
                    "feed": "ossf", "id": rec.get("id"), "ecosystem": eco, "name": pkg.get("name"),
                    "published": rec.get("published"), "modified": rec.get("modified"),
                    "withdrawn": state == "withdrawn" or bool(rec.get("withdrawn")),
                    "sources": sorted({o.get("source") or "unknown" for o in origins}) or ["unknown"],
                    "first_import": min((o.get("import_time") or "" for o in origins), default="") or None,
                    "versions": _versions(aff), "aliases": rec.get("aliases") or [], "matched": [],
                    "kind": kind_of(f"{rec.get('summary') or ''} {rec.get('details') or ''}"),
                }


def vulnetix(root: Path):
    """vulnetix/<FAMILY>/<year>/<bucket>/<id>.json, malware classification only (their own detections)."""
    for path in (root / "vulnetix").rglob("*.json"):
        try:
            rec = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if rec.get("classification") != "malware":
            continue
        for aff in rec.get("affected") or []:
            eco = ECOSYSTEMS.get(aff.get("ecosystem", ""))
            if not eco:
                continue
            yield {
                "feed": "vulnetix", "id": rec.get("id") or path.stem, "ecosystem": eco, "name": aff.get("name"),
                "published": rec.get("published"),  # the record's date, not the package's
                "modified": None, "withdrawn": rec.get("state") == "withdrawn",
                "sources": ["vulnetix"], "first_import": None,
                "versions": sorted({v.get("version") for v in aff.get("versions") or [] if v.get("version")}),
                "aliases": [], "matched": [m.get("rule") for m in (rec.get("detection") or {}).get("matched_lines") or []],
                "kind": "static-rule",
            }


def ghsa(root: Path):
    for eco_file, eco in (("npm.jsonl", "npm"), ("pip.jsonl", "pypi")):
        path = root / eco_file
        if not path.is_file():
            continue
        for line in path.read_text().splitlines():
            a = json.loads(line)
            for name in a.get("pkgs") or []:
                yield {
                    "feed": "ghsa", "id": a["id"], "ecosystem": eco, "name": name, "published": a.get("published"),
                    "modified": None, "withdrawn": bool(a.get("withdrawn")),
                    "sources": sorted({c for c in a.get("credits") or [] if c}) or ["ghsa"], "first_import": None,
                    "versions": [], "aliases": [x for x in a.get("aliases") or [] if x != a["id"]], "matched": [],
                    "kind": kind_of(a.get("summary") or ""),
                }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--ossf", type=Path)
    ap.add_argument("--vulnetix", type=Path)
    ap.add_argument("--ghsa", type=Path)
    args = ap.parse_args()
    n = 0
    for gen, root in ((ossf, args.ossf), (vulnetix, args.vulnetix), (ghsa, args.ghsa)):
        if root is None:
            continue
        for row in gen(root):
            if row["name"]:
                sys.stdout.write(json.dumps(row, ensure_ascii=False) + "\n")
                n += 1
    print(f"{n} rows", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
