"""Transparency, part A: the analyst's scores for the 300 sampled records, and the shares per tool.

The judgements are data below, by the rules in METHODOLOGY.md ("Transparency and response"): a
template line shared by many records gets one judgement (TEXT_RULES); records whose text is their
own are judged one by one (BY_ID, every record of those tools listed). Structured fields are read
from the pinned snapshot: the `iocs` block (evidence when the record credits the tool alone),
references (linked evidence) and versions.

    python3 transparency_score.py SAMPLE_RECORDS OSSF_SNAPSHOT OUT_SCORED.jsonl OUT_SUMMARY.json
"""
import json
import math
import os
import re
import sys
from collections import defaultdict

SAMPLE, OSSF, OUT_ROWS, OUT_SUM = sys.argv[1:5]

# Template lines: (tool, regex on the tool's text) -> (evidence in text, reason, method, note)
TEXT_RULES = [
    ("ghsa-malware", r"^Any computer that has this package installed", (0, 0, 0, "advice on what to do; no behaviour, no method")),
    ("checkmarx", r".", (0, 1, 0, "campaign description naming the behaviour; no indicator in the text, no method")),
    ("ossf-package-analysis", r"^The OpenSSF Package Analysis project identified",
     (0, 1, 1, "names the analysis system and the behaviour class; the domain or command is not named")),
    ("google-open-source-security", r".", (0, 1, 0, "compromise or campaign behaviour; no indicator, no method")),
    ("unknown", r"was found to contain malicious code\.$", (0, 0, 0, "template line")),
    ("unknown", r"^The package communicates with a domain associated", (0, 1, 0, "behaviour class; domain not named")),
    ("reversing-labs", r"^$", (0, 0, 0, "no text of its own")),
    ("reversing-labs", r"was found to contain malicious code\.$", (0, 0, 0, "template line")),
    ("reversing-labs", r"^The package communicates with a domain associated", (0, 1, 0, "behaviour class; domain not named")),
]

# Records judged one by one: id -> (evidence in text, reason, method, note)
_A_TEMPLATE = (0, 0, 0, "template line")
_A_DETAIL = (1, 1, 0, "names files, code, hosts or paths and the behaviour; no method stated")
BY_ID = {
    # amazon-inspector: a template line or a detailed analysis
    **{i: _A_TEMPLATE for i in ("MAL-2026-380", "MAL-2026-14553", "MAL-2026-3893", "MAL-2026-1466", "MAL-2025-192530",
                                "MAL-2026-3794", "MAL-2026-760", "MAL-2026-2340", "MAL-2026-6049", "MAL-2025-191200",
                                "MAL-2026-2924")},
    **{i: _A_DETAIL for i in ("MAL-2026-12034", "MAL-2026-13663", "MAL-2026-17246", "MAL-2026-12503", "MAL-2026-17160",
                              "MAL-2026-11742", "MAL-2026-12067", "MAL-2026-13524", "MAL-2026-11792", "MAL-2026-6363",
                              "MAL-2026-10912", "MAL-2026-6919", "MAL-2026-11989", "MAL-2026-5468", "MAL-2026-4632",
                              "MAL-2026-12935", "MAL-2026-13877", "MAL-2026-4433", "MAL-2026-5327")},
    # kam193: a behaviour in its own words almost always; files or indicators named in six
    **{i: (0, 1, 0, "behaviour of the package or campaign; no file or indicator in the text") for i in (
        "MAL-2026-5281", "MAL-2025-48908", "MAL-2026-650", "MAL-2026-18162", "MAL-2026-2120", "MAL-2024-10017",
        "MAL-2024-9983", "MAL-2026-5773", "MAL-2026-3393", "MAL-2026-3660", "MAL-2026-18228", "MAL-2024-10071",
        "MAL-2026-3364", "MAL-2024-12365", "MAL-2026-3411", "MAL-2025-191746", "MAL-2026-15910", "MAL-2026-18131",
        "MAL-2025-192468", "MAL-2026-2141", "MAL-2025-191884", "MAL-2024-10081", "MAL-2026-3401")},
    "MAL-2025-2974": (1, 1, 0, "setup.py install override; GITHUB_TOKEN and other variables sent out"),
    "MAL-2024-10028": (1, 1, 1, "__init__.py obfuscated downloader; executables identified by VirusTotal"),
    "MAL-2025-5144": (1, 1, 0, "names the public template repository the package is built from, and setup.py"),
    "MAL-2026-909": (1, 1, 0, "hardcoded executable saved under %LOCALAPPDATA%"),
    "MAL-2024-5326": (1, 1, 0, "setup.py install override; obfuscation; typosquatting"),
    "MAL-2026-2305": (1, 1, 0, "names the domains roboat[.]pro and robase[.]app"),
    "MAL-2024-10172": (0, 0, 0, "category line only; the campaign's reason list is empty"),
    # oracle-using-macaron: an assessment of purpose in its own words; two name files
    **{i: (0, 1, 0, "purpose or behaviour in its own words; no file or indicator; no method") for i in (
        "MAL-2025-2591", "MAL-2025-2593", "MAL-2025-2602", "MAL-2025-2598", "MAL-2026-1003", "MAL-2025-2594",
        "MAL-2025-47458", "MAL-2026-1488", "MAL-2025-191946", "MAL-2025-2595", "MAL-2025-2592", "MAL-2025-2587",
        "MAL-2025-2588", "MAL-2025-2622", "MAL-2026-1453", "MAL-2025-2621", "MAL-2025-2596", "MAL-2025-2586",
        "MAL-2025-112503", "MAL-2025-2599", "MAL-2025-2589", "MAL-2026-911", "MAL-2025-2601", "MAL-2025-47875",
        "MAL-2025-2590", "MAL-2025-2600", "MAL-2025-2597", "MAL-2025-47510")},
    "MAL-2025-2345": (1, 1, 0, "injects code into site.py"),
    "MAL-2026-2201": (1, 1, 0, "setup.py with an opaque data.bin payload"),
}
BY_ID_TOOLS = {"amazon-inspector", "kam193", "oracle-using-macaron"}
# vulnetix: matched lines are evidence and the rule plus "static analysis" the method; the text is
# a template that would fit any package, except the indicator-list record
VULNETIX_IOC_TEXT = re.compile(r"^\[IOC-STIX-MATCH\] Malicious domain ")

LINKED = re.compile(r"virustotal\.com/gui/file|tria\.ge/|app\.any\.run/tasks|bad-packages\.kam193\.eu/pypi/package/")
OWN_SITE = {"kam193": "bad-packages.kam193.eu"}


def judge(r):
    if r["tool"] == "vulnetix":
        if VULNETIX_IOC_TEXT.match(r["tool_text"]):
            return 1, 1, 1, "names the indicator-list domain and the file; rule named; static analysis"
        lines = (r.get("detection") or {}).get("matched_lines") or []
        if not lines:
            return 0, 0, 1, "no matched line; template text; static analysis named"
        return 1, 0, 1, "matched lines with rule ids; the text is a template that fits any package"
    if r["tool"] in BY_ID_TOOLS:
        return BY_ID[r["id"]]  # every record of these tools is listed
    for tool, rx, verdict in TEXT_RULES:
        if tool == r["tool"] and re.search(rx, r["tool_text"].strip()):
            return verdict
    raise SystemExit(f"no judgement for {r['tool']} {r['id']}")


def wilson(k, n, z=1.96):
    if n == 0:
        return None
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(k / n, 3), round(max(0, c - h), 3), round(min(1, c + h), 3)]


rows = [json.loads(line) for line in open(SAMPLE, encoding="utf-8")]
assert len(rows) == 300 and len({r["id"] + r["tool"] for r in rows}) == 300
per = defaultdict(lambda: defaultdict(int))
with open(OUT_ROWS, "w", encoding="utf-8") as fo:
    for r in rows:
        ev_text, reason, method, note = judge(r)
        srcs, iocs = [r["tool"]], False
        if r["feed"] == "ossf":
            rec = json.load(open(os.path.join(OSSF, r["path"]), encoding="utf-8"))
            ds = rec.get("database_specific") or {}
            srcs = sorted({o["source"] for o in ds.get("malicious-packages-origins") or []}) or ["unknown"]
            iocs = bool(ds.get("iocs"))
        sole = srcs == [r["tool"]]
        ev = int(bool(ev_text) or (iocs and sole))
        own = OWN_SITE.get(r["tool"])
        linked = int(any(LINKED.search(u or "") and (sole or (own and own in u)) for u in r["references"]))
        versions = int(bool(r["versions"]["listed"] or r["versions"]["ranges"]))
        out = {"tool": r["tool"], "id": r["id"], "ecosystem": r["ecosystem"], "name": r["name"],
               "evidence": ev, "evidence_from": "text" if ev_text else ("iocs" if ev else None),
               "linked_evidence": linked, "reason": reason, "method": method, "versions": versions,
               "sole_source": sole, "sources": srcs, "note": note, "tool_text": r["tool_text"],
               "detection": r.get("detection"), "references": r["references"]}
        fo.write(json.dumps(out, ensure_ascii=False) + "\n")
        p = per[r["tool"]]
        p["n"] += 1
        for k in ("evidence", "linked_evidence", "reason", "method", "versions"):
            p[k] += out[k]
        p["evidence_or_linked"] += int(ev or linked)
summary = {t: {"n": p["n"], **{k: [p[k]] + (wilson(p[k], p["n"]) or []) for k in
                               ("evidence", "linked_evidence", "evidence_or_linked", "reason", "method", "versions")}}
           for t, p in sorted(per.items())}
json.dump(summary, open(OUT_SUM, "w"), indent=1)
for t, s in summary.items():
    print(f"{t:28} n={s['n']} " + " ".join(f"{k}={s[k][0]}" for k in s if k != "n"))
