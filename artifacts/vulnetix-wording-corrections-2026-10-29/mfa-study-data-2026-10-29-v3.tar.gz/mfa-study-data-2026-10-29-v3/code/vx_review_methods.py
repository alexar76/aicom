"""Fetch each still-published record of the 600 (vulnetix format, pinned commit) and count review methods."""
import json, subprocess, sys
from collections import Counter
src, commit, out = sys.argv[1], sys.argv[2], sys.argv[3]
rows = [json.loads(l) for l in open(src)]
res = []
for r in rows:
    i = r["id"]; _, _, fam, yr, num = i.split("-")
    path = f"vulnetix/{fam}/{yr}/{int(num) // 1000}xxx/{i}.json"
    p = subprocess.run(["gh", "api", f"repos/Vulnetix/advisory-database/contents/{path}?ref={commit}",
                        "-H", "Accept: application/vnd.github.raw"], capture_output=True, text=True)
    try:
        d = json.loads(p.stdout)
        rev = d.get("review") or {}
        res.append({"id": i, "ecosystem": r["ecosystem"], "classification": d.get("classification"), "state": d.get("state"),
                    "review_method": rev.get("method"), "approved_at": rev.get("approved_at")})
    except Exception as e:
        res.append({"id": i, "error": type(e).__name__})
with open(out, "w") as f:
    for x in res: f.write(json.dumps(x) + "\n")
print(Counter((x.get("ecosystem"), x.get("classification"), x.get("review_method")) for x in res))
print("approved dates (malware):", Counter(str(x.get("approved_at"))[:10] for x in res if x.get("classification") == "malware").most_common(10))
print("errors:", sum(1 for x in res if "error" in x))
