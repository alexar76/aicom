#!/usr/bin/env python3
"""Where a flagged package stands in its registry today: metadata requests only.

For a stratified random sample of normalize.py rows (per feed, detecting source, ecosystem and kind),
ask the registry what it serves now and write one JSONL row per package:

    removed      the registry answers 404 for the name (PyPI deletion, npm unpublish)
    placeholder  npm replaced it with its security holding package (0.0.1-security)
    versions_gone the name is live, but none of the flagged versions is served any more
    live         at least one flagged version (or, with no versions given, the name) is served

A takedown is evidence the registry agreed; "live" is not proof of a false positive (registries
are slow and miss things), so the study reports it as unresolved, never as wrong. Nothing is
downloaded beyond registry metadata. Run with python3 -I.

    python3 -I registry_check.py records.jsonl --per-stratum 400 --seed 20261024 > status.jsonl
"""

from __future__ import annotations

import argparse
import json
import random
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

PLACEHOLDER = re.compile(r"^0\.0\.1-security(\.\d+)?$")
UA = "malware-feed-accuracy-study/1.0 (+https://modelmarket.dev; metadata only)"


def fetch(url: str, accept: str = "application/json") -> tuple[int, dict | None]:
    for attempt in range(4):
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.status, json.loads(resp.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as err:
            if err.code in (429, 500, 502, 503, 504) and attempt < 3:
                time.sleep(2 ** attempt * 2)
                continue
            return err.code, None
        except (urllib.error.URLError, TimeoutError, OSError, ValueError):  # socket.timeout is OSError on 3.9
            if attempt < 3:
                time.sleep(2 ** attempt)
                continue
            return 0, None
    return 0, None


def npm_status(name: str, flagged: list[str] | str) -> dict:
    code, doc = fetch("https://registry.npmjs.org/" + urllib.parse.quote(name, safe="@"),
                      "application/vnd.npm.install-v1+json")
    if code == 404:
        return {"status": "removed", "http": code}
    if code != 200 or doc is None:
        return {"status": "error", "http": code}
    versions = doc.get("versions") or {}
    served = set(versions)
    # npm's holding package is 0.0.1-security, and also 0.0.1-security.0, .1, … when it was re-held
    if served and all(PLACEHOLDER.match(v) for v in served):
        return {"status": "placeholder", "http": code}
    if any(PLACEHOLDER.match(v) for v in served):
        # A held name can still LIST the versions it replaced while their tarballs are gone
        # (404): those are not served. Found in stage 2, where such packages were bundled as
        # npm's holder while this check had called them live. Only for held names, so the
        # extra requests stay few; the flagged versions first, at most 50.
        real = sorted((v for v in served if not PLACEHOLDER.match(v)),
                      key=lambda v: (v not in (flagged if isinstance(flagged, list) else []), v))
        gone = {v for v in real[:50] if not tarball_served(versions[v])}
        served -= gone
        if all(PLACEHOLDER.match(v) for v in served):
            return {"status": "placeholder", "http": code, "listed_without_tarball": len(gone)}
        out = _versions_verdict(served, flagged, code)
        out["listed_without_tarball"] = len(gone)
        return out
    return _versions_verdict(served, flagged, code)


def tarball_served(version_doc: dict) -> bool:
    url = ((version_doc or {}).get("dist") or {}).get("tarball")
    if not url:
        return False
    for attempt in range(4):
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": UA})
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.status == 200
        except urllib.error.HTTPError as err:
            if err.code in (429, 500, 502, 503, 504) and attempt < 3:
                time.sleep(2 ** attempt * 2)
                continue
            return False
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt < 3:
                time.sleep(2 ** attempt)
                continue
            return True  # unknown is not evidence of removal; keep the listed version
    return True


def pypi_status(name: str, flagged: list[str] | str) -> dict:
    code, doc = fetch(f"https://pypi.org/pypi/{urllib.parse.quote(name)}/json")
    if code == 404:
        return {"status": "removed", "http": code}
    if code != 200 or doc is None:
        return {"status": "error", "http": code}
    releases = doc.get("releases") or {}
    served = {v for v, files in releases.items() if files and not all(f.get("yanked") for f in files)}
    out = _versions_verdict(served, flagged, code)
    status = ((doc.get("info") or {}).get("project_status") or {})
    if isinstance(status, dict) and status.get("status") in ("quarantined", "archived", "deprecated"):
        out["project_status"] = status.get("status")
        if status.get("status") == "quarantined":
            out["status"] = "quarantined"
    return out


def _versions_verdict(served: set[str], flagged: list[str] | str, code: int) -> dict:
    if isinstance(flagged, list) and flagged:
        still = sorted(set(flagged) & served)
        return {"status": "live" if still else "versions_gone", "http": code, "flagged_served": len(still),
                "flagged": len(flagged), "served": len(served)}
    return {"status": "live" if served else "versions_gone", "http": code, "served": len(served)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("records")
    ap.add_argument("--per-stratum", type=int, default=400)
    ap.add_argument("--seed", type=int, default=20261024)
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--plan-only", action="store_true",
                    help="write the sampled rows without asking any registry (to check or store a sample)")
    args = ap.parse_args()

    strata: dict[tuple[str, str, str, str], list[dict]] = defaultdict(list)
    for line in open(args.records):
        row = json.loads(line)
        for src in row["sources"]:
            strata[(row["feed"], src, row["ecosystem"], row.get("kind", "malicious"))].append(row)
    rng = random.Random(args.seed)
    picked: dict[tuple[str, str], dict] = {}
    plan: list[tuple[tuple[str, str, str, str], dict]] = []
    for key in sorted(strata):
        rows = strata[key]
        sample = rows if len(rows) <= args.per_stratum else rng.sample(rows, args.per_stratum)
        for row in sample:
            plan.append((key, row))
            picked.setdefault((row["ecosystem"], row["name"]), row)
    print(f"{len(strata)} strata, {len(plan)} sampled rows, {len(picked)} distinct packages", file=sys.stderr)
    if args.plan_only:
        # The sample depends on the order of rows in the records file, and normalize.py reads the
        # snapshots in the order the filesystem lists them: keep the records file, or this plan.
        for (feed, src, eco, kind), row in plan:
            sys.stdout.write(json.dumps({"feed": feed, "source": src, "ecosystem": eco, "kind": kind, "id": row["id"],
                                         "name": row["name"], "published": row["published"],
                                         "withdrawn": row["withdrawn"], "versions": row["versions"],
                                         "stratum_size": len(strata[(feed, src, eco, kind)])}) + "\n")
        return 0

    def check(item):
        (eco, name), row = item
        fn = npm_status if eco == "npm" else pypi_status
        return (eco, name), fn(name, row["versions"])

    results: dict[tuple[str, str], dict] = {}
    with ThreadPoolExecutor(args.workers) as pool:
        for i, (key, res) in enumerate(pool.map(check, picked.items()), 1):
            results[key] = res
            if i % 500 == 0:
                print(f"  {i}/{len(picked)}", file=sys.stderr)
    checked_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    for (feed, src, eco, kind), row in plan:
        out = {"feed": feed, "source": src, "ecosystem": eco, "kind": kind, "id": row["id"], "name": row["name"],
               "published": row["published"], "withdrawn": row["withdrawn"], "stratum_size": len(strata[(feed, src, eco, kind)]),
               "checked_at": checked_at, **results[(eco, row["name"])]}
        if row["versions"] and isinstance(row["versions"], list):
            # per-row verdict: the flagged versions of THIS record
            res = results[(eco, row["name"])]
            if res["status"] in ("live", "versions_gone") and "flagged" in res and row is not picked[(eco, row["name"])]:
                out["status_note"] = "versions taken from another record of the same package"
        sys.stdout.write(json.dumps(out) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
