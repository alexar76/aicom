"""Transparency, part A: draw 30 records per tool from the pinned stage 1 snapshots and extract what
each record shows (METHODOLOGY.md, "Transparency and response").

Population per tool: the rows of records_ov.jsonl of kind `malicious` (OpenSSF) or `static-rule`
(Vulnetix) that credit the tool, withdrawn records included, sorted by record id. One generator,
seeded 2026102710, draws min(30, n) ids per tool, tools taken in sorted order, so the draw does not
depend on the filesystem. For an OpenSSF record only the tool's own section of `details`
(`## Source: <tool> (<hash>)`) is the tool's text; when the tool has no section of its own (a
record that credits no tool, or a bulk import), it is the text above the per-source part, and
`text_from` says which. The summary, references and structured versions are kept beside it. Simple proxies are
recorded as a cross-check of the analyst's scores, not instead of them.

    python3 transparency_sample.py RECORDS_OV OSSF_SNAPSHOT VULNETIX_SNAPSHOT OUT.jsonl
"""
from __future__ import annotations

import json
import os
import random
import re
import sys
from collections import defaultdict

SEED = 2026102710
PER_TOOL = 30
KINDS = {"ossf": "malicious", "vulnetix": "static-rule"}

RECORDS, OSSF, VULNETIX, OUT = sys.argv[1:5]

pop = defaultdict(list)
for line in open(RECORDS, encoding="utf-8"):
    r = json.loads(line)
    if r["kind"] != KINDS.get(r["feed"]):
        continue
    for tool in r["sources"] or ["unknown"]:
        pop[tool].append(r)
rng = random.Random(SEED)
drawn = []
for tool in sorted(pop):
    rows = sorted(pop[tool], key=lambda r: r["id"])
    for r in rng.sample(rows, min(PER_TOOL, len(rows))):
        drawn.append((tool, len(rows), r))
want = {r["id"] for _, _, r in drawn}

paths = {}
for top in (os.path.join(OSSF, "osv", "malicious"), os.path.join(OSSF, "osv", "withdrawn"),
            os.path.join(VULNETIX, "vulnetix")):
    for d, _, files in os.walk(top):
        for f in files:
            if f.endswith(".json") and f[:-5] in want:
                paths[f[:-5]] = os.path.join(d, f)

# "## Source: amazon-inspector (6b1e…)": the tool, then the hash of its section
SECTION = re.compile(r"^## Source: (?P<tool>[^\s(]+)[^\n]*$", re.M)
SEPARATOR = "\n---\n_-= Per source details"
URL = re.compile(r"https?://\S+")
PATH = re.compile(r"(?:[\w.@-]+/)+[\w.@-]+\.\w{1,5}\b|\b[\w-]+\.(?:js|cjs|mjs|ts|py|sh|json|pth|cfg|toml|bat|ps1|exe|dll)\b")
CODE = re.compile(r"`[^`]+`|```")
IP = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
HASH = re.compile(r"\b[0-9a-f]{32,64}\b", re.I)


def tool_text(details: str, tool: str) -> tuple[str, str]:
    """The tool's own section, else the record's text above the per-source part, and which."""
    details = details or ""
    for i, m in enumerate(parts := list(SECTION.finditer(details))):
        if m.group("tool") == tool:
            end = parts[i + 1].start() if i + 1 < len(parts) else len(details)
            return details[m.end():end].strip(), "section"
    return details.split(SEPARATOR)[0].strip(), "top"


def versions(rec: dict) -> dict:
    out = {"listed": [], "ranges": []}
    for a in rec.get("affected") or []:
        for v in a.get("versions") or []:
            out["listed"].append(v["version"] if isinstance(v, dict) else v)
        for rg in a.get("ranges") or []:
            out["ranges"].append(rg.get("events"))
    return out


with open(OUT, "w", encoding="utf-8") as fo:
    for tool, n, r in drawn:
        p = paths.get(r["id"])
        rec = json.load(open(p, encoding="utf-8")) if p else {}
        if r["feed"] == "ossf":
            text, text_from = tool_text(rec.get("details", ""), tool)
        else:
            text, text_from = rec.get("details") or "", "details"
        detection = rec.get("detection") if r["feed"] == "vulnetix" else None
        probe = text + " " + json.dumps(detection or {})
        row = {
            "tool": tool, "population": n, "feed": r["feed"], "id": r["id"], "ecosystem": r["ecosystem"],
            "name": r["name"], "withdrawn": r["withdrawn"], "found": bool(p),
            "path": os.path.relpath(p, OSSF if r["feed"] == "ossf" else VULNETIX) if p else None,
            "summary": rec.get("summary"), "tool_text": text, "text_from": text_from, "detection": detection,
            "references": [x.get("url") for x in rec.get("references") or []],
            "versions": versions(rec),
            "proxy": {"chars": len(text), "urls": len(URL.findall(probe)), "paths": len(PATH.findall(probe)),
                      "code": len(CODE.findall(probe)), "ips": len(IP.findall(probe)),
                      "hashes": len(HASH.findall(probe))},
        }
        fo.write(json.dumps(row, ensure_ascii=False) + "\n")
print("drawn", len(drawn), "found", len(paths), "tools", {t: min(PER_TOOL, len(v)) for t, v in sorted(pop.items())})
