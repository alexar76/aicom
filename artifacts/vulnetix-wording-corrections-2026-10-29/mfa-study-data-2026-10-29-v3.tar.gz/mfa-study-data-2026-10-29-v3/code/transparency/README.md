# Transparency and response (2026-10-27)

Section 9 of the write-up rests on these files; the criteria and the rules for edge cases are in
[../METHODOLOGY.md](../METHODOLOGY.md), "Transparency and response".

| File | What it holds |
|---|---|
| `sample_records.jsonl` | 300 records, 30 per tool, drawn from the pinned stage 1 snapshots by `../transparency_sample.py` (seed 2026102710): the tool's own text, summary, references, versions, simple proxies |
| `scored.jsonl` | each record with the analyst's scores (evidence, linked evidence, reason, method, versions), a note, and the text the scores rest on; the judgements are data in `../transparency_score.py` |
| `summary.json` | counts per tool with Wilson 95% intervals |
| `disputes.jsonl` | 100 disputes from the three public trackers, each with the tools its records credit, the first answer by the feed, and the outcome; the readings are data in `../disputes_measure.py` |
| `disputes_summary.json` | per tracker and per OpenSSF tool |
| `vulnetix_remaining_600_2026-10-29.jsonl` | added 2026-10-29 at Vulnetix's request: the 600 npm and PyPI records of the stage 1 snapshot that Vulnetix's withdrawal index of 2026-10-27 does not list, each with its class, state, review method and approval date on 2026-10-29 (Vulnetix commit `48a29d8e8e2e`); record ids only |
| `vulnetix_followup_2026-10-29.json` | counts only: the snapshot against that index, the 600 now, and the 100 Vulnetix records rated in stage 2 by our label against Vulnetix's withdrawals (`../vx_followup.py`, `../vx_review_methods.py`) |

Kept on two servers only, with checksums in [../data-manifest.json](../data-manifest.json): the raw
issue dump (issue lists, comments and events from the public GitHub API) and Vulnetix's withdrawal
index of 2026-10-27.
