#!/usr/bin/env python3
"""Stage 3 numbers, as fixed in METHODOLOGY.md ("Stage 3 protocol") before any set was drawn.

    python3 stage3_score.py OUT_DIR MANIFEST_DIR --volumes volumes.json > stage3_results.json

OUT_DIR holds <scanner>_<set>.jsonl (stage3_scan.py), MANIFEST_DIR manifest_<set>.jsonl. volumes.json
gives, per ecosystem, the benign B window's volume and the malware the open feeds flagged in it:
    {"days": 7, "npm": {"volume": N, "volume_note": "...", "flagged": M}, "pypi": {...}}

Per scanner and ecosystem: outcomes (flag / clean / timeout / error, never folding a timeout or an
error into "clean"); recall on the malicious set; false positives per 1,000 in benign A and in benign
B; precision and F1 on malicious + benign A (balanced, as benchmarks report) and at the base rate
(flagged / volume, a lower bound: only malware someone caught is counted); false alarms per day at
the window's volume; recall by the half-year the sample was published in; flags by rule. Wilson 95%
intervals throughout. Benign B flags are listed for the reading by hand the protocol requires.
"""
from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

SETS = ("malicious", "benignA", "benignB")
SCANNERS = ("baseline", "guarddog", "malcontent", "ossgadget")
DATE = re.compile(r"/(\d{4})-(\d{2})-\d{2}-[^/]*$")


def wilson(k: int, n: int, z: float = 1.96) -> list[float] | None:
    if n == 0:
        return None
    p = k / n
    den = 1 + z * z / n
    mid = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return [round(max(0.0, mid - half), 4), round(min(1.0, mid + half), 4)]


def rate(k: int, n: int) -> dict:
    return {"k": k, "n": n, "value": round(k / n, 4) if n else None, "ci95": wilson(k, n)}


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()] if path.exists() else []


def half_year(row: dict) -> str | None:
    m = DATE.search(str(row.get("archive") or ""))
    return f"{m.group(1)}H{1 if int(m.group(2)) <= 6 else 2}" if m else None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("out_dir", type=Path)
    ap.add_argument("manifest_dir", type=Path)
    ap.add_argument("--volumes", type=Path, required=True)
    args = ap.parse_args()
    volumes = json.loads(args.volumes.read_text())

    manifest: dict[str, dict[str, dict]] = {}
    for s in SETS:
        manifest[s] = {r["key"]: r for r in load_jsonl(args.manifest_dir / f"manifest_{s}.jsonl")}
        # The fetch jobs carry the DataDog archive path, whose name starts with the sample's date.
        for job in load_jsonl(args.manifest_dir / f"jobs_s3_{s}.jsonl"):
            if job.get("key") in manifest[s] and job.get("archive"):
                manifest[s][job["key"]].setdefault("archive", job["archive"])

    results: dict = {"volumes": volumes, "sets": {}, "scanners": {}, "benignB_flags": []}
    for s in SETS:
        by_eco = Counter(r["ecosystem"] for r in manifest[s].values())
        unpacked = Counter(r["ecosystem"] for r in manifest[s].values() if not r.get("error"))
        results["sets"][s] = {"drawn": dict(by_eco), "unpacked": dict(unpacked)}

    for scanner in SCANNERS:
        per_eco: dict = {}
        for eco in ("npm", "pypi"):
            cell: dict = {}
            outcomes: dict[str, dict[str, Counter]] = {}
            rows_by_set: dict[str, list[dict]] = {}
            for s in SETS:
                rows = [r for r in load_jsonl(args.out_dir / f"{scanner}_{s}.jsonl")
                        if manifest[s].get(r["key"], {}).get("ecosystem") == eco]
                rows_by_set[s] = rows
                c = Counter(r.get("outcome") for r in rows)
                # GuardDog reports rules that failed to run in "errors"; a clean verdict with failed
                # rules is not a full reading, so it is counted apart.
                # malcontent's files it could not open (read_errors) likewise.
                c["clean_with_rule_errors"] = sum(1 for r in rows if r.get("outcome") == "clean"
                                                  and (r.get("errors") or r.get("read_errors")))
                outcomes[s] = c
                missing = sum(1 for k, m in manifest[s].items()
                              if m["ecosystem"] == eco and not m.get("error") and k not in {r["key"] for r in rows})
                cell[s] = {"outcomes": dict(c), "not_run": missing}
            if not rows_by_set["malicious"] and not rows_by_set["benignA"]:
                per_eco[eco] = {"not_run": True}
                continue
            n_mal = sum(1 for m in manifest["malicious"].values() if m["ecosystem"] == eco and not m.get("error"))
            tp = outcomes["malicious"]["flag"]
            mal_done = tp + outcomes["malicious"]["clean"]
            cell["recall"] = rate(tp, n_mal)  # a timeout or a crash is a miss here
            cell["recall_of_completed"] = rate(tp, mal_done)
            for s in ("benignA", "benignB"):
                done = outcomes[s]["flag"] + outcomes[s]["clean"]
                r = rate(outcomes[s]["flag"], done)
                cell[f"fp_per_1000_{s}"] = {**r, "value": round(1000 * r["value"], 1) if r["value"] is not None else None,
                                             "ci95": [round(1000 * x, 1) for x in r["ci95"]] if r["ci95"] else None}
            fp_a = outcomes["benignA"]["flag"]
            precision = tp / (tp + fp_a) if tp + fp_a else None
            recall = tp / n_mal if n_mal else None
            cell["balanced"] = {
                "precision": round(precision, 4) if precision is not None else None,
                "f1": round(2 * precision * recall / (precision + recall), 4) if precision and recall else None,
            }
            vol = volumes.get(eco) or {}
            if vol.get("volume") and recall is not None:
                prev = vol["flagged"] / vol["volume"]
                done_b = outcomes["benignB"]["flag"] + outcomes["benignB"]["clean"]
                fpr = outcomes["benignB"]["flag"] / done_b if done_b else None
                if fpr is not None:
                    tp_rate, fp_rate = recall * prev, fpr * (1 - prev)
                    p_br = tp_rate / (tp_rate + fp_rate) if tp_rate + fp_rate else None
                    per_day = vol["volume"] / volumes.get("days", 7)
                    cell["at_base_rate"] = {
                        "prevalence_lower_bound": round(prev, 6),
                        "precision": round(p_br, 5) if p_br is not None else None,
                        "f1": round(2 * p_br * recall / (p_br + recall), 5) if p_br and recall else None,
                        "false_alarms_per_day": round(fpr * per_day, 1),
                        "false_alarms_per_day_ci95": [round(x * per_day, 1) for x in wilson(outcomes["benignB"]["flag"], done_b)],
                        "true_alarms_per_day": round(recall * vol["flagged"] / volumes.get("days", 7), 1),
                    }
            by_period: dict[str, Counter] = defaultdict(Counter)
            for r in rows_by_set["malicious"]:
                hy = half_year(manifest["malicious"].get(r["key"], {}))
                if hy:
                    by_period[hy]["n"] += 1
                    by_period[hy]["flag"] += r.get("outcome") == "flag"
            cell["recall_by_half_year"] = {hy: rate(c["flag"], c["n"]) for hy, c in sorted(by_period.items())}
            for s in SETS:
                rules = Counter()
                for r in rows_by_set[s]:
                    if r.get("outcome") == "flag":
                        rules.update((r.get("rules") or {}).keys() if isinstance(r.get("rules"), dict) else (r.get("rules") or []))
                cell[s]["flags_by_rule"] = dict(rules.most_common(15))
            for r in rows_by_set["benignB"]:
                if r.get("outcome") == "flag":
                    m = manifest["benignB"][r["key"]]
                    results["benignB_flags"].append({"scanner": scanner, "key": r["key"], "ecosystem": eco,
                                                     "name": m.get("name"), "version": m.get("version"),
                                                     "rules": r.get("rules")})
            per_eco[eco] = cell
        results["scanners"][scanner] = per_eco
    print(json.dumps(results, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
