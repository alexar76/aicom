#!/bin/sh
# s3_ossgadget.sh SET : OSSGadget 0.2.38 detect-backdoor over one unpacked set, one gVisor run per
# package, no network, 300 s each (exit 124 = timeout), two at a time, at low CPU priority (the host also runs HISTOR's sandbox); then folded by stage3_scan.py.
# Image mfa-ossgadget:2 = the dotnet tool plus the BackdoorRules of the v0.2.38 tag, which the tool
# package does not ship (without them every scan returns no results, silently).
set -e
S="$1"; W=/root/mfa-study; O=$W/s3/out; D=$O/oss_$S; mkdir -p "$D"
RUN="docker run --rm --runtime=runsc --network=none --memory=3g --memory-swap=3g --cpus=1 --cpu-shares=256 --pids-limit=512"
grep -v '"error"' "$W/s3/manifest_$S.jsonl" | python3 -c 'import json,sys; [print(json.loads(l)["key"]) for l in sys.stdin if l.strip()]' |
  xargs -P 2 -I{} sh -c "[ -s '$D/{}.rc' ] && exit 0; timeout 300 $RUN -v '$W/s3/$S/{}':/pkg:ro --entrypoint /root/.dotnet/tools/ossgadget mfa-ossgadget:2 detect-backdoor --format sarifv2 /pkg > '$D/{}.sarif' 2> '$D/{}.err'; echo \$? > '$D/{}.rc'"
$RUN -v $W:/w:ro -v $O:/o:ro histor-python:3.12 python3 /w/stage3_scan.py ossgadget /w/s3/$S /w/s3/manifest_$S.jsonl /o/oss_$S > $O/ossgadget_$S.jsonl
echo "done ossgadget $S"
