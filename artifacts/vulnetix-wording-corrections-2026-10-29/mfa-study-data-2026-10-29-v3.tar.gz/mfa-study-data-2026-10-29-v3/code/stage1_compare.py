#!/usr/bin/env python3
"""Registry action on the stage 1 sample at two times, as fixed in METHODOLOGY.md (repeat measurement,
amended 2026-10-27).

    python3 -I stage1_compare.py --published stage1_published_2026-10-24.json --now status_B.jsonl
    python3 -I stage1_compare.py --then status_A.jsonl --now status_B.jsonl

With --published (counts only, the per-row link lost): per stratum, the two shares and their difference
with Newcombe's hybrid score interval, labelled unpaired. With --then (a per-row file of the same rows):
the same table, plus McNemar's exact test on the rows present in both, the rows that changed each
way, and Holm's correction across the strata of each feed. Rows with a registry error are left out of
the stratum they are in. Run with python3 -I; standard library only.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from math import comb

ACTED = {"removed", "placeholder", "quarantined", "versions_gone"}
Z = 1.959963984540054


def wilson(k: int, n: int) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    den = 1 + Z * Z / n
    mid = (p + Z * Z / (2 * n)) / den
    half = Z * math.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / den
    return max(0.0, mid - half), min(1.0, mid + half)


def newcombe(k1: int, n1: int, k2: int, n2: int) -> tuple[float, float, float]:
    """p2 - p1 with Newcombe's hybrid score interval (method 10)."""
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = wilson(k1, n1)
    l2, u2 = wilson(k2, n2)
    d = p2 - p1
    return d, d - math.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2), d + math.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2)


def mcnemar_exact(b: int, c: int) -> float:
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(comb(n, i) for i in range(0, k + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def holm(pvals: dict[str, float]) -> dict[str, float]:
    order = sorted(pvals, key=pvals.get)
    m, out, running = len(order), {}, 0.0
    for i, key in enumerate(order):
        running = max(running, min(1.0, (m - i) * pvals[key]))
        out[key] = running
    return out


def load_rows(path: str) -> dict[str, dict]:
    rows = {}
    for line in open(path):
        r = json.loads(line)
        key = "|".join((r["feed"], r["source"], r["ecosystem"], r["kind"], r["id"], r["name"]))
        rows[key] = r
    return rows


def stratum(key: str) -> str:
    return "|".join(key.split("|")[:4])


def counts(rows: dict[str, dict]) -> dict[str, dict]:
    out: dict[str, dict] = defaultdict(lambda: {"n": 0, "acted": 0, "errors": 0})
    for key, r in rows.items():
        s = out[stratum(key)]
        if r["status"] == "error":
            s["errors"] += 1
            continue
        s["n"] += 1
        s["acted"] += r["status"] in ACTED
    return dict(out)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--published")
    ap.add_argument("--then")
    ap.add_argument("--now", required=True)
    ap.add_argument("--json")
    args = ap.parse_args()
    now_rows = load_rows(args.now)
    now = counts(now_rows)
    paired = args.then is not None
    if paired:
        then_rows = load_rows(args.then)
        then = counts(then_rows)
    else:
        then = json.load(open(args.published))["strata"]
    result = {"paired": paired, "strata": {}}
    pvals: dict[str, dict[str, float]] = defaultdict(dict)
    for s in sorted(set(then) & set(now)):
        a, b = then[s], now[s]
        if not a["n"] or not b["n"]:
            continue
        d, lo, hi = newcombe(a["acted"], a["n"], b["acted"], b["n"])
        cell = {"then": [a["acted"], a["n"]], "now": [b["acted"], b["n"]], "difference": round(d, 4),
                "ci95": [round(lo, 4), round(hi, 4)], "errors_now": b.get("errors", 0)}
        if paired:
            keys = [k for k in now_rows if stratum(k) == s and k in then_rows
                    and now_rows[k]["status"] != "error" and then_rows[k]["status"] != "error"]
            up = sum(1 for k in keys if then_rows[k]["status"] not in ACTED and now_rows[k]["status"] in ACTED)
            down = sum(1 for k in keys if then_rows[k]["status"] in ACTED and now_rows[k]["status"] not in ACTED)
            cell.update({"paired_rows": len(keys), "newly_acted": up, "acted_then_live_now": down,
                         "mcnemar_p": mcnemar_exact(up, down)})
            pvals[s.split("|")[0]][s] = cell["mcnemar_p"]
        result["strata"][s] = cell
    if paired:
        for feed, ps in pvals.items():
            for s, adj in holm(ps).items():
                result["strata"][s]["holm_p"] = adj
    print(f"{'stratum':58} {'then':>11} {'now':>11} {'difference (95% CI)':>26}" + ("  changed +/-  Holm p" if paired else ""))
    for s, c in result["strata"].items():
        line = (f"{s:58} {c['then'][0]:>4}/{c['then'][1]:<6} {c['now'][0]:>4}/{c['now'][1]:<6} "
                f"{100 * c['difference']:+6.1f} ({100 * c['ci95'][0]:+.1f} to {100 * c['ci95'][1]:+.1f}) pp")
        if paired:
            line += f"  +{c['newly_acted']}/-{c['acted_then_live_now']}  {c['holm_p']:.3g}"
        print(line)
    print("(unpaired: counts on the same rows whose per-row link is lost)" if not paired else "(paired on the same rows)")
    if args.json:
        json.dump(result, open(args.json, "w"), indent=1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
