#!/usr/bin/env python3
"""Build the study's data archive for a DOI deposit, as METHODOLOGY.md ("Data custody and
publication") fixes it: no package file, and no name next to a benign reading.

    python3 -I build_archive.py --study /root/mfa-study --code CODE_DIR --out OUT_DIR --commit SHA

STUDY is the sandbox host's study folder (read only). CODE_DIR holds the repository files at
COMMIT (this folder and the five reports). OUT_DIR receives the archive tree.

What is withheld, and why:
- Stage 2: every rated package gets a fresh random id, malicious ones included. Several frames were
  rated whole, so naming the malicious rows would name the benign ones by elimination. Record ids
  become opaque tokens (they name the package); free text (rater evidence and summaries,
  adjudication reasons), versions and file lists are dropped; timestamps keep the date only.
- Stage 1: rows of the packages rated in stage 2 carry no name and no record id; every other row is
  a public feed record with its public registry status, as published.
- Stage 3: benign sets A and B get fresh ids, with no name, version or file count. The malicious
  set keeps its names: it is DataDog's public dataset, cited by path.
- Scanner outputs keep the outcome, rule ids and counts; error messages and raw reports (file
  paths name the package) stay on the two servers.
Every output is checked afterwards: no original key and no withheld name may appear in a data file.
Standard library only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import secrets
import shutil
import tarfile
from collections import Counter
from pathlib import Path

SCANNERS = ("baseline", "guarddog", "malcontent", "ossgadget")
SETS = ("malicious", "benignA", "benignB")
RATING_FILES = ("ratings_counted.jsonl", "ratings_select.jsonl", "ratings_cmp_v1.jsonl", "ratings_cmp_v2.jsonl",
                "ratings_controls.first-pair-v2.jsonl", "ratings_sample.first-pair-v2.jsonl",
                "ratings_sample.discarded-prompt-v1.jsonl")
KEY_FILES = ("keys_ctl_select.txt", "keys_counted.txt", "keys_cmp_v1.txt", "keys_cmp_v2.txt")
STRATUM_FIELDS = ("feed", "source", "ecosystem", "stratum_frame", "sampled_in_stratum")
USAGE_FIELDS = ("prompt_tokens", "completion_tokens", "total_tokens", "cost")


class Tar:
    def __init__(self, path: Path):
        self.t = tarfile.open(path)
        self.members = {m.name.lstrip("./"): m for m in self.t.getmembers() if m.isfile()}

    def read(self, tail: str) -> str:
        hits = [m for name, m in self.members.items() if name == tail or name.endswith("/" + tail)]
        assert len(hits) == 1, (tail, [m.name for m in hits])
        return self.t.extractfile(hits[0]).read().decode("utf-8")

    def jsonl(self, tail: str) -> list[dict]:
        return [json.loads(line) for line in self.read(tail).splitlines() if line.strip()]

    def lines(self, tail: str) -> list[str]:
        return [line.strip() for line in self.read(tail).splitlines() if line.strip()]


def jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def write_jsonl(path: Path, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in rows))


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=1, sort_keys=True) + "\n")


class Ids:
    """Fresh random ids, never derived from the name."""

    def __init__(self, avoid: set[str]):
        self.map: dict[str, str] = {}
        self.avoid = set(avoid)

    def __call__(self, key: str, prefix: str = "") -> str:
        if key not in self.map:
            while True:
                new = prefix + secrets.token_hex(6)
                if new not in self.avoid:
                    break
            self.avoid.add(new)
            self.map[key] = new
        return self.map[key]


def day(ts) -> str | None:
    return str(ts)[:10] if ts else None


def build(study: Path, code: Path, out: Path, commit: str) -> dict:
    s2d = Tar(study / "stage2-data-2026-10-27.tgz")
    s2r = Tar(study / "stage2-restored-2026-10-27.tgz")
    s3o = Tar(study / "stage3-outputs-2026-10-27.tgz")
    man3 = study / "restore/stage3/manifests"

    km_sample = json.loads(s2r.read("in/keymap_sample.json"))
    km_mal = json.loads(s2r.read("in/keymap_controls_mal.json"))
    km_ben = json.loads(s2r.read("in/keymap_controls_ben.json"))
    manifests = {s: jsonl(man3 / f"manifest_{s}.jsonl") for s in SETS}
    jobs = {s: jsonl(man3 / f"jobs_s3_{s}.jsonl") for s in SETS}

    original_keys = set(km_sample) | set(km_mal) | set(km_ben) | {r["key"] for s in SETS for r in manifests[s]}
    ids = Ids(original_keys)
    tokens = Ids(original_keys)
    withheld = {(v["ecosystem"], v["name"]) for v in km_sample.values()}
    withheld |= {(v["ecosystem"], v["name"]) for v in km_ben.values()}
    withheld |= {(r["ecosystem"], r["name"]) for s in ("benignA", "benignB") for r in manifests[s]}
    withheld |= {(r["ecosystem"], r["name"]) for s in ("benignA", "benignB") for r in jobs[s] if r.get("name")}
    counts: Counter = Counter()

    # ---- stage 2
    d2 = out / "stage2"
    gone = set(s2r.lines("in/withdrawn_ids.txt"))
    keymap = {}
    for key, v in km_sample.items():
        strata = []
        for s in v["strata"]:
            row = {f: s[f] for f in STRATUM_FIELDS if f in s}
            row["id"] = tokens(s["id"], "rec-")
            strata.append(row)
        keymap[ids(key)] = {"role": "sample", "ecosystem": v["ecosystem"], "strata": strata}
    write_json(d2 / "keymap_sample.json", keymap)
    write_json(d2 / "keymap_controls_mal.json",
               {ids(k): {"role": v["role"], "ecosystem": v["ecosystem"], "name": v["name"]} for k, v in km_mal.items()})
    write_json(d2 / "keymap_controls_ben.json",
               {ids(k): {"role": v["role"], "ecosystem": v["ecosystem"]} for k, v in km_ben.items()})
    (d2 / "controls_malicious.txt").write_text(s2r.read("in/controls_malicious.txt"))
    in_sample = {s["id"] for v in km_sample.values() for s in v["strata"]}
    # Sorted by token, not by record id: the order of record ids is public and would link them.
    (d2 / "withdrawn_ids.txt").write_text("".join(t + "\n" for t in sorted(tokens(i, "rec-") for i in gone & in_sample)))
    counts["stage2 withdrawn record tokens"] = len(gone & in_sample)

    def rating(r: dict) -> dict:
        assert r["key"] in ids.map, ("unmapped rating key", r.get("rater"))
        row = {"key": ids.map[r["key"]], "rated_on": day(r.get("rated_at"))}
        for f in ("rater", "model", "model_served", "prompt", "label", "confidence"):
            if f in r:
                row[f] = r[f]
        if isinstance(r.get("usage"), dict):
            row["usage"] = {f: r["usage"][f] for f in USAGE_FIELDS if f in r["usage"]}
        return row

    for name in RATING_FILES:
        rows = sorted((rating(r) for r in s2d.jsonl(name)), key=lambda r: (r.get("rater", ""), r["key"]))
        write_jsonl(d2 / name, rows)
        counts[f"stage2 {name}"] = len(rows)
    for name in KEY_FILES:
        keys = s2d.lines(name)
        assert all(k in ids.map for k in keys), name
        (d2 / name).write_text("".join(k + "\n" for k in sorted(ids.map[k] for k in keys)))
    for name in ("keys_ctl_heldout.txt", "keys_held_2026-10-27.txt"):
        keys = s2r.lines("in/" + name)
        assert all(k in ids.map for k in keys), name
        (d2 / name).write_text("".join(k + "\n" for k in sorted(ids.map[k] for k in keys)))
    for name in ("adjudications.jsonl", "audit_analyst.jsonl"):
        rows = [{"key": ids.map[r["key"]], "label": r["label"], "by": r.get("by"), "on": day(r.get("at"))}
                for r in s2r.jsonl("in/" + name)]
        write_jsonl(d2 / name, sorted(rows, key=lambda r: r["key"]))
        counts[f"stage2 {name}"] = len(rows)
    write_jsonl(d2 / "frames_published.jsonl",
                [{"strata": [{f: s[f] for f in ("source", "ecosystem", "stratum_frame")} for s in r["strata"]]}
                 for r in s2r.jsonl("in/stage2_frames_published.jsonl")])
    write_jsonl(d2 / "bundles.jsonl", sorted(
        ({"key": ids.map[b["key"]], "ecosystem": b["ecosystem"], "file_count": b.get("file_count"),
          "error": bool(b.get("error"))} for b in s2d.jsonl("bundles_all.jsonl")), key=lambda r: r["key"]))
    final = json.loads(s2r.read("out/stage2_final_restored.json"))
    final["final"] = {ids.map[k]: v for k, v in sorted(final["final"].items(), key=lambda kv: ids.map[kv[0]])}
    write_json(d2 / "results_restored.json", final)
    for name in ("stage2_final_restored.txt", "stage2_controls_restored.txt"):
        (d2 / name.replace("stage2_", "results_")).write_text(s2r.read("out/" + name))

    # ---- stage 3
    d3 = out / "stage3"
    for s in SETS:
        rows = []
        for r in manifests[s]:
            row = {"set": s, "key": ids(r["key"]), "ecosystem": r["ecosystem"]}
            if r.get("error"):
                row["error"] = True
            if s == "malicious":
                row.update({f: r[f] for f in ("name", "version", "files") if f in r})
            rows.append(row)
        write_jsonl(d3 / f"manifest_{s}.jsonl", sorted(rows, key=lambda r: r["key"]))
        counts[f"stage3 manifest_{s}"] = len(rows)
    write_jsonl(d3 / "jobs_s3_malicious.jsonl", sorted(
        ({"key": ids.map[j["key"]], "archive": j["archive"]} for j in jobs["malicious"] if j.get("archive")),
        key=lambda r: r["key"]))
    for scanner in SCANNERS:
        for s in SETS:
            rows = []
            for r in s3o.jsonl(f"s3/out/{scanner}_{s}.jsonl"):
                assert r["key"] in ids.map, (scanner, s)
                row = {"key": ids.map[r["key"]], "scanner": scanner, "outcome": r.get("outcome")}
                for f in ("rules", "capabilities", "risk", "seconds"):
                    if f in r:
                        row[f] = r[f]
                if r.get("errors"):
                    row["errors"] = {k: 1 for k in r["errors"]} if isinstance(r["errors"], dict) else len(r["errors"])
                if r.get("read_errors"):
                    row["read_errors"] = len(r["read_errors"]) if isinstance(r["read_errors"], (list, dict)) else r["read_errors"]
                if r.get("error"):
                    row["error"] = True
                rows.append(row)
            write_jsonl(d3 / f"{scanner}_{s}.jsonl", sorted(rows, key=lambda r: r["key"]))
    results = json.loads((study / "restore/stage3/out/stage3_results.json").read_text())
    results["benignB_flags"] = sorted(({"scanner": f["scanner"], "key": ids.map[f["key"]], "ecosystem": f["ecosystem"],
                                        "rules": f.get("rules")} for f in results["benignB_flags"]),
                                      key=lambda f: (f["scanner"], f["key"]))
    write_json(d3 / "results_restored.json", results)
    shutil.copy(study / "restore/stage3/scripts/stage3_volumes.json", d3 / "stage3_volumes.json")

    # ---- stage 1
    d1 = out / "stage1"
    plan = jsonl(study / "stage1/sample_plan.jsonl")
    status = jsonl(study / "stage1/out/status_2026-10-27.jsonl")
    assert len(plan) == len(status)
    rows = []
    for i, (p, st) in enumerate(zip(plan, status)):
        assert (p["feed"], p["source"], p["ecosystem"], p["id"]) == (st["feed"], st["source"], st["ecosystem"], st["id"])
        row = {**p, **{f: st[f] for f in ("checked_at", "status", "http") if f in st}}
        if (p["ecosystem"], p["name"]) in withheld:
            # One opaque token per row in both fields, so stage1_compare.py still keys every row apart.
            row["name"] = row["id"] = tokens(f"stage1 row {i}", "withheld-")
            row["withheld"] = True
            counts["stage1 rows withheld"] += 1
        rows.append(row)
    write_jsonl(d1 / "sample_status_2026-10-27.jsonl", rows)
    for name in ("summary_2026-10-27.json", "compare_2026-10-24_vs_2026-10-27.json", "results_2026-10-27.md"):
        shutil.copy(study / "stage1/out" / name, d1 / name)
    shutil.copy(code / "research/malware-feed-accuracy/stage1_published_2026-10-24.json", d1 / "published_2026-10-24.json")

    # ---- code and reports at the commit
    shutil.copytree(code / "research/malware-feed-accuracy", out / "code")
    (out / "report").mkdir()
    for p in sorted((code / "docs").glob("malware-feed-accuracy*.md")):
        shutil.copy(p, out / "report" / p.name)
    shutil.copy(out / "code/archive-README.md", out / "README.md")

    leaks = check(out, original_keys, withheld)
    counts["withheld names"] = len(withheld)
    report = {"commit": commit, "counts": dict(counts), "leaks": leaks}
    write_json(out / "BUILD.json", {"commit": commit, "counts": dict(counts), "blocking_leaks": len(leaks["blocking"]),
                                    "names_for_review": len(leaks["review"])})
    return report


TOKEN = re.compile(r"[A-Za-z0-9@][A-Za-z0-9._@/-]*")


def strings(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k)
            yield from strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from strings(v)
    elif obj is not None:
        yield str(obj)


def dicts(obj):
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            yield from dicts(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from dicts(v)


def check(out: Path, original_keys: set[str], withheld: set[tuple[str, str]]) -> dict:
    """Blocking: an original key anywhere, or a withheld (ecosystem, name) pair in a data row outside
    the malicious stage 3 set. For review: a withheld name as any other string (another ecosystem's
    package of the same name, a malware sample that a feed also flagged, a word in a report)."""
    names = {n for _, n in withheld}
    block, review = Counter(), Counter()
    for path in sorted(out.rglob("*")):
        if not path.is_file():
            continue
        rel = str(path.relative_to(out))
        text = path.read_text(encoding="utf-8", errors="replace")
        for k in original_keys:
            if k in text:
                block[f"{rel}: original key"] += 1
        if rel.startswith(("stage1/", "stage2/", "stage3/")) and path.suffix in (".json", ".jsonl"):
            docs = [json.loads(line) for line in text.splitlines() if line.strip()] if path.suffix == ".jsonl" else [json.loads(text)]
            for d in (d for doc in docs for d in dicts(doc)):
                if (d.get("ecosystem"), d.get("name")) in withheld:
                    malicious_set = rel.startswith("stage3/") and "malicious" in rel
                    (review if malicious_set else block)[f"{rel}: {d['ecosystem']}/{d['name']}"] += 1
            for value in (v for doc in docs for v in strings(doc)):
                if value in names:
                    review[f"{rel}: {value}"] += 1
        else:
            for tok in set(TOKEN.findall(text)):
                if tok in names:
                    review[f"{rel}: {tok}"] += 1
    return {"blocking": dict(block), "review": dict(review)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--study", type=Path, required=True)
    ap.add_argument("--code", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--commit", required=True)
    args = ap.parse_args()
    report = build(args.study, args.code, args.out, args.commit)
    sums = []
    for path in sorted(args.out.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS":
            sums.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(args.out)}")
    (args.out / "SHA256SUMS").write_text("\n".join(sums) + "\n")
    print(json.dumps(report, indent=1, ensure_ascii=False))
    return 1 if report["leaks"]["blocking"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
