#!/usr/bin/env python3
"""Stage 2 sample, as METHODOLOGY.md's stage 2 protocol fixes it.

Frame: stage 1 status rows that are `live`, of kind malicious (OpenSSF) or static-rule (Vulnetix),
flagged more than 30 days before the check. Every row of a stratum with at most 50 rows, else 50
at random (seed 20261025). One line per package to review, with the strata it counts in and the
version to fetch (the newest flagged version still served; the latest when the record names none).

    python3 -I stage2_sample.py records.jsonl status.jsonl > stage2_sample.jsonl
"""

from __future__ import annotations

import json
import random
import sys
from collections import defaultdict
from datetime import datetime

CAP, SEED, MIN_AGE_DAYS = 50, 20261025, 30


def days(a: str, b: str) -> float:
    pa = datetime.fromisoformat(a.replace("Z", "+00:00"))
    pb = datetime.fromisoformat(b.replace("Z", "+00:00"))
    return (pb - pa).total_seconds() / 86400


def vkey(v: str):
    out = []
    for part in v.replace("-", ".").split("."):
        out.append((0, int(part)) if part.isdigit() else (1, part))
    return out


def main() -> int:
    records = {}
    for line in open(sys.argv[1]):
        r = json.loads(line)
        records[(r["feed"], r["id"], r["name"])] = r
    strata = defaultdict(list)
    for line in open(sys.argv[2]):
        s = json.loads(line)
        if s["status"] != "live" or s["kind"] not in ("malicious", "static-rule"):
            continue
        rec = records.get((s["feed"], s["id"], s["name"]))
        if not rec or not rec["published"] or days(rec["published"], s["checked_at"]) <= MIN_AGE_DAYS:
            continue
        strata[(s["feed"], s["source"], s["ecosystem"])].append((s, rec))
    rng = random.Random(SEED)
    packages: dict[tuple[str, str], dict] = {}
    for key in sorted(strata):
        rows = sorted(strata[key], key=lambda x: (x[0]["name"], x[0]["id"]))
        picked = rows if len(rows) <= CAP else rng.sample(rows, CAP)
        for s, rec in picked:
            pk = (s["ecosystem"], s["name"])
            entry = packages.setdefault(pk, {"ecosystem": s["ecosystem"], "name": s["name"], "flagged": set(), "strata": []})
            entry["strata"].append({"feed": key[0], "source": key[1], "ecosystem": key[2], "id": s["id"],
                                    "stratum_frame": len(rows), "sampled_in_stratum": len(picked)})
            if isinstance(rec["versions"], list):
                entry["flagged"].update(rec["versions"])
    for entry in packages.values():
        flagged = sorted(entry.pop("flagged"), key=vkey)
        entry["flagged_versions"] = flagged
        entry["fetch"] = "newest-served-of:" + ",".join(flagged) if flagged else "latest"
        sys.stdout.write(json.dumps(entry) + "\n")
    print(f"{len(packages)} packages from {sum(len(v) for v in strata.values())} frame rows in {len(strata)} strata",
          file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
