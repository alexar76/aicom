#!/usr/bin/env python3
"""Stage 2: which sample packages need adjudication, and the 10% audit draw of agreed labels.

Adjudication: R1 and R2 disagree, either says inconclusive, or either gave no label.
Audit: every adjudicated package plus 10% of the agreed ones, drawn at random (seed 20261028).
Writes the key lists only; nothing here shows which tool flagged a package.

    python3 -I stage2_audit.py --ratings ratings_counted.jsonl --keymap keymap_sample.json \
        --r1 R1 --r2 R2 --out-dir DIR
"""

from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ratings", required=True)
    ap.add_argument("--keymap", required=True)
    ap.add_argument("--r1", default="R1")
    ap.add_argument("--r2", default="R2")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--exclude", help="keys with no bundle (removed or unreadable): reported apart")
    args = ap.parse_args()
    km = json.load(open(args.keymap))
    labels: dict[str, dict[str, str]] = {}
    for line in open(args.ratings):
        r = json.loads(line)
        if r["key"] in km and r.get("label"):
            labels.setdefault(r["key"], {})[r["rater"]] = r["label"]
    skip = {line.strip() for line in open(args.exclude) if line.strip()} if args.exclude else set()
    sample = sorted(k for k, v in km.items() if v.get("role") == "sample" and k not in skip)
    adjudicate, agreed = [], []
    for key in sample:
        got = labels.get(key, {})
        a, b = got.get(args.r1), got.get(args.r2)
        if a and b and a == b and a != "inconclusive":
            agreed.append(key)
        else:
            adjudicate.append(key)
    rng = random.Random(20261028)
    audit_agreed = sorted(rng.sample(agreed, math.ceil(len(agreed) * 0.10)))
    out = Path(args.out_dir)
    (out / "keys_adjudicate.txt").write_text("\n".join(adjudicate) + "\n")
    (out / "keys_audit_agreed.txt").write_text("\n".join(audit_agreed) + "\n")
    print(json.dumps({"sample_with_bundle": len(sample), "agreed": len(agreed), "adjudicate": len(adjudicate),
                      "audit_agreed": len(audit_agreed)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
