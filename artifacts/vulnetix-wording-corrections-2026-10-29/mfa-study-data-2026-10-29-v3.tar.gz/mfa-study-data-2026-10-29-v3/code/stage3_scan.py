#!/usr/bin/env python3
"""Stage 3: run one scanner over every unpacked package of a set; one JSONL line per package.

Runs on the isolated sandbox host inside the scanner's gVisor container, with no network. What
counts as a flag is fixed in METHODOLOGY.md before the run:

    guarddog   any threat-* or metadata heuristic; capability-* rules are kept but are not flags
    baseline   an install-time hook that makes a network call or starts a process (pitfall P6)
    malcontent the per-file JSON of `mal --format json scan DIR`, folded per package; flag at HIGH+
    ossgadget  `ossgadget detect-backdoor --format sarifv2` per package (s3_ossgadget.sh); any result

    python3 stage3_scan.py guarddog   SET_DIR manifest.jsonl > out.jsonl
    python3 stage3_scan.py baseline   SET_DIR manifest.jsonl > out.jsonl
    python3 stage3_scan.py malcontent SET_DIR manifest.jsonl mal.json > out.jsonl
    python3 stage3_scan.py ossgadget  SET_DIR manifest.jsonl SARIF_DIR > out.jsonl
"""

from __future__ import annotations

import json
from collections import Counter
import re
import subprocess
import sys
import time
from pathlib import Path

TIMEOUT = 300
NET = re.compile(r"https?://|\bfetch\(|\brequire\(['\"](?:https?|net|dns|axios|node-fetch|request)['\"]\)|urllib|requests\.|http\.client|"
                 r"socket\.|\bcurl\b|\bwget\b|Invoke-WebRequest", re.I)
PROC = re.compile(r"child_process|\bexecSync\b|\bspawn\(|\bexec\(|subprocess|os\.system|os\.popen|\bsh -c\b|\bbash\b|powershell", re.I)
HOOKS = ("preinstall", "install", "postinstall")


def manifest(path: str) -> list[dict]:
    return [json.loads(line) for line in open(path) if line.strip() and not json.loads(line).get("error")]


def guarddog(set_dir: Path, rows: list[dict]) -> None:
    for row in rows:
        out = {"key": row["key"], "scanner": "guarddog"}
        start = time.time()
        try:
            proc = subprocess.run(["guarddog", row["ecosystem"], "scan", str(set_dir / row["key"]), "--output-format", "json",
                                   "--no-sandbox"], capture_output=True, text=True, timeout=TIMEOUT)
            doc = json.loads(proc.stdout or "{}")
            hits = {k: (len(v) if isinstance(v, (list, dict)) else 1) for k, v in (doc.get("results") or {}).items() if v}
            threats = {k: v for k, v in hits.items() if not k.startswith("capability-")}
            out.update({"outcome": "flag" if threats else "clean", "rules": threats,
                        "capabilities": {k: v for k, v in hits.items() if k.startswith("capability-")}, "errors": doc.get("errors")})
        except subprocess.TimeoutExpired:
            out["outcome"] = "timeout"
        except (ValueError, OSError) as exc:
            out.update({"outcome": "error", "error": str(exc)[:200]})
        out["seconds"] = round(time.time() - start, 1)
        print(json.dumps(out), flush=True)


def baseline(set_dir: Path, rows: list[dict]) -> None:
    for row in rows:
        root = set_dir / row["key"]
        reasons = []
        for pj in root.rglob("package.json"):
            if "node_modules" in pj.parts:
                continue
            try:
                scripts = json.loads(pj.read_text(errors="replace")).get("scripts") or {}
            except ValueError:
                continue
            for hook in HOOKS:
                cmd = str(scripts.get(hook) or "")
                if not cmd:
                    continue
                text = cmd
                for ref in re.findall(r"[\w./-]+\.(?:js|cjs|mjs|sh|py)", cmd):
                    target = pj.parent / ref
                    if target.is_file():
                        text += "\n" + target.read_text(errors="replace")[:200_000]
                if NET.search(text) or PROC.search(text):
                    reasons.append(f"npm {hook}")
        for sp in root.rglob("setup.py"):
            text = sp.read_text(errors="replace")[:200_000]
            if NET.search(text) or PROC.search(text):
                reasons.append("setup.py")
        print(json.dumps({"key": row["key"], "scanner": "baseline", "outcome": "flag" if reasons else "clean", "rules": reasons}), flush=True)


def malcontent(set_dir: Path, rows: list[dict], report: str, errlog: str | None = None) -> None:
    """The report lists only files with a behaviour, so a package absent from it was read and found
    clean. A file malcontent could not open is logged to stderr (errlog); its package is marked
    partial (read_errors), never silently clean or dirty."""
    doc = json.loads(Path(report).read_text() or "{}")
    unread: Counter = Counter()
    if errlog and Path(errlog).exists():
        for m in re.finditer(r'path=/data/([0-9a-f]{12})/', Path(errlog).read_text(errors="replace")):
            unread[m.group(1)] += 1
    files = doc.get("Files") or doc.get("files") or {}
    risk_of = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    best: dict[str, tuple[int, list]] = {}
    for path, info in files.items():
        rel = Path(path).as_posix().split(str(set_dir.as_posix()).rstrip("/") + "/", 1)[-1]
        key = rel.split("/", 1)[0]
        level = risk_of.get(str(info.get("RiskLevel") or info.get("risk_level") or "").upper(), int(info.get("RiskScore") or 0))
        behaviours = [b.get("ID") or b.get("RuleName") for b in (info.get("Behaviors") or []) if (b.get("RiskScore") or 0) >= 3]
        if key not in best or level > best[key][0]:
            best[key] = (level, behaviours[:20])
    for row in rows:
        level, rules = best.get(row["key"], (0, []))
        out = {"key": row["key"], "scanner": "malcontent", "outcome": "flag" if level >= 3 else "clean",
               "risk": level, "rules": rules}
        if unread[row["key"]]:
            out["read_errors"] = unread[row["key"]]
        print(json.dumps(out), flush=True)


def ossgadget(set_dir: Path, rows: list[dict], sarif_dir: str) -> None:
    """Fold `ossgadget detect-backdoor --format sarifv2`, run once per package by s3_ossgadget.sh:
    <key>.sarif is its output and <key>.rc its exit code (124 = the 300 s timeout). Any result is a
    flag (the protocol: "any backdoor finding"); rules are the BD rule ids with their titles."""
    base = Path(sarif_dir)
    for row in rows:
        out = {"key": row["key"], "scanner": "ossgadget"}
        rc_file, sarif = base / f"{row['key']}.rc", base / f"{row['key']}.sarif"
        rc = rc_file.read_text().strip() if rc_file.exists() else ""
        if rc == "124":
            out["outcome"] = "timeout"
        elif not sarif.exists() or not sarif.stat().st_size:
            out.update({"outcome": "error", "error": f"no SARIF (exit {rc or '?'})"})
        else:
            try:
                results = json.loads(sarif.read_text(errors="replace"))["runs"][0]["results"]
            except (ValueError, KeyError, IndexError) as exc:
                out.update({"outcome": "error", "error": f"unreadable SARIF: {exc}"[:200]})
            else:
                rules: dict[str, int] = {}
                for r in results:
                    rid = f"{(r.get('rule') or {}).get('id') or '?'} {(r.get('message') or {}).get('text') or ''}".strip()
                    rules[rid] = rules.get(rid, 0) + 1
                out.update({"outcome": "flag" if results else "clean", "rules": rules})
        print(json.dumps(out), flush=True)


def main() -> int:
    mode, set_dir, man = sys.argv[1], Path(sys.argv[2]), sys.argv[3]
    rows = manifest(man)
    if mode == "guarddog":
        guarddog(set_dir, rows)
    elif mode == "baseline":
        baseline(set_dir, rows)
    elif mode == "malcontent":
        malcontent(set_dir, rows, sys.argv[4], sys.argv[5] if len(sys.argv) > 5 else None)
    elif mode == "ossgadget":
        ossgadget(set_dir, rows, sys.argv[4])
    else:
        sys.exit(f"unknown mode {mode}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
