"""Transparency, part C: a compact reading list of the candidate issues of one tracker, for the
analyst to classify (is it a dispute of a record, which record, how did it end).

    python3 disputes_dossier.py ISSUES_DIR OWNER/REPO > dossier.txt

ISSUES_DIR holds <owner>_<repo>.json.jsonl (the issue list), candidates.tsv and comments/, events/
per issue, as fetched read-only from the public GitHub API.
"""
import json
import re
import sys

T, REPO = sys.argv[1], sys.argv[2]


def flat(s, n):
    return re.sub(r"\s+", " ", s or "")[:n]


idx = {}
for line in open(f"{T}/{REPO.replace('/', '_')}.json.jsonl", encoding="utf-8"):
    r = json.loads(line)
    idx[r["number"]] = r
for line in open(f"{T}/candidates.tsv", encoding="utf-8"):
    repo, num = line.split()
    if repo != REPO:
        continue
    k = f"{repo.replace('/', '_')}_{num}"
    r = idx[int(num)]
    cs = json.load(open(f"{T}/comments/{k}.json", encoding="utf-8"))
    ev = json.load(open(f"{T}/events/{k}.json", encoding="utf-8"))
    au = r["user"]["login"]
    first = next((c for c in cs if c["user"]["login"] != au), None)
    clos = [e for e in ev if e["event"] == "closed"]
    refs = sum(e["event"] in ("referenced", "cross-referenced", "connected") for e in ev)
    print(f"#{num} {r['created_at'][:10]} by {au}: {flat(r['title'], 110)}")
    print(f"   body: {flat(r['body'], 260)}")
    if first:
        print(f"   first other: {first['user']['login']} {first['created_at'][:10]}: {flat(first['body'], 160)}")
    who = [e["actor"]["login"] for e in clos if e.get("actor")]
    print(f"   state {r['state']} {r.get('state_reason')} closed {str(r.get('closed_at'))[:10]} by {who} "
          f"by-commit {[bool(e.get('commit_id')) for e in clos]} refs {refs}")
    if cs and cs[-1] is not first:
        print(f"   last: {cs[-1]['user']['login']} {cs[-1]['created_at'][:10]}: {flat(cs[-1]['body'], 160)}")
