#!/usr/bin/env python3
"""Stage 3: unpack every package of a set into its own directory, never installing or importing it.

Runs on the isolated sandbox host in a gVisor container (with network for registry sets, without
for the DataDog archives). Reuses stage2_bundle.py's download, unpack and control normalisation, so
a malicious sample and a registry download end up in the same layout.

    python3 stage3_fetch.py SET_NAME OUT_DIR < jobs.jsonl > manifest.jsonl
    job: {"key","ecosystem","name","version"} (registry) or {...,"archive","password"} (DataDog)
"""

from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import stage2_bundle as b  # noqa: E402


def main() -> int:
    set_name, out_dir = sys.argv[1], Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)
    for line in sys.stdin:
        job = json.loads(line)
        row = {"set": set_name, "key": job["key"], "ecosystem": job["ecosystem"], "name": job["name"]}
        dest = out_dir / job["key"]
        try:
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp) / "x"
                root.mkdir()
                if job.get("archive"):
                    b.unpack(Path(job["archive"]).read_bytes(), job["archive"], root, job.get("password"))
                    root, meta = b.normalise_control(root, job)
                else:
                    spec = f"newest-served-of:{job['version']}" if job.get("version") else "latest"
                    got = (b.pypi_artifact if job["ecosystem"] == "pypi" else b.npm_artifact)(job["name"], spec)
                    if got is None or got[2] is None:
                        raise RuntimeError("version not served")
                    version, meta, blob, fname = got
                    b.unpack(blob, fname, root)
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(root, dest)
                (dest.parent / f"{job['key']}.meta.json").write_text(json.dumps(meta))
                row.update({"version": meta.get("version"), "files": sum(1 for p in dest.rglob("*") if p.is_file())})
        except Exception as exc:  # noqa: BLE001 - one bad package must not stop the set
            row["error"] = f"{type(exc).__name__}: {exc}"[:300]
        print(json.dumps(row), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
