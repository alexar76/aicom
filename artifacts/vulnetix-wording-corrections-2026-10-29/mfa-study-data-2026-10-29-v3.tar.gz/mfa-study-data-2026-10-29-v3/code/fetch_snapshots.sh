#!/usr/bin/env bash
# The two stage 1 feed snapshots at the commits pinned in METHODOLOGY.md, with the same sparse paths
# as its "Reproduce" section. Run from this folder.
set -euo pipefail
fetch() { # dir url sha path...
  local dir=$1 url=$2 sha=$3; shift 3
  rm -rf "$dir"
  git init -q "$dir"
  git -C "$dir" remote add origin "$url"
  git -C "$dir" sparse-checkout init --cone
  git -C "$dir" sparse-checkout set "$@"
  git -C "$dir" fetch -q --depth 1 --filter=blob:none origin "$sha"
  git -C "$dir" checkout -q FETCH_HEAD
  echo "$dir at $(git -C "$dir" rev-parse HEAD)"
}
fetch ossf https://github.com/ossf/malicious-packages ef188da1c8d1af253a585af8362997df142e1f36 osv/malicious osv/withdrawn
fetch vulnetix https://github.com/Vulnetix/advisory-database a21bd56f5a257df6016129a3e164553722267da6 vulnetix/PYPI vulnetix/NPM index
