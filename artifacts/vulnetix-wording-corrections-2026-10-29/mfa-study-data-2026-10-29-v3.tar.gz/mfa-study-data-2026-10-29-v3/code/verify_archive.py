#!/usr/bin/env python3
"""Recompute the study's numbers from the data archive alone and compare them with the results the
archive carries (made from the full data before anything was withheld).

    python3 -I verify_archive.py ARCHIVE_DIR

Stage 1: registry action per stratum, against the published 2026-10-24 counts (stage1_compare.py).
Stage 2: final labels, rates per tool with and without withdrawn records, Cohen's kappa, held-out
controls (stage2_score.py). Stage 3: every scanner number (stage3_score.py). Exit 0 when all match.
Standard library only.
"""
from __future__ import annotations

import ast
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path


def run(code: Path, *args: str) -> str:
    return subprocess.run([sys.executable, "-I", str(code / args[0]), *args[1:]], check=True,
                          capture_output=True, text=True).stdout


SAMPLE = re.compile(r"^Sample: (\{.*\}); ", re.M)


def sample_line(text: str):
    """stage2_score.py prints its tally as a dict whose order follows string hashing, which changes
    from one process to the next: compare it as a dict, the rest of the text as it is."""
    m = SAMPLE.search(text)
    return ast.literal_eval(m.group(1)), SAMPLE.sub("Sample: {}; ", text)


def top_rules(obj):
    """stage3_score.py keeps the 15 most frequent rules; rules tied at the cut are kept in the order
    rows come in, and the archive's rows are ordered by their random ids. Compare every count, and
    the rules above the cut."""
    if isinstance(obj, dict):
        if len(obj.get("flags_by_rule") or {}) >= 15:
            rules = obj["flags_by_rule"]
            cut = min(rules.values(), default=0)
            obj = {**obj, "flags_by_rule": {"above_cut": {k: v for k, v in rules.items() if v > cut},
                                            "counts": sorted(rules.values())}}
        return {k: top_rules(v) for k, v in obj.items()}
    return obj


def main() -> int:
    a = Path(sys.argv[1])
    code, s1, s2, s3 = a / "code", a / "stage1", a / "stage2", a / "stage3"
    ok = True
    with tempfile.TemporaryDirectory() as tmp:
        t = Path(tmp)

        run(code, "stage1_compare.py", "--published", str(s1 / "published_2026-10-24.json"),
            "--now", str(s1 / "sample_status_2026-10-27.jsonl"), "--json", str(t / "s1.json"))
        same = json.loads((t / "s1.json").read_text()) == json.loads((s1 / "compare_2026-10-24_vs_2026-10-27.json").read_text())
        print("stage 1, registry action per stratum vs 2026-10-24:", "same" if same else "DIFFERENT")
        ok &= same

        common = ["--ratings", str(s2 / "ratings_counted.jsonl"), "--r1", "R1", "--r2", "R2"]
        text = run(code, "stage2_score.py", "final", *common, "--keymaps", str(s2 / "keymap_sample.json"),
                   "--adjudications", str(s2 / "adjudications.jsonl"), "--audit", str(s2 / "audit_analyst.jsonl"),
                   "--held", str(s2 / "keys_held_2026-10-27.txt"), "--frames", str(s2 / "frames_published.jsonl"),
                   "--withdrawn", str(s2 / "withdrawn_ids.txt"), "--json", str(t / "s2.json"))
        got, want = json.loads((t / "s2.json").read_text()), json.loads((s2 / "results_restored.json").read_text())
        same = all(got[k] == want[k] for k in ("final", "per", "per_current", "how"))
        same_text = sample_line(text) == sample_line((s2 / "results_final_restored.txt").read_text())
        print("stage 2, labels and rates:", "same" if same else "DIFFERENT", "| printed tables:", "same" if same_text else "DIFFERENT")
        ok &= same and same_text
        text = run(code, "stage2_score.py", "controls", *common,
                   "--keymaps", str(s2 / "keymap_controls_mal.json"), str(s2 / "keymap_controls_ben.json"))
        same = text == (s2 / "results_controls_restored.txt").read_text()
        print("stage 2, held-out controls:", "same" if same else "DIFFERENT")
        ok &= same

        got = json.loads(run(code, "stage3_score.py", str(s3), str(s3), "--volumes", str(s3 / "stage3_volumes.json")))
        want = json.loads((s3 / "results_restored.json").read_text())
        norm = lambda flags: sorted((f["scanner"], f["key"], f["ecosystem"], json.dumps(f.get("rules"), sort_keys=True))  # noqa: E731
                                    for f in flags)
        same = (all(top_rules(got[k]) == top_rules(want[k]) for k in ("volumes", "sets", "scanners"))
                and norm(got["benignB_flags"]) == norm(want["benignB_flags"]))
        print("stage 3, every scanner number:", "same" if same else "DIFFERENT")
        ok &= same
    print("ALL SAME" if ok else "MISMATCH")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
