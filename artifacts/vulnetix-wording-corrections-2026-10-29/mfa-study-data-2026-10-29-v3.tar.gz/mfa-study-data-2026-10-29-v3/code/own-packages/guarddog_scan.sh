#!/bin/bash
# GuardDog over our own packages: latest version of each, plus the versions Vulnetix flagged.
D="$(dirname "$0")"; out="${1:-guarddog-results.jsonl}"; : > "$out"
scan(){ eco="$1"; name="$2"; ver="$3"
  args=(); [ -n "$ver" ] && args=(--version "$ver")
  res=$(guarddog "$eco" scan "$name" "${args[@]}" --output-format json 2>/dev/null)
  printf '%s' "$res" | python3 -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: d={'error':'no json'}
hit={k:(len(v) if isinstance(v,list) else (len(v) if isinstance(v,dict) else 1)) for k,v in (d.get('results') or {}).items() if v}
print(json.dumps({'eco':'$eco','name':'$name','version':'$ver' or 'latest','issues':d.get('issues'),'errors':d.get('errors'),'rules':hit}))" >> "$out"
}
while read -r n; do scan pypi "$n" ""; done < "$D/pypi.txt"
for nv in aimarket-hub:3.0.0 aimarket-mcp:0.4.0 aimarket-hestia:0.1.0 aimarket-hestia-agents:0.1.1 aimarket-emporion:0.1.0 aimarket-signal-hunt:0.1.1 aimarket-histor:0.2.0 helios-broadcast:0.2.0 skopos-fleet:0.2.0; do scan pypi "${nv%%:*}" "${nv##*:}"; done
while read -r n; do scan npm "$n" ""; done < "$D/npm.txt"
echo "done $(wc -l < "$out")"
