#!/bin/sh
# s3_scan_set.sh SET : baseline, malcontent and GuardDog (3 shards) over one unpacked set, no network.
set -e
S="$1"; W=/root/mfa-study; O=$W/s3/out; mkdir -p $O
RUN="docker run --rm --runtime=runsc --network=none --memory=3g --memory-swap=3g --cpus=1 --pids-limit=512"
$RUN -v $W:/w:ro histor-python:3.12 python3 /w/stage3_scan.py baseline /w/s3/$S /w/s3/manifest_$S.jsonl > $O/baseline_$S.jsonl
$RUN -v $W/s3/$S:/data:ro cgr.dev/chainguard/malcontent:latest --format json scan /data > $O/mal_$S.json 2> $O/mal_$S.err || true
$RUN -v $W:/w:ro -v $O:/o:ro histor-python:3.12 python3 /w/stage3_scan.py malcontent /data /w/s3/manifest_$S.jsonl /o/mal_$S.json /o/mal_$S.err > $O/malcontent_$S.jsonl
grep -v "\"error\"" $W/s3/manifest_$S.jsonl | split -n l/3 - $O/shard_${S}_
for sh in $O/shard_${S}_*; do
  $RUN -v $W:/w:ro -v $O:/o:ro mfa-py-scanners:1 python3 /w/stage3_scan.py guarddog /w/s3/$S /o/$(basename $sh) > $sh.guarddog.jsonl &
done
wait
cat $O/shard_${S}_*.guarddog.jsonl > $O/guarddog_$S.jsonl
echo "done $S"
