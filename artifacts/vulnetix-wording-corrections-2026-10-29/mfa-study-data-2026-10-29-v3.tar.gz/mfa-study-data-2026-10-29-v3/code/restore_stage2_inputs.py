# -*- coding: utf-8 -*-
"""Rebuild run 1's stage 2 scoring inputs, lost on 2026-10-27, from what survived.

- adjudications.jsonl and audit_analyst.jsonl: every adj.sh / audit.sh call, replayed in order from
  the session log (each call appended one row; the scorer keeps the last row per key);
- keymap_sample.json: keys sha256("20261025|eco|name")[:12] (run 1's formula, from the log); each
  package's strata are its rows in the rebuilt stage 1 sample of kind malicious or static-rule,
  flagged more than 30 days before run 1's first registry check (a package in the stage 2 sample was
  live as a whole, so every such row was in a frame);
- withdrawn_ids.txt from the rebuilt records.

    python3 restore_stage2_inputs.py LOG SAMPLE_PLAN RECORDS BUNDLE_NAMES OUT_DIR OVERRIDES
"""
import hashlib
import json
import re
import shlex
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

LOG, PLAN, RECORDS, NAMES, OUT, OVERRIDES = sys.argv[1:7]
out = Path(OUT); out.mkdir(parents=True, exist_ok=True)
CHECK_V1 = datetime(2026, 10, 24, 11, 45, tzinfo=timezone.utc)  # run 1's first registry check, ~11:4x Z
FRAME_AT_FIXING = {("amazon-inspector", "npm"): 24, ("amazon-inspector", "pypi"): 45, ("ghsa-malware", "npm"): 35,
                   ("google-open-source-security", "npm"): 13, ("ossf-package-analysis", "npm"): 16,
                   ("ossf-package-analysis", "pypi"): 2, ("checkmarx", "npm"): 1, ("kam193", "pypi"): 1,
                   ("unknown", "npm"): 54, ("vulnetix", "npm"): 145, ("vulnetix", "pypi"): 170}

# 1. adjudication and audit calls, in the order they ran (tool results are checked for errors)
calls, results = [], {}
for line in open(LOG, encoding="utf-8", errors="replace"):
    d = json.loads(line)
    c = d.get("message", {}).get("content")
    if not isinstance(c, list):
        continue
    for x in c:
        if isinstance(x, dict) and x.get("type") == "tool_result":
            results[x.get("tool_use_id")] = bool(x.get("is_error"))
        if isinstance(x, dict) and x.get("type") == "tool_use":
            cmd = (x.get("input") or {}).get("command") or ""
            if ("adj.sh" in cmd or "audit.sh" in cmd) and (d.get("timestamp") or "") < "2026-10-26":
                calls.append((d.get("timestamp"), x.get("id"), cmd))
calls.sort()
adj, aud, skipped = [], [], 0
CALL = re.compile(r'(?P<who>\$A|/adj\.sh|/audit\.sh)\s+(?P<key>[0-9a-f]{12})\s+(?P<label>[a-z]+)\s+"(?P<reason>(?:[^"\\]|\\.)*)"')
ASSIGN = re.compile(r'(?:^|[\s;])A=(?P<path>\S+)')
for ts, tid, cmd in calls:
    if results.get(tid):
        skipped += 1
    assigns = [(m.start(), "audit" if "audit.sh" in m.group("path") else "adj") for m in ASSIGN.finditer(cmd)]
    for m in CALL.finditer(cmd):
        who = m.group("who")
        if who == "$A":
            prior = [w for pos, w in assigns if pos < m.start()]
            target = prior[-1] if prior else None
        else:
            target = "audit" if "audit" in who else "adj"
        if target is None:
            continue
        reason = re.sub(r'\\(.)', r'\1', m.group("reason"))
        (adj if target == "adj" else aud).append({"key": m.group("key"), "label": m.group("label"), "reason": reason,
                                                  "by": "analyst", "at": ts})
# Two rows run 1 changed by hand. Their keys name packages (a key is a hash of the name, the salt is
# above), so they are data kept on the study's servers (OVERRIDES), not code: "drop", a row removed
# before re-adjudicating it (2026-10-24 15:36:36); "rewrite", an audit row rewritten in place.
over = json.load(open(OVERRIDES, encoding="utf-8"))
adj = [r for r in adj if not (r["key"] == over["drop"]["key"] and r["label"] == over["drop"]["label"])]
(out / "adjudications.jsonl").write_text("".join(json.dumps(r) + "\n" for r in adj))
for r in aud:
    if r["key"] == over["rewrite"]["key"]:
        r.update({f: over["rewrite"][f] for f in ("label", "reason", "at")})
(out / "audit_analyst.jsonl").write_text("".join(json.dumps(r) + "\n" for r in aud))
print("adjudication rows", len(adj), "keys", len({r['key'] for r in adj}), "| audit rows", len(aud),
      "keys", len({r['key'] for r in aud}), "| calls in errored tool runs", skipped)

# 2. keymap
def key(eco, name):
    return hashlib.sha256(f"20261025|{eco}|{name}".encode()).hexdigest()[:12]

plan = [json.loads(l) for l in open(PLAN)]
by_pkg = defaultdict(list)
for r in plan:
    by_pkg[(r["ecosystem"], r["name"])].append(r)
keys_wanted = {}
for line in open(NAMES):
    fn, eco, name, k = line.rstrip("\n").split("\t")
    if fn == "bundles_sample.jsonl":
        keys_wanted[k] = (eco, name)
by_key = {key(e, n): (e, n) for (e, n) in by_pkg}
km, unknown = {}, []
for k in keys_wanted:
    if k not in by_key:
        unknown.append(k); continue
    eco, name = by_key[k]
    strata = []
    for r in by_pkg[(eco, name)]:
        if r["kind"] not in ("malicious", "static-rule"):
            continue
        pub = r.get("published")
        try:
            t = datetime.fromisoformat(pub.replace("Z", "+00:00"))
        except (AttributeError, ValueError):
            continue
        if (CHECK_V1 - t).total_seconds() / 86400 <= 30:
            continue
        strata.append({"feed": r["feed"], "source": r["source"], "ecosystem": r["ecosystem"], "id": r["id"],
                       "stratum_frame": FRAME_AT_FIXING.get((r["source"], r["ecosystem"]))})
    versions = sorted({v for r in by_pkg[(eco, name)] if isinstance(r.get("versions"), list) for v in r["versions"]})
    km[k] = {"role": "sample", "ecosystem": eco, "name": name, "strata": strata, "flagged_versions": versions}
per = Counter((s["source"], s["ecosystem"]) for v in km.values() for s in v["strata"])
for v in km.values():
    for s in v["strata"]:
        s["sampled_in_stratum"] = per[(s["source"], s["ecosystem"])]
(out / "keymap_sample.json").write_text(json.dumps(km))
print("keymap", len(km), "of", len(keys_wanted), "bundle keys; keys not matched to the sample", unknown)
print("packages per stratum:", dict(per))

# 3. withdrawn record ids
ids = [json.loads(l)["id"] for l in open(RECORDS) if json.loads(l).get("withdrawn")]
(out / "withdrawn_ids.txt").write_text("\n".join(ids) + "\n")
print("withdrawn ids", len(ids))
