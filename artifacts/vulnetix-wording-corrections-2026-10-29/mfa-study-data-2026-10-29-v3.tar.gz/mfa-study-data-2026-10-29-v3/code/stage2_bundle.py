#!/usr/bin/env python3
"""Build the blind evidence bundle for one package: download, unpack, never install or import.

Runs on the isolated sandbox host, in a throwaway gVisor container. Input lines (JSONL) carry
{"key", "ecosystem", "name", "fetch"} or, for local control samples, {"key", "ecosystem", "name",
"version", "archive", "password"}. Output: one bundle per line with package metadata, the file
list, every install-time hook in full, the files hooks and entry points name, then files ranked by
density of risky calls, up to 60 KB. Nothing about feeds, tools or registry status goes in.

    python3 stage2_bundle.py < todo.jsonl > bundles.jsonl
"""

from __future__ import annotations

import io
import json
import re
import sys
import tarfile
import tempfile
import urllib.request
import zipfile
from pathlib import Path

BUDGET, PER_FILE, LINE_CAP = 60_000, 15_000, 400
UA = "malware-feed-accuracy-study/1.0 (+https://modelmarket.dev; evidence bundle, no install)"
TEXT_EXT = {".py", ".js", ".mjs", ".cjs", ".ts", ".json", ".toml", ".cfg", ".txt", ".md", ".sh", ".pth", ".yml",
            ".yaml", ".ps1", ".bat", ".cmd", ".rb", ".pl", ".php", ".html", ".in", ".ini", ".gyp", ".gypi", ""}
HOOK_NAMES = {"setup.py", "setup.cfg", "pyproject.toml", "package.json", "__init__.py", "install.js", "postinstall.js",
              "preinstall.js", "index.js", "main.py", "__main__.py", "binding.gyp"}
HEAD = 1_000_000  # a larger file is read from its start; clip() notes the cut
RISKY = re.compile(
    r"requests\.|urllib|http\.client|socket\.|fetch\(|axios|XMLHttpRequest|https?://|child_process|\bexec\w*\(|\beval\(|"
    r"subprocess|os\.system|popen|base64|atob\(|fromCharCode|Buffer\.from|process\.env|os\.environ|getenv|\.ssh|\.aws|"
    r"\.npmrc|\.pypirc|discord|telegram|webhook|wallet|keychain|crontab|LaunchAgents|\.bashrc|marshal\.loads|"
    r"compile\(|__import__|ctypes|powershell|curl |wget ", re.I)


def fetch(url: str, accept: str = "application/json") -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read(80_000_000)


def vkey(v: str):
    return [(0, int(p)) if p.isdigit() else (1, p) for p in re.split(r"[.\-+]", v)]


def pick_version(served: list[str], spec: str, latest: str | None) -> str | None:
    if spec.startswith("newest-served-of:"):
        wanted = [v for v in spec.split(":", 1)[1].split(",") if v in served]
        return max(wanted, key=vkey) if wanted else None
    return latest


def pypi_artifact(name: str, spec: str):
    doc = json.loads(fetch(f"https://pypi.org/pypi/{name}/json"))
    served = [v for v, files in doc["releases"].items() if files and not all(f.get("yanked") for f in files)]
    version = pick_version(served, spec, doc["info"]["version"])
    if not version:
        return None
    files = doc["releases"][version]
    files = sorted(files, key=lambda f: (f["packagetype"] != "sdist", f["size"]))  # sdist first: it has setup.py
    info = doc["info"]
    meta = {"name": info["name"], "version": version, "summary": info.get("summary"), "home_page": info.get("home_page"),
            "project_urls": info.get("project_urls"), "author": info.get("author"), "requires_dist": info.get("requires_dist"),
            "uploaded": files[0].get("upload_time_iso_8601") if files else None, "artifact": files[0]["filename"] if files else None}
    return version, meta, fetch(files[0]["url"], "*/*") if files else None, files[0]["filename"] if files else ""


def npm_artifact(name: str, spec: str):
    doc = json.loads(fetch("https://registry.npmjs.org/" + urllib.request.quote(name, safe="@")))
    served = list((doc.get("versions") or {}).keys())
    version = pick_version(served, spec, (doc.get("dist-tags") or {}).get("latest"))
    if not version:
        return None
    v = doc["versions"][version]
    meta = {"name": name, "version": version, "description": v.get("description"), "homepage": v.get("homepage"),
            "repository": v.get("repository"), "author": v.get("author"), "scripts": v.get("scripts"),
            "dependencies": v.get("dependencies"), "uploaded": (doc.get("time") or {}).get(version), "artifact": v["dist"]["tarball"]}
    return version, meta, fetch(v["dist"]["tarball"], "*/*"), "package.tgz"


def unpack(blob: bytes, filename: str, dest: Path, password: str | None = None) -> None:
    if filename.endswith((".zip", ".whl", ".egg")) or blob[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(blob)) as zf:
            for info in zf.infolist():
                target = (dest / info.filename).resolve()
                if not str(target).startswith(str(dest.resolve())) or info.is_dir() or info.file_size > 5_000_000:
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(zf.read(info, pwd=password.encode() if password else None))
        return
    with tarfile.open(fileobj=io.BytesIO(blob)) as tf:
        tf.extractall(dest, filter="data")


def normalise_control(root: Path, job: dict) -> tuple[Path, dict]:
    """Make a control sample look like a registry download: same metadata, same paths.

    DataDog's archives hold the package under tmp/tmpXXXX/<name>/, wheel members stored as
    <member>/<member>, and a package_info-<name>-<version>.json copy of the registry metadata. Left
    as they are, those three things tell a rater a bundle is a control. The metadata is read into the
    same fields a registry download gets, the file is removed, and the paths are rebuilt.
    """
    meta = {"name": job["name"], "version": job.get("version")}
    for info in root.rglob("package_info-*.json"):
        try:
            doc = json.loads(info.read_text(errors="replace"))
        except ValueError:
            doc = {}
        if job["ecosystem"] == "npm":
            v = (doc.get("versions") or {}).get(job.get("version")) or {}
            meta.update({"description": v.get("description"), "homepage": v.get("homepage"), "repository": v.get("repository"),
                         "author": v.get("author"), "scripts": v.get("scripts"), "dependencies": v.get("dependencies"),
                         "uploaded": (doc.get("time") or {}).get(job.get("version"))})
        else:
            i = doc.get("info") or {}
            meta.update({"summary": i.get("summary"), "home_page": i.get("home_page"), "project_urls": i.get("project_urls"),
                         "author": i.get("author"), "requires_dist": i.get("requires_dist")})
        info.unlink()
    clean = root.parent / (root.name + "-clean")
    for p in [p for p in root.rglob("*") if p.is_file()]:
        parts = list(p.relative_to(root).parts)
        if len(parts) > 3 and parts[0] == "tmp" and parts[1].startswith("tmp"):
            parts = parts[3:]  # tmp/tmpXXXX/<name>/
        half = len(parts) // 2
        if len(parts) % 2 == 0 and half and parts[:half] == parts[half:]:
            parts = parts[:half]  # <member>/<member>
        target = clean.joinpath(*parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            p.rename(target)
    return clean, meta


def is_text(p: Path) -> bool:
    # No size cap: a large file is excerpted from its start, never dropped (npm runs binding.gyp's
    # '<!(node index.js)' at install, and stage 2 found 4.5 MB loaders hidden behind the old cap).
    if p.suffix.lower() not in TEXT_EXT:
        return False
    try:
        return b"\x00" not in p.read_bytes()[:4096]
    except OSError:
        return False


def read_head(p: Path) -> tuple[str, int]:
    with open(p, errors="replace") as fh:
        return fh.read(HEAD), p.stat().st_size


def clip(text: str, size: int | None = None) -> str:
    lines = []
    for line in text.splitlines():
        lines.append(line if len(line) <= LINE_CAP else line[:LINE_CAP] + f" …[line cut, {len(line)} chars]")
    out = "\n".join(lines)
    if len(out) <= PER_FILE and not (size and size > HEAD):
        return out
    return out[:PER_FILE] + f"\n…[file cut, {size or len(text)} {'bytes' if size else 'chars'}]"


def bundle(root: Path, meta: dict) -> dict:
    files = sorted(p for p in root.rglob("*") if p.is_file())
    rel = lambda p: str(p.relative_to(root))  # noqa: E731
    listing = [f"{rel(p)} ({p.stat().st_size} B)" for p in files][:400]
    chosen: list[Path] = []
    named = set()
    for p in files:  # install hooks and entry files first, in full (within the per-file cap)
        if p.name in HOOK_NAMES or p.suffix == ".pth":
            chosen.append(p)
    for p in chosen:  # files a hook or package.json script names
        if p.name == "package.json":
            try:
                scripts = (json.loads(p.read_text(errors="replace")).get("scripts") or {})
            except ValueError:
                scripts = {}
            for cmd in scripts.values():
                for tok in re.findall(r"[\w./-]+\.(?:js|cjs|mjs|sh|py)", str(cmd)):
                    named.add(tok.split("/")[-1])
    chosen += [p for p in files if p.name in named and p not in chosen]
    rest = [p for p in files if p not in chosen and is_text(p)]
    rest.sort(key=lambda p: -len(RISKY.findall(read_head(p)[0][:200_000])) / max(1, p.stat().st_size) ** 0.5)
    excerpts, used = [], 0
    for p in chosen + rest:
        if not is_text(p):
            continue
        text = clip(*read_head(p))
        if used + len(text) > BUDGET:
            if used >= BUDGET * 0.9:
                break
            text = text[: BUDGET - used] + "\n…[budget reached]"
        excerpts.append({"path": rel(p), "text": text})
        used += len(text)
    return {"metadata": meta, "file_count": len(files), "files": listing, "excerpts": excerpts}


def main() -> int:
    for line in sys.stdin:
        job = json.loads(line)
        out = {"key": job["key"], "ecosystem": job["ecosystem"]}
        try:
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                if job.get("archive"):  # a local control sample (password-protected archive)
                    blob = Path(job["archive"]).read_bytes()
                    unpack(blob, job["archive"], root, job.get("password"))
                    root, meta = normalise_control(root, job)
                else:
                    got = (pypi_artifact if job["ecosystem"] == "pypi" else npm_artifact)(job["name"], job["fetch"])
                    if got is None:
                        out["error"] = "no flagged version served any more"
                        print(json.dumps(out), flush=True)
                        continue
                    version, meta, blob, fname = got
                    if blob is None:
                        out["error"] = "no files for this version"
                        print(json.dumps(out), flush=True)
                        continue
                    unpack(blob, fname, root)
                out.update(bundle(root, meta))
        except Exception as exc:  # noqa: BLE001 - one bad package must not stop the batch
            out["error"] = f"{type(exc).__name__}: {exc}"[:300]
        print(json.dumps(out), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
