#!/usr/bin/env python3
"""Stage 2 scoring, as METHODOLOGY.md fixes it.

    select   accuracy of every candidate on the selection controls, and the chosen pair
    controls accuracy of R1 and R2 on the held-out controls, with Cohen's kappa
    compare  agreement of every model with the first (expensive) pair on the same packages
    final    final labels and false-positive rates per tool, with Wilson intervals

Ground truth for controls comes from the key maps (control_malicious / control_benign). A rating
counts as correct only if its label is exactly the control's class; spam and inconclusive count as
wrong for accuracy and are shown apart.

    python3 -I stage2_score.py select  --ratings r.jsonl --keymaps km1.json km2.json
    python3 -I stage2_score.py controls --ratings r.jsonl --keymaps ... --r1 NAME --r2 NAME
    python3 -I stage2_score.py compare --ratings cheap.jsonl --first first1.jsonl first2.jsonl
    python3 -I stage2_score.py final   --ratings r.jsonl --keymaps sample.json --r1 NAME --r2 NAME
                                       [--adjudications adj.jsonl] [--audit audit.jsonl]
                                       [--held held.txt] [--frames frames.jsonl] [--withdrawn ids.txt]

Final label, in order: the audit's reading where it differs; an adjudication (disagreements, and
packages whose bundle the builder had shortened, even when the raters agreed); the raters' label
when they agree. Keys in --held (packages the corrected registry check finds held) leave the
frame and are counted apart; --frames (stage2_sample.py over the corrected status) gives the
frame sizes then.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter, defaultdict

PRICE_IN = {  # USD per input token on OpenRouter at fixing time, for the tie rule
    "deepseek/deepseek-v4.1-flash": 0.00000002, "z-ai/glm-5.3-flash": 0.0000000492, "qwen/qwen3.8-flash": 0.00000015,
    "minimax/minimax-m3.1-flash": 0.00000015, "z-ai/glm-5.3": 0.000000079,
}
VENDOR = lambda model: model.split("/")[0]  # noqa: E731
LABELS = ("malicious", "spam", "benign", "inconclusive")


def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return float("nan"), float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, max(0.0, c - h), min(1.0, c + h)


def fmt(k: int, n: int) -> str:
    p, lo, hi = wilson(k, n)
    return f"{k}/{n} = {100 * p:.1f}% ({100 * lo:.1f}–{100 * hi:.1f}%)" if n else "—"


def kappa(pairs: list[tuple[str, str]]) -> float:
    n = len(pairs)
    if not n:
        return float("nan")
    po = sum(a == b for a, b in pairs) / n
    ca, cb = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
    pe = sum(ca[x] * cb[x] for x in set(ca) | set(cb)) / (n * n)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def load(path: str) -> list[dict]:
    return [json.loads(line) for line in open(path) if line.strip()]


def truth(keymaps: list[str]) -> dict[str, dict]:
    out = {}
    for path in keymaps:
        out.update(json.load(open(path)))
    return out


def by_rater(ratings: list[dict]) -> dict[str, dict[str, dict]]:
    out: dict[str, dict[str, dict]] = defaultdict(dict)
    for r in ratings:
        if r.get("label") in LABELS:
            out[r["rater"]][r["key"]] = r
    return out


def cmd_select(args) -> None:
    km = truth(args.keymaps)
    ratings = load(args.ratings)
    rated = by_rater(ratings)
    # Every control in the half is in the denominator: a missing or failed answer is not a correct label.
    keys = [line.strip() for line in open(args.keys) if line.strip()] if args.keys else sorted(
        {r["key"] for r in ratings if km.get(r["key"], {}).get("role", "").startswith("control")})
    models = {r["rater"]: r["model"] for r in ratings}
    rows = []
    for rater in sorted(models):
        got = rated.get(rater, {})
        model = models[rater]
        correct = sum(k in got and got[k]["label"] == ("malicious" if km[k]["role"] == "control_malicious" else "benign") for k in keys)
        cost = sum(((r.get("usage") or {}).get("cost") or 0) for r in ratings if r["rater"] == rater)
        labels = Counter(got[k]["label"] if k in got else "no answer" for k in keys)
        rows.append((correct / max(1, len(keys)), -PRICE_IN.get(model, 1), rater, model, correct, len(keys), cost, labels))
    rows.sort(reverse=True)
    print("| Rank | Model | Correct | Labels | Cost |\n|---:|---|---|---|---:|")
    for i, (_, _, rater, model, c, n, cost, labels) in enumerate(rows, 1):
        print(f"| {i} | `{model}` | {fmt(c, n)} | {dict(labels)} | ${cost:.3f} |")
    chosen, vendors = [], set()
    for row in rows:
        if VENDOR(row[3]) not in vendors:
            chosen.append(row)
            vendors.add(VENDOR(row[3]))
        if len(chosen) == 2:
            break
    print("\nChosen: " + ", ".join(f"R{i}={r[2]} ({r[3]})" for i, r in enumerate(chosen, 1)))


def cmd_controls(args) -> None:
    km = truth(args.keymaps)
    rated = by_rater(load(args.ratings))
    keys = sorted(k for k in set(rated[args.r1]) | set(rated[args.r2]) if km.get(k, {}).get("role", "").startswith("control"))
    for rater in (args.r1, args.r2):
        got = rated[rater]
        ks = [k for k in keys if k in got]
        correct = sum(got[k]["label"] == ("malicious" if km[k]["role"] == "control_malicious" else "benign") for k in ks)
        for role in ("control_malicious", "control_benign"):
            sub = [k for k in ks if km[k]["role"] == role]
            ok = sum(got[k]["label"] == ("malicious" if role == "control_malicious" else "benign") for k in sub)
            print(f"{rater} {role}: {fmt(ok, len(sub))} labels {dict(Counter(got[k]['label'] for k in sub))}")
        print(f"{rater} all held-out controls: {fmt(correct, len(ks))}  -> {'passes' if correct >= 0.9 * len(ks) else 'BELOW'} the 90% bar")
    both = [(rated[args.r1][k]["label"], rated[args.r2][k]["label"]) for k in keys if k in rated[args.r1] and k in rated[args.r2]]
    print(f"Cohen's kappa R1 vs R2 on held-out controls: {kappa(both):.3f} (n={len(both)})")


def cmd_compare(args) -> None:
    first = by_rater([r for path in args.first for r in load(path)])
    cheap = by_rater(load(args.ratings))
    print("| Model | vs first R1 (agree / n) | vs first R2 (agree / n) |\n|---|---|---|")
    for rater, got in sorted(cheap.items()):
        model = next(iter(got.values()))["model"]
        cells = []
        for fr in ("R1", "R2"):
            ks = [k for k in got if k in first.get(fr, {})]
            cells.append(f"{sum(got[k]['label'] == first[fr][k]['label'] for k in ks)}/{len(ks)}")
        print(f"| `{model}` | {cells[0]} | {cells[1]} |")
    ks = [k for k in first.get("R1", {}) if k in first.get("R2", {})]
    print(f"\nFirst pair agree with each other: {sum(first['R1'][k]['label'] == first['R2'][k]['label'] for k in ks)}/{len(ks)}")


def cmd_final(args) -> None:
    km = truth(args.keymaps)
    rated = by_rater(load(args.ratings))
    adj = {r["key"]: r for r in load(args.adjudications)} if args.adjudications else {}
    audit = {r["key"]: r for r in load(args.audit)} if args.audit else {}
    held = {line.strip() for line in open(args.held) if line.strip()} if args.held else set()
    final, how = {}, Counter()
    for key in set(rated[args.r1]) | set(rated[args.r2]):
        if km.get(key, {}).get("role") != "sample":
            continue
        if key in held:
            how["held by the registry now (out of the frame)"] += 1
            continue
        a = rated[args.r1].get(key, {}).get("label")
        b = rated[args.r2].get(key, {}).get("label")
        agreed = a if a and a == b and a != "inconclusive" else None
        if key in adj:
            final[key] = adj[key]["label"]
            how["adjudicated" if not agreed else "adjudicated although agreed (bundle shortened)"] += 1
            if agreed and agreed != final[key]:
                how["agreed label changed by adjudication"] += 1
        elif agreed:
            final[key] = agreed
            how["agreed"] += 1
        else:
            final[key] = "pending"
            how["pending adjudication"] += 1
        if key in audit and audit[key]["label"] != final[key]:
            how[f"changed by the audit ({final[key]} -> {audit[key]['label']})"] += 1
            final[key] = audit[key]["label"]
    if audit:
        looked = [k for k in audit if k in final]
        how["audited"] = len(looked)
    pairs = [(rated[args.r1][k]["label"], rated[args.r2][k]["label"]) for k in final if k in rated[args.r1] and k in rated[args.r2]]
    print(f"Sample: {dict(how)}; Cohen's kappa R1 vs R2 on the sample: {kappa(pairs):.3f} (n={len(pairs)})\n")
    frames = {}
    if args.frames:
        for row in load(args.frames):
            for s in row["strata"]:
                frames[(s["source"], s["ecosystem"])] = s["stratum_frame"]
    per = defaultdict(Counter)
    for key, label in final.items():
        for s in km[key]["strata"]:
            per[(s["source"], s["ecosystem"])][label] += 1
            per[(s["source"], s["ecosystem"])]["_frame"] = frames.get(
                (s["source"], s["ecosystem"]), s["stratum_frame"])
    print("| Tool | Ecosystem | Frame | Reviewed | Malicious | Spam | Benign | Inconclusive | Pending | False-positive rate (benign / decided) |")
    print("|---|---|---:|---:|---:|---:|---:|---:|---:|---|")
    out = {}
    for (src, eco), c in sorted(per.items()):
        decided = c["malicious"] + c["spam"] + c["benign"]
        n = sum(v for k, v in c.items() if not k.startswith("_"))
        print(f"| {src} | {eco} | {c['_frame']} | {n} | {c['malicious']} | {c['spam']} | {c['benign']} | {c['inconclusive']} | "
              f"{c['pending']} | {fmt(c['benign'], decided)} |")
        out[f"{src}|{eco}"] = dict(c)
    # The sampler did not leave out records the feed has since withdrawn (found 2026-10-25, after
    # the results; METHODOLOGY.md, "Changes after the results"). A withdrawn record no longer flags
    # anything for a consumer of the feed, so the rate among the records still standing is shown
    # beside the one above, never instead of it.
    out_current = {}
    if args.withdrawn:
        gone = {line.strip() for line in open(args.withdrawn) if line.strip()}
        cur = defaultdict(Counter)
        for key, label in final.items():
            for s in km[key]["strata"]:
                cell = cur[(s["source"], s["ecosystem"])]
                cell["_withdrawn"] += s.get("id") in gone
                if s.get("id") not in gone:
                    cell[label] += 1
        print("\nRecords still standing (the feed has not withdrawn them):\n")
        print("| Tool | Ecosystem | Withdrawn, left out | Malicious | Spam | Benign | Inconclusive | False-positive rate (benign / decided) |")
        print("|---|---|---:|---:|---:|---:|---:|---|")
        for (src, eco), c in sorted(cur.items()):
            decided = c["malicious"] + c["spam"] + c["benign"]
            print(f"| {src} | {eco} | {c['_withdrawn']} | {c['malicious']} | {c['spam']} | {c['benign']} | "
                  f"{c['inconclusive']} | {fmt(c['benign'], decided)} |")
            out_current[f"{src}|{eco}"] = dict(c)
    if args.json:
        json.dump({"final": final, "per": out, "per_current": out_current, "how": dict(how)}, open(args.json, "w"), indent=1)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=("select", "controls", "compare", "final"))
    ap.add_argument("--ratings", required=True)
    ap.add_argument("--keymaps", nargs="*", default=[])
    ap.add_argument("--first", nargs="*", default=[])
    ap.add_argument("--r1")
    ap.add_argument("--r2")
    ap.add_argument("--adjudications")
    ap.add_argument("--audit")
    ap.add_argument("--held")
    ap.add_argument("--frames")
    ap.add_argument("--withdrawn", help="record ids the feeds have withdrawn, one per line")
    ap.add_argument("--json")
    ap.add_argument("--keys", help="the controls of this half, one key per line (denominator)")
    args = ap.parse_args()
    {"select": cmd_select, "controls": cmd_controls, "compare": cmd_compare, "final": cmd_final}[args.mode](args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
