"""Vulnetix's questions of 2026-10-29, answered from the study's own data (read only, no network).

  python3 -I vx_followup.py STUDY MANIFEST OUT

STUDY    the sandbox host's /root/mfa-study (read only)
MANIFEST Vulnetix/advisory-database index/manifest.json at a pinned commit (current class and state)
OUT      writable folder:
  summary.json         counts only (publishable)
  remaining_600.jsonl  the snapshot's npm/PyPI records not in the 2026-10-27 withdrawal index:
                       record id, ecosystem, published, current classification, state, modified (no names)
  private_stage2.jsonl the 100 rated Vulnetix records with name, versions, our label and the reading
                       behind it; for Vulnetix only, never published
"""
import json, sys, tarfile
from collections import Counter
from pathlib import Path

study, manifest_path, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])

def jsonl(path):
    return [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]

def tar_member(tgz, tail):
    t = tarfile.open(tgz)
    hits = [m for m in t.getmembers() if m.isfile() and (m.name.lstrip("./") == tail or m.name.endswith("/" + tail))]
    assert len(hits) == 1, (tgz, tail, [m.name for m in hits])
    return t.extractfile(hits[0]).read().decode("utf-8")

# The stage 1 snapshot's Vulnetix records (a21bd56f5a25, 2026-10-24).
vx = [r for r in jsonl(study / "stage1/records_ov.jsonl") if r.get("feed") == "vulnetix"]
eco_of = {r["id"]: r["ecosystem"] for r in vx}
pub_of = {r["id"]: r.get("published") for r in vx}

w27 = json.load(open(study / "transparency/vulnetix_withdrawn_2026-10-27.json"))
w27_ids = {r["id"]: r for r in w27["records"]}
man = {r["id"]: r for r in json.load(open(manifest_path))["records"]}

withdrawn = [i for i in eco_of if i in w27_ids]
remaining = sorted(i for i in eco_of if i not in w27_ids)
summary = {
    "snapshot_records": len(eco_of),
    "snapshot_by_ecosystem": dict(Counter(eco_of.values())),
    "withdrawn_in_2026_10_27_index": len(withdrawn),
    "withdrawn_modified_dates": dict(Counter(str(w27_ids[i].get("modified", ""))[:10] for i in withdrawn)),
    "remaining": len(remaining),
    "remaining_by_ecosystem": dict(Counter(eco_of[i] for i in remaining)),
    "remaining_now": dict(Counter(f"{man[i]['classification']}/{man[i]['state']}" if i in man else "absent" for i in remaining)),
    "withdrawn_now": dict(Counter(f"{man[i]['classification']}/{man[i]['state']}" if i in man else "absent" for i in withdrawn)),
}
with open(out / "remaining_600.jsonl", "w", encoding="utf-8") as f:
    for i in remaining:
        m = man.get(i, {})
        f.write(json.dumps({"id": i, "ecosystem": eco_of[i], "published": pub_of[i],
                            "classification_now": m.get("classification"), "state_now": m.get("state"),
                            "modified_now": m.get("modified")}) + "\n")

# Stage 2: the rated Vulnetix records.
s2r = study / "stage2-restored-2026-10-27.tgz"
keymap = json.loads(tar_member(s2r, "in/keymap_sample.json"))
final = json.loads(tar_member(s2r, "out/stage2_final_restored.json"))["final"]
adjud = {}
for a in (json.loads(l) for l in tar_member(s2r, "in/adjudications.jsonl").splitlines() if l.strip()):
    adjud[a["key"]] = a  # the last decision per key stands
ratings = {}
for r in (json.loads(l) for l in tar_member(study / "stage2-data-2026-10-27.tgz", "ratings_counted.jsonl").splitlines() if l.strip()):
    ratings.setdefault(r["key"], []).append(r)

rows = []
for key, k in keymap.items():
    vstrata = [s for s in k["strata"] if s.get("feed") == "vulnetix"]
    if not vstrata or key not in final:
        continue
    ids = sorted({s["id"] for s in vstrata})
    rows.append({"key": key, "ecosystem": k["ecosystem"], "name": k["name"], "flagged_versions": k.get("flagged_versions"),
                 "record_ids": ids, "label": final[key],
                 "withdrawn_2026_10_25": all(i in w27_ids for i in ids),
                 "now": sorted({f"{man[i]['classification']}/{man[i]['state']}" if i in man else "absent" for i in ids}),
                 "adjudication": ({"label": adjud[key]["label"], "reason": adjud[key]["reason"], "by": adjud[key]["by"]}
                                  if key in adjud else None),
                 "raters": [{"rater": r["rater"], "label": r["label"], "confidence": r.get("confidence"),
                             "summary": r.get("summary"), "evidence": r.get("evidence")} for r in ratings.get(key, [])]})
c = Counter((r["ecosystem"], r["label"], r["withdrawn_2026_10_25"]) for r in rows)
summary["stage2_rated"] = len(rows)
summary["stage2_by_ecosystem_label_withdrawn25"] = {f"{e}|{l}|{'withdrawn' if w else 'kept'}": n for (e, l, w), n in sorted(c.items())}
summary["stage2_now"] = dict(Counter(f"{r['ecosystem']}|{r['label']}|{'+'.join(r['now'])}" for r in rows))
with open(out / "private_stage2.jsonl", "w", encoding="utf-8") as f:
    for r in sorted(rows, key=lambda r: (r["ecosystem"], r["label"], r["name"])):
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
json.dump(summary, open(out / "summary.json", "w"), indent=1)
print(json.dumps(summary, indent=1))
