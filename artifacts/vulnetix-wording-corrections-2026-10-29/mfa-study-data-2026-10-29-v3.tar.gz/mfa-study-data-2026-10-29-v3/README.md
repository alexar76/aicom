# Package-malware feeds on npm and PyPI: study data, 2026-10

Data of the study "Package-malware feeds: what they flag, and what registries did about it"
(stages 1 to 3 and section 9, data of 2026-10-24 to 2026-10-27). The write-up in five languages is in
`report/`, the method fixed before the results in `code/METHODOLOGY.md`, the scripts in `code/`.
The commit the code and reports come from is named in `BUILD.json`.

**No package file is in this archive**, so no malware: malicious samples are named by their path in
DataDog's public `malicious-software-packages-dataset`.

## Check it

```
python3 -I code/verify_archive.py .
```

recomputes from these files alone every stage 1 registry count, every stage 2 label, rate and
kappa, and every stage 3 scanner number, and compares them with the results made from the full data
before anything was withheld (`*/results_restored.*`, `stage1/compare_*.json`). It prints
`ALL SAME` when they match. `SHA256SUMS` lists every file.

## What is here

| Folder | What it holds |
|---|---|
| `stage1/` | `sample_status_2026-10-27.jsonl`: the 7,483 sampled feed records (feed, tool, ecosystem, kind, record id, package, flag date, versions, stratum size) with the registry's status on 2026-10-27; the published counts of 2026-10-24 and the comparison of the two |
| `stage2/` | the sample's key map (tool and ecosystem per package), every rating of every model run (label, confidence, tokens, date), the adjudications and blind re-reads (label only), held and withdrawn markers, frame sizes, bundle sizes, the restored results |
| `stage3/` | the three sets (malicious with names and dataset paths; benign A and B by id only), every scanner's outcome per package with the rules that fired, the window volumes, the restored results |
| `code/` | the study folder of the repository at the commit: scripts, seeds, `METHODOLOGY.md`, `data-manifest.json`, and section 9's data (`code/transparency/`) |
| `report/` | the write-up in English, Russian, Spanish, French and Chinese |

## What is withheld, and why

The study's ethics rule: the names of packages we read as probably benign are not published; they go
only to the feed concerned.

- **Stage 2:** every rated package has a fresh random id, the malicious ones too. Several frames
  were rated whole, so naming the malicious rows would name the benign ones by elimination. Record
  ids are opaque tokens (a record id names the package). Rater evidence and summaries, adjudication
  reasons, versions and file lists are left out (they quote the code); dates are kept, times are not.
- **Stage 1:** the rows of the packages rated in stage 2 carry an opaque token instead of the package
  name and record id (`"withheld": true`). Every other row is a public feed record with its public
  registry status.
- **Stage 3:** benign sets A (popular packages) and B (recent uploads) have ids only, with no name,
  version or file count. Scanner outputs keep the outcome, the rules and their counts; error messages
  and raw reports (their file paths name the package) are not included.

The full data, including everything withheld, is kept on two servers with checksums in
`code/data-manifest.json`. Anyone who rebuilds the sample from the public feed snapshots with the
published seeds will get the package names back; the archive only does not list them next to our
readings.

## Sources and licences

- Data made by this study: CC BY 4.0. Code: MIT (the repository's licence).
- Feed records come from OpenSSF `malicious-packages` at commit `ef188da1c8d1` (Apache-2.0) and
  Vulnetix's advisory database at commit `a21bd56f5a25` (CC BY 4.0); stage 1 repeats their record
  ids, package names and dates.
- Stage 3's malicious set is drawn from DataDog's `malicious-software-packages-dataset`
  (Apache-2.0), cited by path.
