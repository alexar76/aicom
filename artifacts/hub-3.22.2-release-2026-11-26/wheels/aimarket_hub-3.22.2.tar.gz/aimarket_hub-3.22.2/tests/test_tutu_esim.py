"""Contract and failure cases for the public Tutu MCP quote client."""

import json
from datetime import UTC, datetime

import httpx
import pytest

from aimarket_hub import tutu_esim


@pytest.fixture
def merchant(monkeypatch):
    requests = []
    plan = {
        "plan_id": "JP-1-7",
        "type": "data",
        "data": "1 GB",
        "days": 7,
        "price_usd": 6.29,
        "buy_url": "https://tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-1-7",
    }
    data = {"destination": "Japan", "currency": "USD", "coverage": ["JP"], "plans": [plan]}
    options = {}

    def respond(request):
        assert request.method == "POST"
        assert str(request.url) == "https://tutuesim.com/mcp"
        assert request.headers["accept"] == "application/json, text/event-stream"
        assert request.headers["user-agent"] == "AIMarket-Hub/1.0"
        assert "authorization" not in request.headers
        body = json.loads(request.content)
        requests.append((body, request.headers))

        if options.get("redirect"):
            return httpx.Response(307, headers={"Location": "https://example.com/"})
        if options.get("timeout"):
            raise httpx.ReadTimeout("unavailable")
        if body["method"] == "initialize":
            return httpx.Response(200, headers={"Mcp-Session-Id": "pilot-session"}, json={
                "jsonrpc": "2.0", "id": 1,
                "result": {"protocolVersion": options.get("version", "2025-06-18")},
            })
        if body["method"] == "notifications/initialized":
            return httpx.Response(202)
        if options.get("oversize"):
            return httpx.Response(200, headers={"Content-Type": "application/json"},
                                  content=b" " * (256 * 1024 + 1))

        result = {"isError": options.get("tool_error", False)}
        if options.get("text"):
            result["content"] = [{"type": "text", "text": json.dumps(data)}]
        else:
            result["structuredContent"] = data
        reply = {"jsonrpc": "2.0", "id": options.get("reply_id", 2), "result": result}
        if options.get("sse"):
            class Events(httpx.AsyncByteStream):
                async def __aiter__(self):
                    yield b": heartbeat\r\n\r\n"
                    yield b'data: {"jsonrpc":"2.0","method":"notifications/progress"}\r\n\r\n'
                    yield b"event: message\r\ndata: " + json.dumps(reply).encode()
                    yield b"\r\n\r\n"
                    pytest.fail("The client waited after receiving its reply")

            return httpx.Response(200, headers={"Content-Type": "text/event-stream"}, stream=Events())
        return httpx.Response(200, json=reply)

    client = httpx.AsyncClient

    def make_client(**kwargs):
        assert kwargs["follow_redirects"] is False
        assert kwargs["trust_env"] is False
        return client(transport=httpx.MockTransport(respond), **kwargs)

    monkeypatch.setattr(tutu_esim.httpx, "AsyncClient", make_client)
    return requests, data, plan, options


@pytest.mark.asyncio
@pytest.mark.parametrize("encoding", ["json", "sse", "text"])
async def test_live_values_vetted_checkout_and_mcp_handshake(merchant, encoding):
    requests, _, plan, options = merchant
    options[encoding] = True
    quote = await tutu_esim.fetch_tutu_quote()

    assert quote == {
        "seller": "Tutu eSIM", "plan_id": "JP-1-7", "country": "JP", "data_gb": 1,
        "validity_days": 7, "price": "6.29", "currency": "USD",
        "checkout_url": plan["buy_url"],
        "fetched_at": quote["fetched_at"],
    }
    assert datetime.fromisoformat(quote["fetched_at"]).utcoffset() == datetime.now(UTC).utcoffset()
    assert [body["method"] for body, _ in requests] == [
        "initialize", "notifications/initialized", "tools/call",
    ]
    initialize, initialized, search = requests
    assert initialize[0]["params"]["protocolVersion"] == "2025-06-18"
    assert "Mcp-Session-Id" not in initialize[1]
    assert "id" not in initialized[0]
    for _, headers in (initialized, search):
        assert headers["Mcp-Session-Id"] == "pilot-session"
        assert headers["MCP-Protocol-Version"] == "2025-06-18"
    assert search[0]["params"] == {
        "name": "search_plans",
        "arguments": {"country": "JP", "gb": 1, "days": 7, "lang": "en", "src": "aimarket", "limit": 8},
    }


@pytest.mark.asyncio
@pytest.mark.parametrize("url", [
    "http://tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-1-7",
    "https://tutuesim.com.example.com/en/esim/japan/?src=aimarket&plan=JP-1-7",
    "https://other@tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-1-7",
    "https://tutuesim.com/en/esim/france/?src=aimarket&plan=JP-1-7",
    "https://tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-3-7",
    "https://tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-1-7&plan=JP-3-7",
    "https://tutuesim.com/en/esim/japan/?plan=JP-1-7",
    "https://tutuesim.com/en/esim/japan/?plan=JP-1-7&src=mcp",
    "https://tutuesim.com/en/esim/japan/?plan=JP-1-7&src=mcp&src=aimarket",
    "https://tutuesim.com/en/esim/japan/?plan=JP-1-7&src=aimarket&extra=value",
])
async def test_rejects_unverified_checkout(merchant, url):
    _, _, plan, _ = merchant
    plan["buy_url"] = url
    with pytest.raises(tutu_esim.TutuQuoteUnavailable):
        await tutu_esim.fetch_tutu_quote()


@pytest.mark.asyncio
@pytest.mark.parametrize("field,value", [
    ("plan_id", "JP-2-7"), ("data", "3 GB"), ("days", 30),
    ("price_usd", None), ("price_usd", -1), ("price_usd", True), ("price_usd", 1e120),
])
async def test_rejects_missing_or_invalid_pilot_plan(merchant, field, value):
    _, _, plan, _ = merchant
    plan[field] = value
    with pytest.raises(tutu_esim.TutuQuoteUnavailable):
        await tutu_esim.fetch_tutu_quote()


@pytest.mark.asyncio
async def test_price_tracks_provider(merchant):
    _, _, plan, _ = merchant
    plan["price_usd"] = 8.125
    quote = await tutu_esim.fetch_tutu_quote()
    assert quote["price"] == "8.125"


@pytest.mark.asyncio
@pytest.mark.parametrize("option,value", [
    ("redirect", True), ("timeout", True), ("oversize", True), ("tool_error", True),
    ("version", "2025-03-26"), ("reply_id", 5),
])
async def test_external_failures_surface_as_quote_unavailable(merchant, option, value):
    requests, _, _, options = merchant
    options[option] = value
    with pytest.raises(tutu_esim.TutuQuoteUnavailable):
        await tutu_esim.fetch_tutu_quote()
    if option in ("redirect", "timeout", "version"):
        assert len(requests) == 1
