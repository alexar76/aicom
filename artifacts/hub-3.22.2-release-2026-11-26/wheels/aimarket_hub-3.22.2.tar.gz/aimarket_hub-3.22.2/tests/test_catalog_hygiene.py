"""Buyer-facing catalogue names and routes stay honest."""

from __future__ import annotations

import json
import time

import pytest
from fastapi.testclient import TestClient

from aimarket_hub.api import create_app
from aimarket_hub.catalog import catalogue_display_name, route_freshness
from aimarket_hub.config import HubConfig
from aimarket_hub.database import HubDatabase
from aimarket_hub.models import Capability, Peer
from aimarket_hub.signing import Signer
from aimarket_hub.tutu_esim import TUTU_QUOTE_IDS, TutuQuoteUnavailable


PEER = "https://peer.example.com"
CAPABILITY = "run@v1"
PRODUCT = "prod-eb9ce90c24f9"


def _stamp(offset_s: int = 0) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + offset_s))


def _cap(**overrides) -> Capability:
    values = dict(
        capability_id=CAPABILITY,
        product_id=PRODUCT,
        name=f"{PRODUCT}.run@v1",
        description="Execute primary workflow for **SignalForge Control Plane** — agent orchestration",
        source_hub=PEER,
        source_hub_name="Peer Hub",
        price_per_call_usd=0.35,
        trust_score=0.5,
    )
    values.update(overrides)
    return Capability(**values)


def _client(tmp_path, *, peer_status: str = "active", peer_age_s: int = 0, max_age_s: int = 60,
            hub_url: str = "https://catalog.example"):
    db = HubDatabase(tmp_path / "hub.db")
    cap = _cap()
    db.upsert_capability(cap)
    db.upsert_peer(
        Peer(
            url=PEER,
            name="Peer Hub",
            capabilities_count=1,
            last_crawl=_stamp(-peer_age_s),
            trust_score=0.5,
            trusted=True,
        ),
        status=peer_status,
    )
    config = HubConfig()
    config.hub_url = hub_url
    config.hub_name = "modelmarket.dev"
    config.db_path = str(tmp_path / "hub.db")
    config.signing_key_path = str(tmp_path / "key")
    config.catalog_max_stale_s = max_age_s
    config.auto_crawl = False
    app = create_app(config=config, db=db, signer=Signer(config.signing_key_path))
    return TestClient(app)


def test_display_name_removes_duplicate_protocol_qualification():
    memory = _cap(
        capability_id="memory.verify@v1",
        product_id="memory-verify",
        name="memory-verify.Verify Memory@v1@v1",
        description="Verify a memory attestation",
    )
    assert catalogue_display_name(memory) == "Verify Memory"
    assert memory.tool_name() == "memory-verify.Verify Memory@v1"


def test_generic_factory_name_uses_the_product_subject():
    cap = _cap()
    assert catalogue_display_name(cap) == "SignalForge Control Plane · Run"
    assert cap.tool_name() == f"{PRODUCT}.run@v1"


def test_route_freshness_distinguishes_stale_and_unavailable():
    cap = _cap()
    active = Peer(url=PEER, name="Peer", last_crawl="2026-01-01T00:00:00Z", status="active")
    now = datetime_epoch = 1767225720.0  # 2026-01-01T00:02:00Z
    assert route_freshness(cap, active, max_age_s=60, now=now).status == "stale"
    active.last_crawl = ""
    assert route_freshness(cap, active, max_age_s=60, now=datetime_epoch).status == "unknown"
    active.status = "key_mismatch"
    assert route_freshness(cap, active, max_age_s=60, now=datetime_epoch).status == "unavailable"


def test_search_hides_stale_offer_but_can_return_it_as_not_offerable(tmp_path):
    with _client(tmp_path, peer_age_s=3600, max_age_s=60) as client:
        regular = client.get("/ai-market/v2/search", params={"intent": "run", "limit": 20}).json()
        assert not any(row["capability_id"] == CAPABILITY for row in regular["matches"])

        audit = client.get(
            "/ai-market/v2/search",
            params={"intent": "run", "limit": 20, "include_stale": True},
        ).json()
        row = next(row for row in audit["matches"] if row["capability_id"] == CAPABILITY)
        assert row["route_status"] == "stale"
        assert row["offerable"] is False
        assert row["display_name"] == "SignalForge Control Plane · Run"
        assert row["seller_kind"] == "hub"

        manifest = client.get("/ai-market/v2/manifest").json()
        assert not any(tool["capability_id"] == CAPABILITY for tool in manifest["tools"])


def test_key_mismatch_offer_is_never_returned_even_for_audit(tmp_path):
    with _client(tmp_path, peer_status="key_mismatch") as client:
        result = client.get(
            "/ai-market/v2/search",
            params={"intent": "run", "include_stale": True},
        ).json()
        assert not any(row["capability_id"] == CAPABILITY for row in result["matches"])


def test_apex_exposes_external_provider_references_without_catalogue_offers(tmp_path):
    with _client(tmp_path, hub_url="https://modelmarket.dev") as client:
        directory = client.get("/ai-market/v2/external-services")
        assert directory.status_code == 200
        rows = {row["id"]: row for row in directory.json()["external"]}
        assert set(rows) == {"tavily", "laso", "tutu-esim"}
        assert (rows["laso"]["published_price_usd"], rows["laso"]["price_basis"]) == (5, "minimum_load")
        assert rows["tavily"]["method"] == "POST"
        assert all(row["payment_recipient"] == "provider" and row["hub_invoke"] is False for row in rows.values())

        search = client.get("/ai-market/v2/search", params={"intent": "Tavily web search"}).json()
        assert search["external"] == [rows["tavily"]]
        for intent in ("CMC crypto prices", "CoinMarketCap", "котировки криптовалют"):
            assert client.get("/ai-market/v2/search", params={"intent": intent}).json()["external"] == []
        assert all(row["capability_id"] == CAPABILITY for row in search["matches"])
        assert search["observed"] == []
        assert client.get("/ai-market/v2/search", params={"intent": "Laso", "budget": 1}).json()["external"] == []
        assert client.get("/ai-market/v2/search", params={"intent": "eSIM"}).json()["external"] == [
            rows["tutu-esim"],
        ]
        manifest = client.get("/ai-market/v2/manifest").json()
        assert "external" not in manifest
        assert {row["capability_id"] for row in manifest["tools"]} == {
            CAPABILITY, "pipeline.run@v1", TUTU_QUOTE_IDS[1],
        }


def test_external_provider_references_are_disabled_on_uni_even_with_apex_name(tmp_path):
    with _client(tmp_path, hub_url="https://uni.modelmarket.dev") as client:
        assert client.get("/ai-market/v2/external-services").status_code == 404
        assert "external" not in client.get("/ai-market/v2/search", params={"intent": "Laso"}).json()
        assert client.get("/ai-market/v2/external-services/tutu-esim/quote").status_code == 404


@pytest.mark.parametrize("hub_url", ["https://modelmarket.dev", "https://hub.modelmarket.dev"])
def test_tutu_is_discoverable_and_quotes_through_both_sites(tmp_path, monkeypatch, hub_url):
    quote = {
        "seller": "Tutu eSIM",
        "plan_id": "JP-1-7",
        "country": "JP",
        "data_gb": 1,
        "validity_days": 7,
        "price": "3.49",
        "currency": "USD",
        "checkout_url": "https://tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-1-7",
        "fetched_at": "2026-11-24T14:27:40Z",
    }
    prices = ("3.49", "4.19")
    calls = []

    async def fetch_quote():
        price = prices[len(calls)]
        calls.append(price)
        return {**quote, "price": price}

    monkeypatch.setattr("aimarket_hub.hub_routes.catalog.fetch_tutu_quote", fetch_quote)
    with _client(tmp_path, hub_url=hub_url) as client:
        directory = client.get("/ai-market/v2/external-services").json()["external"]
        if hub_url == "https://hub.modelmarket.dev":
            assert [row["id"] for row in directory] == ["tutu-esim"]
        listing = next(row for row in directory if row["id"] == "tutu-esim")
        assert listing["payment_protocol"] == "checkout"
        assert listing["payment_recipient"] == "provider"
        assert listing["hub_invoke"] is False
        assert "published_price_usd" not in listing
        for intent in ("eSIM?", "eSIM для Японии", "Japón", "Japon", "日本流量"):
            search = client.get("/ai-market/v2/search", params={"intent": intent}).json()
            assert search["external"] == [listing]
            if hub_url == "https://hub.modelmarket.dev":
                # The apex also lists the free quote capability (test_tutu_is_a_signed_free_capability_…).
                assert all(row["product_id"] != "tutu-esim" for row in search["matches"])
        assert client.get(
            "/ai-market/v2/search", params={"intent": "eSIM", "budget": 1},
        ).json()["external"] == []
        response = client.post("/mcp", json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "market_search", "arguments": {"intent": "JP-1-7"}},
        })
        rpc = json.loads(next(line[5:].strip() for line in response.text.splitlines()
                              if line.startswith("data:")))
        tool_result = json.loads(rpc["result"]["content"][0]["text"])
        assert tool_result["external"] == [{**listing, "quote_url": hub_url + listing["quote_url"]}]
        assert not calls

        for price in prices:
            current_quote = client.get(listing["quote_url"])
            assert current_quote.status_code == 200
            assert current_quote.headers["cache-control"] == "no-store"
            assert current_quote.json() == {**quote, "price": price}
        assert calls == list(prices)


def test_tutu_quote_reports_unavailability_without_a_purchase_link(tmp_path, monkeypatch):
    calls = []

    async def fetch_quote():
        calls.append("Tutu")
        raise TutuQuoteUnavailable("upstream unavailable")

    monkeypatch.setattr("aimarket_hub.hub_routes.catalog.fetch_tutu_quote", fetch_quote)
    with _client(tmp_path, hub_url="https://modelmarket.dev") as client:
        for _ in range(2):
            response = client.get("/ai-market/v2/external-services/tutu-esim/quote")
            assert response.status_code == 503
            assert response.headers["cache-control"] == "no-store"
            assert "checkout_url" not in response.json()
    assert calls == ["Tutu", "Tutu"]


def test_tutu_is_a_signed_free_capability_that_fetches_fresh_quotes(tmp_path, monkeypatch):
    product, capability = TUTU_QUOTE_IDS
    quote = {
        "seller": "Tutu eSIM", "plan_id": "JP-1-7", "country": "JP",
        "data_gb": 1, "validity_days": 7, "currency": "USD",
        "checkout_url": "https://tutuesim.com/en/esim/japan/?src=aimarket&plan=JP-1-7",
        "fetched_at": "2026-11-25T04:30:00Z",
    }
    prices = iter(("3.49", "4.19"))

    async def fetch():
        return {**quote, "price": next(prices)}

    monkeypatch.setattr("aimarket_hub.tutu_esim.fetch_tutu_quote", fetch)
    with _client(tmp_path, hub_url="https://modelmarket.dev") as client:
        manifest = client.get("/ai-market/v2/manifest").json()
        signer = Signer(str(tmp_path / "key"))
        assert signer.verify_manifest_signature(manifest, signer.public_key_b64, signer.pq_public_key_b64)
        listing = next(row for row in manifest["tools"] if row["capability_id"] == capability)
        assert (listing["product_id"], listing["price_per_call_usd"]) == (product, 0)
        assert listing["invoke_url"] == "https://modelmarket.dev/ai-market/v2/invoke"
        matches = client.get("/ai-market/v2/search", params={"intent": "Japan eSIM", "budget": 0}).json()["matches"]
        assert any(row["capability_id"] == capability and row["source_hub"] == "local" for row in matches)
        invoke = {"product_id": product, "capability_id": capability, "source_hub": "local", "max_price_usd": 0}
        invalid = client.post("/ai-market/v2/invoke", json={**invoke, "input": {"country": "US"}})
        assert invalid.status_code == 422, invalid.text
        for price in ("3.49", "4.19"):
            response = client.post("/ai-market/v2/invoke", json={**invoke, "input": {}})
            assert response.status_code == 200, response.text
            answer = response.json()
            assert answer["success"] and answer["price_usd"] == 0
            assert answer["result"] == {**quote, "price": price}
            assert answer["receipt"]["signature"]
