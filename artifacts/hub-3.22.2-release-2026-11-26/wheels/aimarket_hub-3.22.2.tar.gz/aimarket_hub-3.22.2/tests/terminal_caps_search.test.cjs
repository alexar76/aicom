// The capability catalogue's search must not freeze the tab (2026-11-22): typing while a catalogue page was loading
// made drainCaps() spin forever on resolved promises. These tests run the page's own code (from terminal-home.html)
// with a fetch that answers late, and fail if any search does not finish. On the old page the first test never
// finishes at all (the spin blocks the event loop, timers included): the test run hangs until its timeout.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const page = fs.readFileSync(path.join(__dirname, '..', 'terminal-home.html'), 'utf8');
function section(start, end) {
  const from = page.indexOf(start), to = page.indexOf(end, from);
  assert.ok(from >= 0 && to > from, `section ${start}`);
  return page.slice(from, to);
}

function fixture({ total = 310, pageSize = 250, delayMs = 30, stuckHasMore = false } = {}) {
  const listeners = {};
  const caps = Array.from({ length: total }, (_, i) => ({ capability_id: `cap_${i}`, description: `capability number ${i}`, source_hub: 'https://hub.example' }));
  const ctx = {
    HUB: 'https://hub.example', CAPS_PAGE: pageSize, hubLang: 'en', capI18n: null, requests: 0, capsFindSeq: 0,
    capsCache: null, capsTotal: 0, capsHasMore: false, capsLoadingMore: false, catMode: 'caps',
    externalDirectory: [], renderDirectOffers: () => '',
    catFind: { value: '', addEventListener(name, cb) { listeners[name] = cb; } },
    catMeta: { textContent: '' }, catBody: { innerHTML: '', addEventListener() {} },
    t: (k, v) => `${k} ${JSON.stringify(v || {})}`, esc: s => String(s), hostOf: u => u, accessMode: () => 'public',
    capabilityPrice: () => '$0', descFor: c => c.description, allLangsFor: () => [], setTimeout, Promise, URL,
    async fetch(url) {
      ctx.requests++;
      const offset = Number(new URL(url).searchParams.get('offset'));
      await new Promise(r => setTimeout(r, delayMs));
      const matches = caps.slice(offset, offset + pageSize);
      return { ok: true, json: async () => ({ matches, total, has_more: stuckHasMore || offset + pageSize < total }) };
    },
  };
  vm.createContext(ctx);
  // The page's own functions, unchanged: shortPublisher … renderCaps, and the search box's listener.
  vm.runInContext(section('  function capKey(', '  function capItemHtml('), ctx);
  vm.runInContext(section('  function capItemHtml(', '  async function openCatalogue('), ctx);
  vm.runInContext(section("  catFind.addEventListener('input'", "  catBody.addEventListener('scroll'"), ctx);
  return { ctx, input: listeners.input };
}

function within(ms, promise) {
  return Promise.race([promise, new Promise((_, rej) => setTimeout(() => rej(new Error(`not finished within ${ms} ms: the search hangs`)), ms))]);
}

test('keystrokes while a catalogue page is loading finish and show matches from every page', async () => {
  const { ctx, input } = fixture();
  await ctx.loadCapsPage(true);
  assert.equal(ctx.capsCache.length, 250);
  ctx.catFind.value = 'number 30';
  const first = input();
  ctx.catFind.value = 'number 309';
  const second = input(); // lands while the second page is still loading
  await within(2000, Promise.all([first, second]));
  assert.equal(ctx.capsCache.length, 310);
  assert.equal(ctx.requests, 2, 'the second page is requested once, shared by both keystrokes');
  assert.match(ctx.catMeta.textContent, /caps_meta_filter .*"shown":1/);
});

test('a hub that keeps answering has_more with nothing new does not keep the tab busy', async () => {
  const { ctx, input } = fixture({ total: 300, stuckHasMore: true });
  await ctx.loadCapsPage(true);
  ctx.catFind.value = 'number';
  await within(3000, input());
  assert.ok(ctx.requests <= 4, `stopped after a page that added nothing (${ctx.requests} requests)`);
});

test('concurrent loads share one request', async () => {
  const { ctx } = fixture();
  await ctx.loadCapsPage(true);
  await within(2000, Promise.all([ctx.loadCapsPage(false), ctx.loadCapsPage(false), ctx.drainCaps(), ctx.drainCaps()]));
  assert.equal(ctx.requests, 2);
  assert.equal(ctx.capsHasMore, false);
});
