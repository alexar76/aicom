"""First-party API references curated by the ModelMarket operator.

CoinMarketCap was listed here until 2026-11-22. CMC support (ticket 1474981) declined any ModelMarket route for
its quotes on 2026-11-19 and on 2026-11-22 asked that ModelMarket not present CMC data or API access among its
offerings; the operator removed the reference."""

from __future__ import annotations

import re

from aimarket_hub.semantic_search import normalize_text

TUTU_QUOTE_PATH = "/external-services/tutu-esim/quote"


_SERVICES = (
    ({
        "id": "tavily",
        "name": "Tavily",
        "description": "Advanced web search with ranked sources and snippets.",
        "documentation_url": "https://docs.tavily.com/documentation/machine-payments/x402",
        "endpoint": "https://x402.tavily.com/search",
        "method": "POST",
        "payment_networks": ("base",),
        "published_price_usd": 0.01,
        "price_basis": "per_request",
    }, ("web search", "поиск в интернете", "веб поиск", "busqueda web", "recherche web", "网页搜索")),
    ({
        "id": "laso",
        "name": "Laso",
        "description": "Non-reloadable U.S. prepaid card. Check merchant acceptance before loading the card.",
        "documentation_url": "https://docs.laso.finance/guides/usa-prepaid-card",
        "endpoint": "https://laso.finance/get-card",
        "method": "GET",
        "payment_networks": ("base", "solana"),
        "published_price_usd": 5,
        "price_basis": "minimum_load",
    }, ("prepaid card", "virtual card", "предоплачен", "виртуальн", "tarjeta prepago", "carte prepayee", "预付卡")),
)

_TUTU_ESIM = {
    "id": "tutu-esim",
    "name": "Tutu eSIM",
    "description": "Japan travel eSIM, 1 GB for 7 days. Check the current price and pay on Tutu eSIM.",
    "documentation_url": "https://tutuesim.com/en/mcp/",
    "payment_protocol": "checkout",
    "payment_recipient": "provider",
    "price_basis": "per_plan",
    "quote_url": f"/ai-market/v2{TUTU_QUOTE_PATH}",
    "hub_invoke": False,
}
_TUTU_TERMS = frozenset({
    "tutu", "esim", "e sim", "jp 1 7", "japan", "japon", "япония", "японию", "японии", "есим",
})


def is_modelmarket_apex(hub_url: str) -> bool:
    return hub_url.rstrip("/") == "https://modelmarket.dev"


def tutu_checkout_enabled(hub_url: str) -> bool:
    return is_modelmarket_apex(hub_url) or hub_url.rstrip("/") == "https://hub.modelmarket.dev"


def external_references(hub_url: str, intent: str = "", *, budget: float | None = None) -> list[dict]:
    """Directory entries with provider checkout or direct x402 payment."""
    query = normalize_text(intent[:500])
    rows = []
    if is_modelmarket_apex(hub_url):
        rows.extend(
            {**service, "payment_protocol": "x402", "asset": "USDC",
             "payment_recipient": "provider", "hub_invoke": False}
            for service, aliases in _SERVICES
            if (budget is None or service["published_price_usd"] <= budget)
            and (not query or any(phrase in query for phrase in (service["id"], *aliases)))
        )
    # No price is known until the buyer requests a quote. An explicit budget
    # filter should only return offers it can verify against that budget.
    if tutu_checkout_enabled(hub_url) and budget is None:
        words = " " + " ".join(re.findall(r"\w+", query)) + " "
        if not query or any(f" {term} " in words for term in _TUTU_TERMS) or "日本" in query:
            rows.append(dict(_TUTU_ESIM))
    return rows
