"""HISTOR service, read-only inspection and offline reports."""

from __future__ import annotations

import json
import logging
import sys


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    command = args[0] if args else "serve"
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    if command == "mcp":
        from histor.mcp_stdio import main as mcp

        return mcp(args[1:])

    if command == "migrate":
        from histor.migrations import main as migrate

        return migrate(args[1:])
    if command == "witness-submit":
        from histor.cosign_cli import main as witness_submit

        return witness_submit(args[1:])
    if command == "audit":
        # Needs no settings, no database and no keys: an auditor is a stranger to the log.
        from histor.audit import main as audit

        return audit(args[1:])
    if command == "tool-cost":
        # Runs in a package's own CI against its own server: no settings, no database, no keys.
        from histor.toolcost_cli import main as tool_cost

        return tool_cost(args[1:])

    if command == "payer-audit":
        # Offline reducer: no production settings, database, signing keys or wallet access.
        from histor.payer_audit_cli import main as payer_audit

        return payer_audit(args[1:])

    if command == "upgrade-brief":
        # The report is entirely offline. Only explicit capture reads an HTTP endpoint.
        if len(args) > 1 and args[1] == "capture":
            from histor.upgrade_capture import main as capture

            return capture(args[2:])
        from histor.upgrade_brief_cli import main as upgrade_brief

        return upgrade_brief(args[1:])

    from histor.config import load_settings
    from histor.service import build

    settings = load_settings()
    if command == "sandboxes":
        # Reaches only the sandbox hosts: no database, no keys, so it runs beside a live service.
        from histor.packages import check_sandboxes

        if not settings.sandbox_enabled:
            print("no sandbox configured (HISTOR_SANDBOX_URL, _TOKEN, _CERT_SHA256)", file=sys.stderr)
            return 1
        rows = check_sandboxes(settings)
        for row in rows:
            print(json.dumps(row))
        return 0 if all(r["ok"] for r in rows) else 1
    services = build(settings, serving=command == "serve")
    try:
        if command == "serve":
            import uvicorn

            from histor.app import create_app

            uvicorn.run(create_app(services), host=settings.host, port=settings.port, proxy_headers=False,
                        log_level="warning")
            return 0
        if command == "crawl":
            running = services.store.last_run(finished_only=False)
            if running and not running.get("finished_at") and "--force" not in args:
                # The lock is per process; the service may be crawling next door.
                print(f"a crawl started at {running['started_at']} has not finished (the service may be "
                      "running it); pass --force if it is dead", file=sys.stderr)
                return 1
            print(json.dumps(services.crawler.run(), indent=2))
            return 0
        if command == "reobserve":
            keys = [a for a in args[1:] if not a.startswith("-")]
            if not keys:
                print("usage: histor reobserve <endpoint or target id> [...]   e.g. pypi:ipinfo-mcp-server",
                      file=sys.stderr)
                return 2
            try:
                rows = services.crawler.reobserve(keys)
            except (KeyError, RuntimeError) as exc:
                print(str(exc).strip("'\""), file=sys.stderr)
                return 1
            for row in rows:
                print(json.dumps(row))
            return 0
        if command == "census":
            from histor.security_events import census
            print(json.dumps(census(services.store, services.key), ensure_ascii=False))
            return 0
        if command == "webhooks":
            from pathlib import Path

            from histor.security_events import deliver
            if len(args) != 2:
                raise ValueError("histor webhooks /operator/owned/subscriptions.json")
            subscriptions = json.loads(Path(args[1]).read_text())
            for subscription in subscriptions:
                print(json.dumps({"id": subscription["id"],
                                  **deliver(services.store, subscription, base_url=settings.public_base)}))
            return 0
        if command == "export-dataset":
            from histor.dataset import main as export_dataset

            return export_dataset(services.store, services.key, settings, args[1:])
        if command == "issuer":
            print(services.key.did)
            return 0
        print("usage: histor [serve|mcp|crawl|migrate [up|status]|issuer|audit URL|tool-cost|payer-audit|upgrade-brief|sandboxes|export-dataset DIR]", file=sys.stderr)
        return 2
    finally:
        services.close()


if __name__ == "__main__":
    raise SystemExit(main())
