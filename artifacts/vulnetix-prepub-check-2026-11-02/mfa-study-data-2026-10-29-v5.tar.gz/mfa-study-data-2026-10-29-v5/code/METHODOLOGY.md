# Malware-feed accuracy study: methodology

Written on 2026-10-24, before stage 1's registry results were read. Any change made after that
is listed under "Changes after the results" at the end, with its reason.

## Why we are doing this, and our interest

On 2026-10-07..17 one feed (Vulnetix, GCVE GNA 110) listed six of our own PyPI packages as
malware. Every matched line was a test, a README example or a public constant. That is one feed
and six packages; it says nothing about how often feeds are right in general. This study measures
that across as many public feeds and detecting tools as publish open data, with the same rules for
each. We are an interested party: the packages of the authors of this study are in the data. The
study counts them like any other row and names this interest wherever the results are published.

## Standards and prior work this follows

- **Arp et al., "Dos and Don'ts of Machine Learning in Computer Security"** (USENIX Security 2022;
  extended in ACM TOPS 2024): ten pitfalls of security evaluations. How this study handles each one
  is listed under "Pitfall checklist" below.
- **Pendlebury et al., TESSERACT** (USENIX Security 2019): no mixing of past and present samples;
  results are reported by time. Here, flag age buckets and pinned snapshot times.
- **Guo et al., "How Effective Are NPM Malicious Package Detectors?"** (ASE 2026, arXiv 2603.27549):
  the closest recent benchmark. Its practice is adopted for labels: dedupe by name and version,
  separate registry placeholders, three reviewers with a two-of-three vote and Cohen's κ reported
  (theirs: 0.78; expert review dropped 1,367 of 7,787 source labels as wrong). Its benign set is
  popularity-weighted, as a deliberately harder false-positive test.
- **Guo et al., "Cutting the Gordian Knot"** (USENIX Security 2026, arXiv 2601.16463): a second
  benign frame of random recent uploads, errors broken down by rule category (for GuardDog, most
  false positives were code-execution flags on legitimate idioms such as `exec(compile(...))`),
  timeouts reported rather than counted as benign.
- **Vu et al., "Bad Snakes"** (ICSE 2023): measured false-positive rates of PyPI malware checks of
  15–97% and reports that registry administrators consider even 0.1% too high. False positives are
  therefore reported per benign package and as alert volume, not only as precision.
- **Registries:** PyPI lets trusted reporters' reports quarantine a project automatically, with a
  human review after, and reported zero false positives from that path in 2025 board reports; npm
  replaces taken-down packages with `0.0.1-security`. Both mean a registry action is partly the
  feeds' own verdict (see "What 'registry acted' is and is not").
- **Spam versus malware:** Amazon Inspector filed about 150,000 tea.xyz token-farming packages to
  OpenSSF as malicious (November 2025); Endor Labs described a similar set as spam that does not
  steal or damage. The study does not settle this; it reports spam as its own kind.
- **Trend: LLM-based detection** (SocketAI, MalPacDetector, DistillGuard and others) reports high
  precision with lower recall on balanced benchmarks. Where this study uses a model, it is only as a
  second rater whose agreement with the human rater is measured; it never labels alone.

## Questions

1. **What do feeds call malware?** The share of records that, by their own text, describe
   malicious code, token-farming spam, or security-research probes.
2. **Do registries act on the flags?** For each feed and detecting tool, the share of flagged
   packages that the registry has since removed, replaced with a security placeholder, or whose
   flagged versions it no longer serves, by the age of the flag.
3. **Do feeds retract?** The share of each tool's records the feed itself withdrew.
4. **Do feeds agree?** For packages flagged by more than one tool, how often the others flag them
   too.
5. **Stage 2 (not yet run):** in a random sample of flags the registry did not act on, how many
   are malicious on inspection: the false-positive rate, with an interval.
6. **Stage 3 (not yet run):** recall: how much of a labelled set of known malware each open
   scanner finds.

## Data

Snapshots, pinned by commit:

| Source | What it is | Snapshot |
|---|---|---|
| `ossf/malicious-packages` | OpenSSF's open database of malicious-package reports (OSV). Each record lists the tools that reported it in `database_specific.malicious-packages-origins[].source`. | commit `ef188da1c8d1`, 2026-10-24 04:29Z |
| `Vulnetix/advisory-database` | Vulnetix's own GCVE records in their native format, with the rule and line that matched (`detection.matched_lines`). | commit `a21bd56f5a25`, 2026-10-24 06:51Z |
| GitHub Advisory Database | Advisories of type `malware` from the public REST API (`/advisories?type=malware`). Most also appear in OpenSSF as source `ghsa-malware`; they are used to check that, not counted twice. | fetched 2026-10-24 |

Ecosystems: npm and PyPI (the two where every source has data). Other ecosystems are left for a
later round and are not mixed in.

What the Vulnetix source is (added 2026-10-29, from Vulnetix's answer to our letter): its GCVE
advisory database, public since 2026-10-18 and loaded in bulk on 19 to 27 October, so the snapshot
is its sixth day. Vulnetix says this database is not its malware-intelligence feed; that feed is a
separate set of STIX bundles of domain and URL indicators (see the repeat measurement, "Added on
2026-10-29"). Where the write-up calls Vulnetix a feed, it means the advisory database as studied.

Stage 1 reads **metadata only**: feed records and registry metadata. No package is downloaded,
installed or run.

## Units and definitions

- **Record:** one feed entry about one package (an OSV `affected` entry, a Vulnetix record, a
  GHSA advisory package).
- **Detecting tool (source):** the tool or team a record credits: OpenSSF origins (`amazon-inspector`,
  `reversing-labs`, `checkmarx`, `ossf-package-analysis`, `kam193`, `google-open-source-security`,
  `ghsa-malware`, `oracle-using-macaron`, `unknown`), `vulnetix`, GHSA credits. A record credited to
  several tools counts once for each.
- **Kind**, from the record's own summary and details, by fixed keyword rules (`normalize.py`,
  `KINDS`): `spam` (tea.xyz token farming, autopublish spam), `research` (security research, bug
  bounty, proof of concept, dependency confusion, pentest), otherwise `malicious`. Vulnetix records
  carry no prose; they are `static-rule`. The rules were fixed before any registry result was seen.
- **Registry status** today (`registry_check.py`):
  - `removed`: the registry answers 404 for the name;
  - `placeholder`: npm serves only its security holding package `0.0.1-security`;
  - `quarantined`: PyPI marks the project quarantined;
  - `versions_gone`: the name is served, but none of the record's flagged versions is;
  - `live`: at least one flagged version is served (or, when a record gives no versions, the name is).
  The first four together are **"registry acted"**. `live` is **"unresolved"**.
- **Age of a flag:** check time minus the record's `published` time, in buckets < 7 days,
  7–30 days, 30–180 days, > 180 days. Registries take time; a young `live` flag is expected.

**What "registry acted" is and is not.** It is evidence that a registry, after its own review,
agreed enough to act. It is not independent ground truth: registries act on reports, often from
these same feeds (PyPI quarantines on trusted reporters' word before a human looks); authors also
unpublish their own packages for unrelated reasons. `live` is not
a false positive: registries miss malware and are slow. Stage 1 therefore reports neither
precision nor a false-positive rate. It reports where flags stand, per tool and age, and leaves the
false-positive rate to stage 2.

## Sampling and estimates

- Strata: (feed, detecting tool, ecosystem, kind). Within each stratum, a simple random sample of
  400 records (all of them if fewer), seed `20261024`, drawn by `registry_check.py`.
- Registry status is per package, so a package drawn in several strata is looked up once.
- Proportions are given per stratum with **Wilson 95% intervals**. Totals across strata are
  weighted by stratum size, never pooled raw.
- Withdrawals (question 3) and agreement (question 4) use the full record sets, not the sample.

## Stage 2: false-positive rate (run 2026-10-24 and 25)

- Population: `live` flags older than 30 days, per tool.
- Random sample per tool, size fixed before drawing (target 100, or all).
- Each package is judged against a codebook written before review: **malicious** = takes or
  sends credentials, keys, files or environment to a third party; downloads and runs a remote
  payload; installs persistence; destroys data; hides such behaviour (obfuscation guarding a
  network or exec call). **Spam** = no harmful behaviour, published to farm rewards or rank.
  **Benign** = none of the above. **Inconclusive** = cannot be decided from code and sandbox run.
- Evidence: static reading of the published files plus a run of the install and import in the
  HISTOR gVisor sandbox (no network except an observed sink), never on a workstation.
- Raters are blind to which tool flagged a package. Two independent raters label each package;
  where a third human rater is available, the label is the two-of-three vote, as in Guo et al.
  Agreement is reported as Cohen's κ (Fleiss' κ with three). If the second rater is a model, that
  is stated, its agreement with the human rater is reported, and disagreements go to a human.
- False-positive rate = benign / (malicious + spam + benign), Wilson interval; inconclusive is
  reported, not dropped; spam is shown both ways (as malicious and as not).

### Stage 2 protocol, fixed on 2026-10-24 before the sample was drawn

This replaces the plan above where they differ; each difference is named.

- **Frame.** Stage 1 sample rows whose registry status was `live`, of kind `malicious` (OpenSSF) or
  `static-rule` (Vulnetix), flagged more than 30 days before the check. Frame sizes at fixing:
  Amazon Inspector npm 24 / PyPI 45, GitHub npm 35, Google npm 13, OSSF Package Analysis npm 16 /
  PyPI 2, Checkmarx npm 1, kam193 PyPI 1, unknown npm 54, Vulnetix npm 145 / PyPI 170.
- **Sample.** Every row of a stratum with at most 50 rows; 50 drawn at random (seed `20261025`)
  from larger ones. A package in several strata is reviewed once and counts in each.
- **Version.** The newest flagged version the registry still serves; if the record names no
  versions, the latest.
- **Evidence bundle, built on the isolated sandbox host, never on a workstation.** The registry
  artifact is downloaded and unpacked without installing or importing it. The bundle holds: package
  metadata (name, version, summary, homepage); the file list; every install-time hook in full
  (`setup.py`, build backends' hooks, `package.json` `preinstall`/`install`/`postinstall`, `.pth`
  files); the files an entry point or hook names; then files ranked by density of risky calls
  (network, process, `eval`/`exec`, decoding, environment and credential paths), until 60 KB. Long
  minified or encoded blobs are cut and their length noted. **No feed, tool, record text or
  registry status is in the bundle.** The same builder makes every bundle, controls included.
- **Raters.** Two models of different vendors, neither of which operates a feed in this study:
  R1 `qwen/qwen3.8-flash`, R2 `deepseek/deepseek-v4.1-flash`, via OpenRouter, temperature 0, the same
  prompt carrying the codebook above. *As fixed on 2026-10-24 this named R1 `openai/gpt-6.1-sol` and
  R2 `moonshotai/kimi-k3.1-pro`; they were replaced before any counted rating, chosen on half of the
  controls (change log, 2026-10-24, "raters changed"). Only the replacement pair's ratings count.*
  Output: label (`malicious`, `spam`, `benign`,
  `inconclusive`), the lines it rests on, confidence. Bundle content is fenced as untrusted data and
  the prompt says instructions inside it are part of the evidence, never orders.
  **Deviation from the plan:** no human raters were available, so both raters are models. That is
  the study's largest limitation and is stated with every stage 2 number.
- **Controls, mixed in blind.** 30 known-benign packages (15 PyPI, 15 npm, drawn at random, seed
  `20261025`, from the most-downloaded packages that no feed in this study lists) and 30 known-malicious
  ones (15 PyPI, 15 npm, drawn at random from DataDog's `malicious-software-packages-dataset`
  samples of 2025–2026, handled only on the sandbox host). Each rater's accuracy on the controls is
  reported; a rater below 90% on the controls has its labels shown but not used.
- **Final label.** Raters agree: that label. Raters disagree, or either says `inconclusive`: the
  package is installed and imported in the HISTOR gVisor sandbox (network observed, not open) and
  an adjudicator decides, blind to the flagging tool: the study's analyst (Claude, Anthropic, which
  operates no feed here). Every adjudication is listed. A human audit of a random 10% of final
  labels plus every adjudication is offered to the owner; whether it happened, and what it changed,
  is reported.
- **Numbers.** Per tool and ecosystem: false-positive rate among live flags older than 30 days =
  benign / (malicious + spam + benign), Wilson 95%; spam shown counted both ways; inconclusive
  reported, not dropped. An estimated false-positive share of all the tool's flags = (share of
  flags live after 30 days, stage 1) × (that rate), under the stated assumption that flags the
  registry acted on are correct; as that assumption can fail, the estimate is labelled a lower
  bound for tools whose acted-on flags include errors. Agreement: Cohen's κ between R1 and R2, on
  the sample and on the controls.

## Stage 3: recall and false alarms of scanners (run 2026-10-24 and 25)

- Malicious set: labelled known malware (DataDog `malicious-software-packages-dataset`,
  `pypi_malregistry`, OpenSSF records whose versions are still retrievable), deduplicated by name and
  version, placeholders removed.
- Two benign frames, reported separately: popular packages (a harder test, as in Guo et al.) and a
  random sample of recent uploads (closer to what a registry sees). Benign labels checked against
  OSV and the feeds, with a manual look at every package a scanner flags.
- Scanners: every open one that runs locally with default settings (for example GuardDog,
  OSSGadget); versions and settings recorded. Timeouts and crashes reported as their own outcome.
- Metrics: precision, recall, F1, false positives per 1,000 benign packages, and the expected
  false alerts per day at the registry's real upload volume and malware prevalence (base rate),
  with errors broken down by rule category.
- Time: malware split by publication period; nothing tuned on the test set.
- Live malware is handled only on the isolated sandbox host.

### Stage 3 protocol, fixed on 2026-10-24 before any set was drawn

- **Scanners**, open source, run locally with default settings, versions recorded: GuardDog 3.2.0
  (DataDog), malcontent 1.27.1 (Chainguard), OSSGadget `oss-detect-backdoor` 0.2.38 (Microsoft),
  Packj 0.15-beta, and Vulnetix's `malscan-engine` if it builds into a runnable command (its
  repository has no licence; it is run locally for this measurement only and not redistributed).
  A scanner that cannot be made to run is listed with the reason. **Baseline (pitfall P6):** one
  rule, "an install-time hook that makes a network call or starts a process".
- **What counts as a flag**, decided per scanner before running: GuardDog any `threat-*` or metadata
  heuristic (its `capability-*` rules describe abilities, not threats, and are reported apart);
  malcontent a `HIGH` or `CRITICAL` risk; OSSGadget any backdoor finding; Packj any "malicious" or
  "risky" alert; malscan-engine any `evidence` finding or a `trigger` with its payload.
- **Sets**, deduplicated by name and version:
  - Malicious: DataDog `malicious-software-packages-dataset` samples discovered 2025–2026, one per
    package name, the 30 stage 2 controls excluded; 200 npm and 200 PyPI at random (seed
    `20261027`), or all if fewer.
  - Benign A, popular: top 5,000 by downloads (the stage 2 sources), no feed in this study lists
    them, stage 2 controls excluded; 200 npm and 200 PyPI at random (seed `20261027`).
  - Benign B, recent uploads: packages with a release published 2026-10-10 00:00Z to 2026-10-17
    00:00Z (a week or more before scanning, so feeds had time), from npm's replication feed and
    PyPI's changelog; no feed lists them at scanning time; 200 npm and 200 PyPI at random (seed
    `20261027`). These are **unflagged, not proven benign**; every package a scanner flags in this
    set is read by hand and reported.
- **Running:** on the isolated sandbox host, in gVisor containers with no network, on the unpacked
  artifact; 300 s per package; timeouts and crashes reported as their own outcome, never as clean.
- **Numbers per scanner and ecosystem:** recall on the malicious set; false positives per 1,000 in
  each benign set; precision and F1 on malicious + benign A (balanced, as benchmarks report) and on
  a realistic mix at the registries' base rate; expected false alarms per day at each registry's
  daily release volume (volume from the changelog/feed window itself); errors by rule. Wilson 95%
  intervals throughout.

## Repeat measurement (stage 1b), fixed on 2026-10-25 before it is run

A second look at the same rows a week later, to see what changes with time. Nothing below is run
before the letters to the feeds have gone out; its date is set from theirs.

- **When:** seven days after the letters are sent (the sending date is written in the letters file),
  target 2026-11-03. One run, at one time, for every part below.
- **Snapshots:** OpenSSF malicious-packages, Vulnetix advisory-database and the GHSA malware
  advisories again, each pinned by commit or fetch time, normalised by the same `normalize.py`.
- **Same rows, second check:** the stage 1 sample (the `status_ov_v3.jsonl` rows, same seed) is
  checked again with the same `registry_check.py`. Per tool and ecosystem: the share the registry
  acted on then and now, paired on the same rows (McNemar's exact test), and how many rows changed
  each way.
- **Feed corrections:** per feed, records of the stage 1 snapshot that are withdrawn, reclassified
  (malware to vulnerability or the reverse) or deleted in the second snapshot, each with the date
  the feed made the change where the record carries one. Changes dated after our letter to that feed
  are reported apart from earlier ones: a letter can cause a change, and the study is then measuring
  its own effect.
- **Stage 2 packages:** for every package with a final stage 2 label, whether the registry removed
  it in the week, by label (malicious, spam, benign). The question is whether registries remove what
  we read as malicious and leave what we read as benign; a removal of a benign-labelled package is
  read by hand again.
- **A week of new flags:** records first published between the two snapshots, per feed and
  ecosystem, with the share the registry acted on by the second check (the < 7 days bucket of
  stage 1, measured forward rather than backward).
- **Scanner drift (stage 3):** a second recent-uploads set, Benign B2: packages released
  2026-10-24 00:00Z to 2026-10-31 00:00Z, 200 npm and 200 PyPI (seed `20261103`), drawn by the same
  `stage3_recent.py`, scanned by the same scanner versions and settings; false positives per 1,000
  next to Benign B's. No scanner setting is changed between the two sets.
- **Not done:** no new rating with models, no change to the codebook, no re-labelling of stage 2
  packages unless a removal of a benign-labelled one sends it back to a reader.

### Amended on 2026-10-27, before any part of it is run

The per-row registry status of 2026-10-24 was lost (see "Changes after the results", 2026-10-27), so
the paired comparison above cannot use it. What replaces it, fixed before the new check is run:

- **When, amended the same day.** Not exactly seven days after the letters, which is hard to keep,
  but on one date within a window of 14 to 21 days after the letters are sent. The date is chosen
  and written into this file and the letters file before the run, never after looking at anything;
  every part runs on that date. The days elapsed since the letters are reported, and counts over the
  time between the two snapshots are also given per day. A run outside the window is a deviation,
  logged with its reason. Publication still comes seven days after the letters (the feeds' time to
  answer); the repeat measurement is published later as an update.
- **A new baseline, before any letter.** The same rows (`sample_plan.jsonl`, rebuilt and checked
  against the published sample) are checked again on 2026-10-27 with the same `registry_check.py`,
  before any letter is sent. This is the paired baseline: the repeat run's "then and now" is
  2026-10-27 against the repeat, per tool, ecosystem and kind, McNemar's exact test, with Holm's
  correction across the strata tested, and the rows that changed each way.
- **Against the published numbers.** Per stratum, the share the registry acted on 2026-10-24 (the
  published counts) and on 2026-10-27, and later on the repeat, as two counts on the same rows whose
  per-row link is lost: a difference with Newcombe's hybrid score interval, labelled unpaired. The
  2026-10-24 to 2026-10-27 comparison is a stability check, not a finding.
- **Benign B2 waits a week, like Benign B.** Benign B was scanned a week after its release window
  closed, so feeds had time to list its packages. B2's window closes on 2026-10-31, so B2 is drawn
  and scanned no earlier than 2026-11-07, on the repeat run's date (the 14-21 day window begins after
  that for any letter sent from 2026-10-24 on), with the "no feed lists it" check made at scan time.
- **Results are effect sizes with intervals.** Tests are reported only for the paired comparisons,
  Holm-adjusted within each family (registry action, one family per feed); feed corrections and new
  flags are counts with dates, not tests.
- **Where it runs.** Every check runs on the study's sandbox host in a gVisor container
  (`--runtime runsc`, read-only data mounts, an unprivileged user; network only for the registry
  check), and its output is stored on two servers the day it is produced (see "Data custody").
- **Added the same day, before any part is run, following comments by Thomas Strömberg (the author
  of malcontent) on 2026-10-27, with thanks.**
  - *Stage 3's malicious set against the codebook.* Stage 3 took DataDog's labels as given. On the
    repeat run's date a random 100 of its 390 samples (50 npm, 50 PyPI; seed `2026102718` over the
    sorted keys) get blind bundles (`stage2_bundle.py`, from the DataDog archives on the sandbox host)
    and are rated by stage 2's two raters with its prompt (v2). Every package the two do not both
    call malicious, and a random 10% of those they do, is read in full by the analyst and given one
    label: *hostile* (its own files show a codebook behaviour, an explicit download-and-run
    included), *shell* (its only route to harm is a dependency, URL or download it names that cannot
    be checked from the package, with no codebook behaviour in its own files), *benign* (neither: a
    typosquat that does nothing, odd but harmless code), *spam* or *inconclusive*. Reported: the share
    of each label with Wilson intervals, and each scanner's recall on the sample three ways (DataDog's
    label; hostile only; hostile and shell), timeouts and crashes counted as misses as before. The
    published stage 3 numbers stay as they are.
  - *Atomdrift Scan.* Run with its defaults (its LLM option is off unless `--llm <url>` is given, and
    stays off), offline and as an unprivileged user, on the malicious set, benign A, benign B and B2,
    scored by the stage 3 rules and reported apart, labelled as added after the results. It was
        trained on DataDog's dataset, so its recall on the malicious set is reported with that caveat;
    its false alarms on the benign sets are the main result.
  - *A fresh malicious set.* Every scanner may have been trained or tested on DataDog's dataset
    (malcontent's author), so recall on old samples overstates what a scanner catches next. On the
    repeat run's date: DataDog samples whose archive date (in the file name) is after 2026-10-24, the
    day the scanner versions were fixed, one per package name; all of them, or 100 per ecosystem at
    random (seed `2026102719`) when there are more. Each is read against the codebook exactly as the
    100 above, and the four stage 3 scanners and Atomdrift Scan are run on it as on the malicious set.
    Reported apart, as the forward-looking number: recall on the hostile ones, and on hostile and
    shell, with Wilson intervals, and the set's size; an ecosystem with fewer than 30 hostile samples
    is reported as too few to rate.
- **Added the same day at the owner's decision, before any part is run: further checks.** Each is
  reported apart and changes no published number.
  - *Scanner results at a second threshold.* For every set, each scanner's recall and false alarms
    are also given at a second threshold: malcontent CRITICAL only (beside HIGH or CRITICAL);
    GuardDog `threat-*` rules only (beside threat or metadata); OSSGadget, which reports no severity,
    by its number of findings (at least 1, 5 and 20). The published stage 3 outputs are scored the
    same way.
  - *A second scorer for section 9.* The 300 records of part A are scored again, blind to the first
    scores, by stage 2's rater R1 (`qwen/qwen3.8-flash`) against the same five definitions and
    edge-case rules; Cohen's kappa per criterion, and every disagreement re-read by the analyst. A
    share changes only where that re-reading changes a score, and each change is listed.
  - *Benign sets read at random.* 50 packages per ecosystem from benign B and from B2 (seed
    `2026102720`), flagged or not, are read against the codebook as above; the share read as
    malicious, with Wilson intervals, bounds how many false alarms in those sets are not false.
  - *A dynamic run for what static reading cannot decide.* Every package the codebook readings above
    label *shell* or *inconclusive* is installed from its local archive (`npm install` or
    `pip install`, install scripts on) in a gVisor container with no network, as an unprivileged
    user, for 120 s; process starts, file writes outside the install directory, and every DNS lookup
    and connection attempt (answered by a local sinkhole, never forwarded) are logged. A codebook
    behaviour seen there makes the package *hostile*; nothing seen leaves the static label.
  - *More blind re-reading.* In the codebook readings above, a random 25% (not 10%) of the packages
    both raters call malicious are re-read blind; stage 2's agreed labels get a further random 15%
    blind re-read, 25% in all, with any change reported and the rates recomputed beside the
    published ones.
  - *Tools with too few rated flags.* For each tool and ecosystem with fewer than 10 packages rated
    in stage 2, all its flags older than 14 days whose packages are still served on the repeat date,
    up to 50 at random (seed `2026102721`), are rated by the stage 2 procedure and reported apart as
    a supplementary sample.
  - *How feed reports reach the registries.* npm's and PyPI's security teams get a short letter
    asking which feeds or tools report to them and how (trusted reporters, OSV imports, manual
    reports); their answers are reported, dated, beside stage 1.
  - *An outside timestamp.* This file, at the commit that fixes these additions, is deposited on
    Zenodo after publication (2026-11-03) and before the repeat run, so "fixed, then run" does not
    rest on our repository alone.
- **Added on 2026-10-29, before any part is run, at Vulnetix's suggestion** (its answer to our letter
  asked for "the repeat measurement … of the feed itself" and named the scanner to use). Each is
  reported apart, labelled as added after the results, and changes no published number.
  - *Vulnetix's STIX feed.* Public and free (AGPL-3.0): per-ecosystem STIX 2.1 bundles of DNS and URL
    indicators listed in `https://vulnetix.com/malscan-stix/index.json` with a SHA-256 for each
    and refreshed every 15 minutes. It names domains, addresses and URLs, not packages, so stages 1
    and 2 cannot measure it. On the repeat run's date the npm, PyPI and `generic` bundles are
    downloaded once, each checked against its SHA-256 in `index.json` and kept with the fetch time.
    (a) *Indicators.* Counts by kind; how many domain indicators, or their registrable domain, are in
    the top 10,000 of the Tranco list of the same day. Each of those is read by hand and labelled a
    legitimate service, a legitimate service used for harm (a paste or file-sharing site, a webhook
    endpoint), or unclear. This is a lower bound on indicators that would flag ordinary code.
    (b) *In packages.* For every stage 3 set (malicious, benign A, benign B, B2 and the fresh malicious
    set), how many packages contain an indicator of their ecosystem or of `generic` in any file, with
    Wilson intervals. A domain indicator matches a whole host name or a parent domain of one,
    case-insensitively; a URL indicator matches as an exact string. That is the feed's recall and its
    false alarms when used to match package text, the way the advisory database's
    `IOC-STIX-MATCH` rule used it.
  - *The Vulnetix CLI's malware scan,* `vulnetix malscan` (malscan-engine in process), which Vulnetix
    named as the natural choice for an unpacked package. The latest CLI release on the repeat run's
    date is used, with its version and the binary's SHA-256 recorded. Its definitions and indicator
    feeds are fetched once that day (`--fetch-definitions`), outside the scanning sandbox, and kept
    with checksums. Then every package of the sets above is scanned offline in a gVisor container as
    an unprivileged user, `--path <unpacked package> --no-upload --no-analytics --output json`, with
    those definitions, 300 s per package. A flag is any finding the CLI reports as malware; it is scored
    by the stage 3 rules. If the scan needs an account, the run uses a free account the owner opens,
    and says so. If it cannot run without network, it runs with network allowed only to Vulnetix's
    definition endpoints, and says that too. Its indicators may include ones drawn from DataDog's
    dataset, so its recall on the malicious set carries the same caveat as the other scanners'.
    *Amended on 2026-11-01, before any part is run, from Vulnetix's answers to our questions.* No
    account is needed. The scan finds what to check from install locations, so a bare unpacked
    directory reports `INCOMPLETE` (nothing checked). Each package is therefore placed where an
    installer would put it, one package per scan, and the parent directory is passed as `--path`:
    - npm: the tarball's `package/` contents at `node_modules/<name>/` (`node_modules/@scope/name/`
      for scoped names);
    - PyPI wheels: unpacked into `.venv/lib/python3.12/site-packages/` as pip would place them;
    - PyPI sdists: the unpacked source tree at `site-packages/<name>/`, not built, since building
      runs the package's code. Wheels and sdists are reported apart.

    `--fetch-definitions` runs once with `VULNETIX_MALSCAN_DEFS_DIR` set to a directory kept with
    checksums. Every scan then uses that directory read-only.

    A flag is the package-level verdict, the top-level `"malicious": true` in `-o json` (exit
    code 1). Each finding's `Class` is counted (`evidence`, `trigger`, `context`), and the terminal
    grouping into MALICIOUS or SUSPICIOUS is kept as a second threshold. An `INCOMPLETE` result
    counts like a timeout: a miss on malware, left out of the false-alarm rates, and reported by
    count.

    Vulnetix cautions that malscan relies on a customer's environment and context, and that a bare
    run will not give the outcomes it gives in production. The results are reported with that
    caveat, as a measurement of the CLI on single packages, offline.



## Transparency and response, fixed on 2026-10-27 before it is measured

Whether a third party can see why a package was flagged, and whether a feed answers the people it
flags, are measured for completeness of the analysis. Added after the exchange with Vulnetix; the
criteria below are fixed before any feed's records are read for them, and every scored record is
published with the text its score rests on.

**A. What each record shows.** From the pinned stage 1 snapshots, 30 records per tool of kind
`malicious` (OpenSSF) or `static-rule` (Vulnetix), npm and PyPI together, drawn at random (seed
`2026102710`; all when a tool has fewer). For OpenSSF records only the tool's own section of the
record is read (`## Source: <tool>`), plus the record's summary and references. Each record is
scored yes or no on:
- **Evidence:** it names something a third party can find and check in the package: a file, a code
  excerpt or matched line, an indicator (domain, IP address, URL, hash) or an observed action (a
  process started, a network destination).
- **Reason:** it says in its own words what the package does that makes it malicious, beyond a
  template line such as "Malicious code in X".
- **Method:** it says how the package was found: a rule name or id, dynamic analysis, a manual
  review, a third-party report.
- **Versions:** it names the affected versions, or says all versions (read from the structured
  fields).
Scored by the analyst against these definitions; a script also records simple proxies (length of
the tool's own text beyond the template, presence of paths, URLs or code) as a cross-check. Per
tool: the share of records with each, Wilson 95% intervals.

**Rules for the edge cases, fixed the same day while reading the records and before any share was
computed.** The definitions above did not settle these:
- An OpenSSF section header carries a hash after the tool's name (`## Source: kam193 (6b1e…)`); it is
  matched on the name. A tool with no section of its own (all of ReversingLabs' and the uncredited
  records) is read from the record's text above the per-source part.
- Records may carry a structured `iocs` block (files, domains, URLs, hashes). It counts as evidence
  for a tool when the record credits that tool alone; on a record credited to several tools it is
  not attributed.
- References are reported apart, as **linked evidence**: a reference to an analysis of this package
  (a sandbox run, a file analysis such as VirusTotal, the tool's own page for the package), counted
  when the record credits the tool alone or the link is on the tool's own site. A campaign write-up,
  a registry page or another feed's record is not linked evidence.
- A reason must be about this package or its campaign. A sentence that would be true of any package
  ("installing it may execute code", "found to contain malicious code") or advice on what to do is
  not a reason; a named behaviour is ("communicates with a domain associated with malicious
  activity", "steals credentials", "typosquats numpy"), however short.
- Method needs the record's text: a named analysis system, static or dynamic analysis, a rule, a
  detection by another engine, a manual review, a report by someone. The source header alone, which
  every OpenSSF record has, does not count.
- Versions count when affected versions are listed or a range is given (a range from 0 says all
  versions); they are record-level fields.

**B. What each feed publishes about itself,** checked on its public pages and repositories, each
answer with its source: records downloadable in bulk under an open licence; the detection method
documented; a documented public way to report a false positive; withdrawals visible, with a reason.

**C. How each feed answers.**
- **Public disputes:** reports in a feed's public tracker, filed 2025-01-01 to 2026-10-27, that say
  a record is wrong (in `ossf/malicious-packages`, by the tool the disputed record credits; in
  `Vulnetix/advisory-database`; in `github/advisory-database` for malware advisories), read through
  the public GitHub API. Per feed: how many, the median days to the first answer by the feed's
  maintainers, the share resolved by a withdrawal or correction, the median days to that.
- **Our letters:** for each recipient, whether and when it answers (days after sending), within the
  seven days before publication and within 21 days, and whether the answer takes up our questions.
  For a feed with no public tracker, this is the only measure of response.

**Reporting.** One table beside the accuracy results: per feed, open data, evidence, reason and
method per record (shares), a dispute channel, public disputes (count, median days to answer and to
resolution), and the answer to our letter. No score is combined into a rank.

## Pitfall checklist (Arp et al.)

| Pitfall | Here |
|---|---|
| P1 sampling bias | Populations named per stratum; random draws with a fixed seed; estimates weighted by stratum size; ecosystems not pooled. |
| P2 label inaccuracy | No single source is ground truth; registry action, feed withdrawal and cross-feed agreement are reported apart; stage 2 uses blind double rating with κ. |
| P3 data snooping | Methodology and keyword rules fixed before results were read; changes listed with reasons; snapshots pinned. |
| P4 spurious correlations | Stage 3 breaks errors down by rule, so a scanner that keys on names or file layout shows it. |
| P5 biased parameter selection | Scanners run with defaults; no threshold tuned on the test data. |
| P6 inappropriate baseline | Every tool is compared on the same packages; the simplest rule (a single keyword) is reported as a baseline in stage 3. |
| P7 inappropriate measures | Precision and recall are given with counts, intervals and per-1,000 false positives. |
| P8 base rate fallacy | False alarms are also expressed at real registry volume and prevalence. |
| P9 lab-only evaluation | Stage 1 and 2 use the live feeds and registries as they are today. |
| P10 inappropriate threat model | Kinds keep spam and research probes apart from code that harms the installer. |

## Limits we know of

- Closed tools (Socket, Snyk, Phylum/Veracode, Aikido, JFrog, Sonatype) appear only through what
  they publish to open feeds; most do not attribute there. "Maximum coverage" means every tool with
  open, attributable data, not every tool on the market.
- OpenSSF attributes records to origins; it does not say which origin was right.
- Keyword kinds are coarse; a misclassified record moves between `malicious` and the others. The
  rules and the counts per rule are published so this can be checked.
- npm package names are reused after unpublish; a 404 today can hide a later republish.
- Feeds differ in age and volume; a tool with few records gets wide intervals, which are shown.
- Every scanner may have been trained or tested on stage 3's malicious set (Thomas Strömberg,
  2026-10-27), so its recall there is likely optimistic for future malware; the repeat run adds
  samples published after 2026-10-24.
- Stage 3's malicious set is DataDog's dataset and GuardDog is DataDog's scanner; if GuardDog helps
  admit samples to the dataset, its recall here is flattering. DataDog is asked, and the answer is
  published.
- The per-row registry status of 2026-10-24 is lost (change log, 2026-10-27): comparisons with it are
  unpaired; the paired comparisons start from the 2026-10-27 re-check of the same rows. That re-check
  gave the same counts as 2026-10-24 in 24 of the 26 strata; the other two moved by a few rows
  (Amazon Inspector npm research 298 to 301 of 319, Amazon Inspector PyPI malicious 352 to 353 of
  400). So the lost per-row status differs from the 2026-10-27 one in only a few rows, and since no
  letter had been sent by 2026-10-27, nothing about the letters' effect is lost (change log,
  2026-10-27, the new baseline; `stage1/out/compare_2026-10-24_vs_2026-10-27.json` in the manifest).
- The models that rate stage 2 are named, versioned and asked the same codebook; they are not
  people, and every disagreement and a blind re-check were read by a person.

## Ethics and disclosure

- Stage 1 contacts no one and runs nothing.
- Package names of probably-benign flags are not published; they go only to the feed concerned.
- Each feed gets its own numbers and this methodology seven days before publication, and its
  answer is published with the results.
- Scripts, seeds and snapshot commits are published so anyone can repeat the numbers.

## Data custody and publication

Added on 2026-10-27, after the stage 1 data was lost from a workstation's temporary folder.

- **Two servers, the day it is produced.** Every dataset the study produces (snapshots' derived
  records, samples, registry statuses, rater outputs, labels, scanner outputs, scores) is written to
  `/root/mfa-study/` on the study's sandbox host and copied to a second server the same day. A
  workstation or a temporary folder is never the only copy.
- **Checksums in the repository.** `data-manifest.json` beside this file lists each dataset with its
  SHA-256, size, row count and the commit and command that made it, so a copy can be checked and a
  lost file is known to be lost.
- **Published with the results.** At publication the datasets go into one archive with a DOI: the
  stage 1 sample and every registry check of it; stage 2 bundles' metadata, both raters' outputs,
  labels and adjudications; the stage 3 sets and every scanner's output; the scripts at a tagged
  commit. Feed snapshots are cited by commit, not copied.
- **What the archive leaves out.** Every package rated in stage 2, the malicious ones too (several
  frames were rated whole, so naming the malicious rows would name the benign ones by
  elimination), the stage 1 rows of those packages, and the packages of benign sets A, B and B2
  carry no package name and no feed record id (a record id names the package): a fresh random id,
  tool, ecosystem, label and outcomes only, as the ethics rule says. Free text that quotes the code
  (rater evidence and summaries, adjudication reasons) is left out. No package file,
  and so no live malware, is in the archive; malicious samples are named by the dataset they came
  from.

## Acknowledgements

Thomas Strömberg, the author of malcontent, read the study on the day the letters went out
(2026-10-27). The comments improved the repeat measurement: stage 3's malicious set read against
the codebook, a fresh set of samples no scanner can have seen, and Atomdrift Scan ("Added the same
day" under the repeat measurement). The advice against running scanners as root matches the
unprivileged user the repeat run already uses. Thank you.

## Reproduce

```
bash fetch_snapshots.sh            # both snapshots at the pinned commits, same sparse paths
python3 -I normalize.py --ossf ossf --vulnetix vulnetix > records.jsonl
python3 -I registry_check.py records.jsonl --per-stratum 400 --seed 20261024 --plan-only > sample_plan.jsonl
python3 -I registry_check.py records.jsonl --per-stratum 400 --seed 20261024 > status.jsonl
python3 -I analyze.py records.jsonl status.jsonl
```

The sample depends on the order of the rows in `records.jsonl`, and `normalize.py` reads the
snapshot files in the order the filesystem lists them. The original records file was made on macOS
(APFS); made on another filesystem, the same records come in another order and the same seed draws
other rows. Use the stored `records_ov.jsonl` (its SHA-256 is in `data-manifest.json`), or rebuild it
on APFS and compare the checksum.

## Changes after the results

- 2026-10-24, implementation fix found while scoring stage 2, **changes stage 1 numbers again**:
  npm can still list the versions a held name replaced after their tarballs are deleted (404).
  `registry_check.py` counted a listed version as served, so such names were `live`. For a held
  name (one that lists npm's holder) the check now asks for each listed version's tarball and
  counts only those that answer. The stage 1 sample was checked a third time on 2026-10-24
  (`status_ov_v3.jsonl`, same rows and seed). Stage 2 sample packages the check now finds held
  leave the frame, as the earlier placeholder fix ruled. Two of them were still waiting for
  adjudication when this was found.
- 2026-10-24, found by the audit, **changes stage 2 labels**: the bundle builder broke its own rule
  that long files are "cut and their length noted". It skipped any file over 3 MB without a word,
  and it did not read `binding.gyp`. npm runs `node-gyp rebuild` at install when a package has a
  `binding.gyp` and no install script, and node-gyp runs any `<!(…)` command in it. Five sample
  packages ship the same 157-byte `binding.gyp`, which runs a 4.5 MB `index.js`. That file is a
  ROT-n character array around AES-128-GCM code, which downloads the bun runtime and runs a second
  encrypted payload. Neither rater saw that file. Raters disagreed on two of the five, which went
  to adjudication and were labelled malicious. They agreed `benign` on the other three. The 10%
  audit drew one of those three, and the analyst's reading changed it to `malicious`. Rule applied
  once the cause was known: every sample package the builder had shortened is adjudicated by
  reading the whole package. That covered the two other `binding.gyp` packages (both `malicious`,
  same loader, decoded statically on the sandbox host) and six packages with large files. Those
  six kept their labels: generated bindings, built web apps, a bundled CLI, monaco-editor. The
  raters' labels on all of these are reported as given, with a note that their bundles were
  incomplete. Rater accuracy on the controls is unaffected: no control has a file over 3 MB or a
  `binding.gyp`. `stage2_bundle.py` now treats `binding.gyp` as a hook and reads a large file from
  its start, noting the cut, as written. Stage 3 does not use the bundles.
- 2026-10-24, audit of a placeholder record: for an OpenSSF record that flags `all` versions, the
  bundle took npm's `latest` tag. In one sampled case that tag is npm's 2016 holder,
  while the older versions are still served. The analyst read the newest real version instead. The
  label is unchanged (`benign`, name squatting from 2016), but the case is reported.

- 2026-10-24, implementation fix found during adjudication, **changes stage 1 numbers**: npm also
  holds packages as `0.0.1-security.0`, `.1`, …, not only `0.0.1-security`; `registry_check.py`
  recognised only the latter, so re-held packages whose records name no versions were counted
  `live`. The check now matches `0.0.1-security(.N)`. The stage 1 sample (same rows, same seed) was
  checked again on 2026-10-24 afternoon; the old results are kept (`status_ov.jsonl`), the
  published stage 1 tables are recomputed from the new check, and the docs say so. Stage 2: sample
  packages the corrected check finds held are no longer in the frame; their ratings are not
  counted and their number is reported. The rest of the sample stays a random draw from the
  corrected frame, since being held is unrelated to the draw.
- 2026-10-24, implementation fix before set B was scanned: PyPI's changelog returns at most 50,000
  rows per call, so the first draw of benign set B covered 2026-10-09 15:21Z to 10-10 23:49Z
  instead of the whole week. `stage3_recent.py` now pages through the changelog and refuses a
  window it does not cover. Set B was drawn again with the same seed; the truncated draw is kept
  (`s3_benignB.truncated-pypi.json`) and not used.
- 2026-10-24, adjudication evidence and audit, fixed before any disagreement was looked at
  (deviation from the stage 2 protocol). The sandbox run cannot be done as written: HISTOR's
  observer refuses source-only PyPI packages by design (building one runs its `setup.py`, where
  most PyPI payloads sit) and its behaviour trace is unavailable outside its own service
  (`trace-unavailable`). Adjudication therefore rests on reading the **whole** package on the
  sandbox host (every file, not the 60 KB bundle), never on running it; this is stated next to
  every stage 2 number. Audit: the owner and the analyst review, blind to the flagging tool, every
  disagreement and `inconclusive`, plus 10% of agreed labels drawn at random (seed `20261028`);
  feeds are revealed only after all audit decisions are written. Both auditors are interested
  parties (one feed lists the owner's packages); that is stated, and how many labels the audit
  changed is reported.
- 2026-10-24, raters changed before any counted result (deviation from the stage 2 protocol). The
  OpenRouter account ran out of credit mid-run (HTTP 402 from 13:39Z); the owner judged the two
  pre-registered raters too expensive for the job. New procedure, fixed before the rerun:
  1. **Candidates:** low-cost models of vendors that run no feed in this study:
     `deepseek/deepseek-v4.1-flash`, `z-ai/glm-5.3-flash`, `qwen/qwen3.8-flash`,
     `minimax/minimax-m3.1-flash`, `z-ai/glm-5.3`.
  2. **Selection on half of the controls:** the 60 controls are split at random (seed `20261026`)
     into a selection half and a held-out half, 15 malicious and 15 benign in each. Every candidate
     rates the selection half; the two most accurate candidates of different vendors become R1 and
     R2 (ties: the cheaper one). Choosing on the same controls would bias the accuracy reported for
     them, so their accuracy is reported only on the held-out half, where the 90% bar applies.
  3. **The counted run:** R1 and R2 rate the full sample and the held-out controls with the final
     prompt. Ratings by the first pair (`openai/gpt-6.1-sol`, `moonshotai/kimi-k3.1-pro`) are not
     counted.
  4. **Expensive versus cheap, descriptive only:** the packages the first pair did rate (about 25,
     paid for already, about $2) are rated again by every candidate with the same prompt version
     the first pair saw; agreement is reported per model as a small, descriptive comparison, no
     inference drawn. No further runs of the first pair are made.
- 2026-10-24, blinding fixes before the counted rating run: DataDog's control archives carried a
  `package_info-*.json` copy of registry metadata and `tmp/tmpXXXX/<name>/` paths that no registry
  download has; `stage2_bundle.py` now reads that metadata into the same fields and rebuilds the
  paths. The artifact URL and upload time are dropped from every bundle at rating time, as controls
  cannot carry them alike. A first rating run had started with them; its 33 ratings are kept in
  `ratings_sample.discarded-prompt-v1.jsonl` and not counted.
- 2026-10-24, stage 2 operations, before any sample package was rated: both raters get the same
  output limit of 8,000 tokens (R2 is a reasoning model and spent a 1,500-token limit on reasoning
  before answering); benign controls come from hugovk's top-pypi-packages (ClickHouse, 30 days) and
  packages.ecosyste.ms for npm, top 5,000 each, as ecosyste.ms timed out on PyPI pages; malicious
  controls are one sample per package name, so a campaign of many versions is not over-drawn
  (DataDog dataset commit 21822443). Package names stay in the bundles, so a famous benign control
  is easier to recognise than a sample package; control accuracy is read with that in mind.
- 2026-10-24, a fact corrected: Vulnetix lists nine of our packages, not six; three records
  (2026-10-17 and 2026-10-22) were found when all 77 of our packages were matched against every
  feed. An own-packages case study was added (own-packages/: package lists, GuardDog 3.2.0 script
  and raw output); it is reported apart from the measurements and draws no accuracy conclusion.
- 2026-10-24, an interpretation limit added after the results: "registry acted" also depends on
  whether a feed's findings reach the registries at all (OpenSSF records reach npm and PyPI; some
  tools are PyPI trusted reporters; for others the path is unknown). A low share can therefore come
  from the reporting path, not only from accuracy. Stage 1 results are worded with this explanation
  next to the others; stage 2 does not depend on it.
- 2026-10-24, implementation fix, not a change of method: for Vulnetix rows `normalize.py` took the
  flag's date from the registry's publish date of the package version, not from the record's own
  `published` field, so our Vulnetix rows had no ages on npm and wrong ages on PyPI (our parsing error, not the
  feed's). Found while
  spot-checking `live` rows; the definition ("check time minus the record's `published` time") was
  right and is unchanged. Registry status does not depend on it and was not re-drawn.
- 2026-10-25, found while re-checking the Amazon Inspector PyPI labels, **adds a second stage 2
  rate, does not replace the first**: the stage 2 sampler did not leave out records the feed has
  since withdrawn, and the protocol did not say whether a withdrawn record is still a flag. 24
  rated rows come from withdrawn records (Amazon Inspector 19 PyPI and 3 npm, GHSA 1, OSSF Package
  Analysis 1; Vulnetix none; one more is held by the registry and out of the frame anyway), among them `fastapi` 0.136.3, which Amazon Inspector flagged for an
  undocumented `fastar` extra and later withdrew. A consumer of the feed no longer sees a withdrawn
  record, so `stage2_score.py --withdrawn` reports the rate among records still standing beside the
  pre-registered one. Both are published, labelled; neither is called "the" rate.
- 2026-10-25, the re-check itself, no label changed: the 32 Amazon Inspector PyPI packages labelled
  benign were searched for code that sends host, account, environment or file data out, or runs a
  fetched payload; every match and every package with a squatting-like name (12 in all, among them one that fetches licence tokens from pastebin and compares the local IP but sends
  nothing, and a squat of sklearn's name holding ML tutorial snippets) was read in full on
  the sandbox host. None meets the codebook's "malicious"; several would meet a broader "suspicious"
  definition, which is how the results are worded.
- 2026-10-25, stage 3 operations, decided before any benign B result was looked at: OSSGadget
  0.2.38's dotnet tool package ships without its `BackdoorRules`, and `detect-backdoor` then
  returns no results for every package without saying so; the image adds the rules of the same tag
  (github.com/microsoft/OSSGadget v0.2.38, `src/Shared.CLI/Resources/BackdoorRules`), which is the
  tool's default rule set. Packj 0.15 cannot be run as the protocol requires: it audits only a
  registry name (`-p ecosystem:name:version`) and downloads the package itself, while the runs have
  no network and most of the malicious set is gone from the registries; it is listed with that
  reason. Vulnetix's `malscan-engine` (d0505f3) is a Go library with no scanning command (its one
  command, `genblocklist`, builds a block list); writing our own driver for it would be our reading
  of its API, so it is listed as not runnable. malcontent's report names only files with a
  behaviour, so a package absent from it was read and found clean; files malcontent could not open
  (permission denied, logged to stderr) mark their package as partially read, counted apart.
  Base rate for the realistic mix: the distinct package names in OpenSSF malicious-packages records
  of kind malicious published in the benign B window (npm 116, PyPI 20), over the window's volume
  (PyPI: 28,833 projects with a new release; npm: 1,711,841 replication-feed changes, recomputed by
  the same bisection, times 200/228, the share of drawn changes whose package published in the
  window; an estimate). It is a lower bound (only malware someone caught), stated with every
  base-rate number (`stage3_volumes.json`).
- 2026-10-25, stage 3 operations, before malcontent's benign numbers were scored: malcontent's image
  runs as uid 65532 and could not open 2 files of benign A and 233 of benign B (permission denied in
  its log; the other scanners run as root and read them). Read access was opened on the unpacked
  copies and malcontent re-run on both benign sets; the malicious set had no such file.
- 2026-10-25, **deviation**, how benign B flags were read: the protocol says every package a scanner
  flags in benign B is read by hand. OSSGadget flags 358 of the 397, so that means reading the whole
  set. What was done instead: (1) every package's registry status was checked again a week after the
  draw (one gone, a Rust CLI that talks only to PyPI and OSV: read, benign);
  (2) the codebook's behaviours were searched for in all 397 unpacked packages (sending host, account
  or environment data out; running a fetched payload; persistence next to network or process code;
  install hooks with network or process code) and every hit, 33 packages, was read where it hit;
  (3) ten packages only OSSGadget flagged (random, seed 20261025) were looked at for what it matched
  (README headings, `return this;`, type annotations). None was read as malicious. One is borderline: a process manager whose postinstall installs a boot service on a global install and says
  so; read as benign under the codebook's intent (declared function, not hidden). Benign B stays
  "unflagged, not proven benign"; its false-positive counts rest on these reads.
- 2026-10-27, **data lost, sample rebuilt, new baseline**: the stage 1 records file and the three
  registry checks of the sample (`status_ov*.jsonl`) existed only in a workstation's temporary folder,
  which was emptied on 2026-10-27. The published counts are unaffected; the per-row registry status of
  2026-10-24 is lost for good. Rebuilt the same day from the pinned snapshots (`fetch_snapshots.sh`,
  `normalize.py` on APFS): 242,072 rows, and every per-source count, withdrawal count and the spam
  count equal the published tables. The sample redrawn with seed 20261024 (`--plan-only`): 7,483 rows,
  6,845 packages, 32 strata, every stratum's size and draw equal to the published ones, and all 282
  stage 2 sample packages are in it (a different draw would hold about a sixth of them). The same
  draw comes out byte for byte in a gVisor container on the study host. Stored on two servers with
  checksums in `data-manifest.json`. The repeat measurement is amended accordingly (its section),
  and the same rows are checked again on 2026-10-27, before any letter, as the new paired baseline.
- 2026-10-27, disclosure: a version of the write-up with stage 1 only has been in the public GitHub
  mirror of the repository since 2026-10-25 08:55Z, before any letter. The letters say so; the
  seven days before publication count from the letters for the full write-up.
- 2026-10-27, the new baseline: the rebuilt sample was checked on 2026-10-27 04:26Z in a gVisor
  container on the study host (7,483 rows, no registry errors; `status_2026-10-27.jsonl`). Against
  the published 2026-10-24 counts (`stage1_compare.py`, unpaired), 24 of the 26 published strata have
  the same count of rows the registry acted on; two rose: Amazon Inspector npm research 298 to 301 of
  319, Amazon Inspector PyPI malicious 352 to 353 of 400. Equal counts on 24 strata three days later
  are what the same rows give and different rows would not, which supports the rebuild.
- 2026-10-27, **run 1 restored and checked**, all three stages, every step in gVisor containers:
  - Stage 3: `stage3_score.py` over the raw scanner outputs kept on the sandbox host gives every
    published number again: recall, false alarms per 1,000 in sets A and B, false alarms a day at
    PyPI's base rate, recall by half-year, for all four scanners in both ecosystems.
  - Stage 2: the scoring inputs were rebuilt (`restore_stage2_inputs.py`): the 42 adjudications and
    17 audit readings are replayed in order from the session log, where each was one command, with
    the one audit row run 1 rewrote in place (inconclusive to benign, after reading its newest real version); the key map from the rebuilt sample (all 285 keys found, and each stratum's count equals
    its frame at fixing: 24, 45, 35, 13, 16, 2, 1, 1, and 50 drawn from unknown npm and from each
    Vulnetix frame); the held packages from the 2026-10-27 check (80, as on 2026-10-24); the published
    frame sizes; the withdrawn ids. `stage2_score.py` then gives the published results exactly:
    Cohen's κ 0.715 (n = 202), 162 agreed, 33 adjudicated, 8 adjudicated although agreed, 78 held,
    17 audited (one changed, benign to malicious), every rate in both tables, and 29 of 30 held-out
    controls for each rater.
  - Stage 1: as recorded above (rebuilt records and sample, the 2026-10-27 baseline).
  All inputs and outputs are on two servers with checksums in `data-manifest.json`.
- 2026-10-27, transparency and response measured. Part A: 300 records (30 per tool) drawn and
  scored in a gVisor sandbox on PingBlip, judgements as data in `transparency_score.py`; part C: 100
  disputes read from the three public trackers (fetched read-only through the GitHub API), outcomes
  as data in `disputes_measure.py`; part B from each feed's own pages. Results in section 9 of the
  write-up; data in `transparency/` with SHA-256 in the manifest, kept on two servers. Found while
  measuring: Vulnetix's withdrawal index served on 2026-10-27 lists 6,762 of the 7,362 npm and PyPI
  records of the stage 1 snapshot, each with an OpenVEX statement. The index is kept; Vulnetix
  dates its audit to 2026-10-25, but the index has no separate withdrawal timestamp. The repeat
  measurement counts these as withdrawals made before the letters.
- 2026-10-27, **data archive built, and names taken out of this file**: `build_archive.py` makes the
  archive for the DOI deposit and `verify_archive.py` recomputes every stage 1 count, stage 2 label,
  rate and kappa, and stage 3 number from the archive alone. The archive applies the ethics rule
  more strictly than "Data custody and publication" first wrote it (that section now says how).
  Five names of packages read as benign appeared in earlier entries of this change log; they are
  replaced by descriptions. The two package keys in `restore_stage2_inputs.py` (a key is a hash of
  the name with a published salt) moved to a data file kept on the two servers; the code's logic is
  unchanged. `fastapi` stays named: the feed withdrew its record and the project is widely known.
- 2026-10-27, **letters sent; an addition after the results**: the letters went out on 2026-10-27 with
  publication on 2026-11-03. malcontent's author, Thomas Strömberg, answered the same day, and the
  method is improved following the comments: in the author's observation malcontent has not been actively
  developed for six months (any announcement is Chainguard's), Atomdrift Scan is its open-source
  successor, and HIGH marks suspicion, not a verdict.
  At the author's suggestion Atomdrift Scan is added to the repeat run, and the third note (DataDog's set holds
  items that only look odd, or are shells around remote dependencies that are gone) adds a reading of
  100 of stage 3's malicious samples against the codebook; the fourth note (every scanner has likely
  been trained or tested on DataDog's dataset, so it cannot predict accuracy on future samples) adds a
  recall test on samples DataDog published after 2026-10-24. All three are written into the repeat
  measurement ("Added the same day") before any part of it runs; none changes a published number.
- 2026-10-29, **wording only**: the reports' section 5 and this file's section on transparency and
  response said why section 9 is measured as the owner's personal view. They now say it is measured
  for completeness of the analysis. No criterion, score or number changes.
- 2026-10-29, **Vulnetix's answer, and what it asked for**: Vulnetix answered our letter of 27 October
  and asked to be quoted verbatim; the write-up quotes it in full and answers its questions with
  dated numbers, none of which changes a published one. (1) The Vulnetix source is described as what
  it is: the GCVE advisory database in its first week, not Vulnetix's malware feed (see "Data").
  (2) Of the 100 Vulnetix records rated in stage 2, Vulnetix's index of withdrawals of 2026-10-27 lists
  95, all with `modified` dates of 25 October (npm 45 of 50, PyPI 50 of 50): 94 of the 97 read as benign and 1 of the 3
  read as malicious. On 29 October (Vulnetix's `index/manifest.json` at commit `48a29d8e8e2e`), two
  read as benign and two read as malicious are still published as malware, and one read as benign is
  a vulnerability record. (3) "The 600 records that remain" is defined: the npm and PyPI records of
  the stage 1 snapshot that are not in that index of withdrawals (329 npm, 271 PyPI). On 29 October
  577 are still published as malware, every one approved by `review.method: auto_rule` (571 on
  19 October), and 23 are vulnerability records (8 of them ours, 13 approved by a person). None was
  withdrawn after 27 October. (4) Correction to our letter: it said all 6,762 withdrawals came on
  25 October; 6,759 records in the index have `modified` dates of 25 October and 3 of 24 October.
  These are record-modification dates, not separate withdrawal timestamps; they do not establish
  the exact time of each withdrawal or its timing within 24 October.
  (5) Additions to the repeat measurement, fixed above before it is run: Vulnetix's STIX feed and the
  Vulnetix CLI's malware scan. (6) The names of the 97 packages read as benign in Vulnetix's sample,
  with the reading behind each label, go to Vulnetix alone, at its request ("Ethics and disclosure");
  its review is reported with its date. Code: `vx_followup.py` and `vx_review_methods.py`, run in a
  gVisor container on the sandbox host (the first) and against Vulnetix's public repository at the
  pinned commit (the second). The list of the 600 is published in `transparency/`; the private file
  with names stays on the two servers.
- 2026-10-29, **withdrawal-date wording clarified**: the reports and this file distinguish the
  withdrawal index served on 27 October, its records' `modified` dates, and Vulnetix's own account
  of an audit on 25 October. No count, label, criterion or planned measurement changes.
- 2026-11-01, **Vulnetix's second answer**: Vulnetix answered our reply of 29 October; the write-up
  quotes it verbatim beside the first. It confirms the counts among the 600 (577 malware,
  23 vulnerability) and that the index's `modified` date is not a withdrawal timestamp (the wording
  already says so). It names OWASP's Transparency Exchange API and GCVE as the basis of its offer to
  the registries. It answers the `auto_rule` question, quoted as given. It points to the DISPUTES.md
  added to its repository on 31 October; section 9 is not re-scored for it. It confirms receiving the
  names and says it will publish its reading of each, dated, which the repeat measurement counts. The
  malscan protocol above is amended from its answers before any part is run. No published number
  changes.
- 2026-11-02, **check before publication**: the reports add dated counts of what Vulnetix changed after
  our letters (Vulnetix commit `f5038075304e`). On 1 November it set the fixed versions of
  000636-000644. Among the 600 records, 52 were withdrawn and 5 reclassified as vulnerabilities,
  leaving 520 published as malware. One more of the 100 rated records, read as benign, was
  withdrawn. The repeat measurement counts all of these as changes after the letters. The STIX feed
  is cited by its `index.json`, since the folder address does not answer. No published number changes.
