"""Static AICOM / AIMarket ecosystem brief for ATLAS Analyst.

Sensor numbers always come from the live ATLAS snapshot. This brief answers
architecture / product / URL questions about the broader economy.
"""

from __future__ import annotations

ECOSYSTEM_BRIEF = """
## AICOM / AIMarket ecosystem (authoritative brief)

Mental model: **aicom** (Factory) builds products → listed & invoked via **AIMarket**
(protocol + Hub) → **oracles ×17** sell signed math → **Metis** verifies high-stakes
cognition → **GAIA** sells attested physical-world readings → **ATLAS** (you) maps those
readings → **ARGUS** is the human touchpoint → priced on **ACEX** → visualized in 3D by
**Alien Monitor**. Beyond ARGUS, humans configure infra; machines trade.

### Core rails
- **AI-Factory** (magic-ai-factory.com) — autonomous multi-agent pipeline that designs,
  builds, tests, and publishes products / capabilities into the Hub.
- **AIMarket Protocol v2** (aimarket-protocol) — open standard: discovery, channels,
  invoke, settle, signed manifests (/.well-known/ai-market.json).
- **AIMarket Hub** (modelmarket.dev, :9083) — federated capability catalog, search,
  invoke, payment channels, plugins (safety, TEE escrow, reputation, provenance, …).
- **AI Service Mesh** (:8090, service-mesh.modelmarket.dev) — agent discovery,
  zero-trust verify, escrow, agent-to-agent payments.
- **HEPHAESTUS studio** (modelmarket.dev/studio) — composes a chain of catalogue
  capabilities, prices the graph BEFORE anything is paid for, submits it to the
  factory's pipeline executor, and keeps the signed bill of materials (hop-level
  blame on failure). Alien Monitor node `hephaestus`. Not a satellite repo — it is
  a page the Hub serves plus a framework-free core in `hephaestus/`.
- **SDKs / clients** — aimarket-agent (Python), aimarket-sdks (TS/Rust/Dart),
  aimarket-widget (embed), aimarket-desktop (Flutter/Tauri/VS Code SKUs),
  aimarket-bridges (LangGraph / CrewAI / AutoGen adapters with signed receipts).

### Oracle classes (three tiers)
1. **Math oracles ×17** (oracles.modelmarket.dev) — Platon, Chronos (VDF), Lattice,
   Murmuration, Lumen (EigenTrust/PageRank reputation), Colony, Turing, Ablation,
   Percola, Fermat, Gauss, Sortes, Aestus, Betti, Kantor, Fourier, Landauer, …
   Ed25519-signed artifacts; MCP via aimarket-oracle-gateway (~35 tools).
2. **Cognitive — METIS** (metis.modelmarket.dev) — Understanding Council → confidence
   gate → layered MoA → verifier; OpenAI-compatible; factory confidence gate;
   PyPI aimarket-metis. Shared tools via **aimarket-mcp** (web_fetch, web_search,
   metis_verify; SSRF-hardened).
3. **Physical — GAIA** (iot.modelmarket.dev, :9320) — virtual IoT + LIVE public-API
   relays. Each reading Ed25519-attested + statistical plausibility; Pay-on-Verified
   escrow. Same Hub discover → channel → invoke → settle loop. Not oracle_call.
   SKUs are generated from the ATLAS catalog (table below) — do not invent ids.
   LIVE only with provenance source. Operator table: gaia/docs/LIVE-RELAYS.md.

### ATLAS (this product)
Planetary **MapLibre** sensor map over GAIA relays. Pins are **LIVE** only when GAIA
exposes provenance `source`; otherwise **SIM**. Public: atlas.modelmarket.dev ·
embed: /embed · Alien Monitor node id=`atlas`. Analyst uses the server snapshot for
numbers, ATLAS SURFACES (live from STATION_CATALOG) for map SKUs, and this brief
for ecosystem Q&A. ATLAS does **not** write sensors, but it **does sell Hub
composites** (see generated physical table). Every clickable point is addressable
through point.read; watchbox/nearest cover every LAYER_META layer.

<!-- BEGIN GENERATED physical-capabilities -->
### Physical and map SKUs

Generated from ATLAS STATION_CATALOG + LAYER_META + PRODUCT_CAPS — do not hand-edit. Run: python3 scripts/sync_knowledge_base.py --write. Live Hub search is the ceiling (GET https://modelmarket.dev/ai-market/v2/search). This table is the floor. Do not invent SKUs absent here or from Hub search. LIVE only with provenance source. Never present SIM as LIVE. Physical/map SKUs are Hub invoke, not oracle_call.

GAIA (iot.modelmarket.dev) — device_id-anchored, ~$0.002 unless noted.

| SKU | layer | example devices | honest limit |
|---|---|---|---|
| gaia.weather.read@v1 | weather (Weather) | om-wx-01, nws-01, cwop-01, metno-01 +267 | operator-anchored device_id; LIVE only with provenance source |
| gaia.air.read@v1 | air (Air quality) | om-aq-01, osm-01, sta-01, sc-01 +122 | operator-anchored device_id; LIVE only with provenance source |
| gaia.tide.read@v1 | tide (Tide) | noaa-tide-01, uhslc-01, noaa-tide-sf, noaa-tide-honolulu +14 | operator-anchored device_id; LIVE only with provenance source |
| gaia.grid.read@v1 | grid (Grid carbon) | uk-grid-01, eia-01, rte-grid-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.quake.read@v1 | quake (Earthquakes) | usgs-quake-01, geonet-01, emsc-01, ingv-01 +2 | operator-anchored device_id; LIVE only with provenance source |
| gaia.river.read@v1 | river (Rivers) | usgs-river-01, eccc-hydro-01, smhi-hydro-01, pegel-bonn-01 +163 | operator-anchored device_id; LIVE only with provenance source |
| gaia.marine.read@v1 | marine (Marine) | ndbc-01, om-marine-01, cdip-pointreyes-01, cdip-santamonica-01 +20 | operator-anchored device_id; LIVE only with provenance source |
| gaia.ghg.read@v1 | ghg (Greenhouse gas) | icos-htm-01, icos-zsf-01, icos-lin-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.fire.read@v1 | fire (Wildfire) | firms-fire-01 | cite NASA FIRMS; not a fire perimeter |
| gaia.radiation.read@v1 | radiation (Radiation) | safecast-01, safecast-tokyo, safecast-sf, safecast-denver +10 | operator-anchored device_id; LIVE only with provenance source |
| gaia.jamming.read@v1 | jamming (GNSS jamming) | cybernews-jam-01 | CyberNews GNSS CC BY 4.0; not GPSJam; not RF sensing |
| gaia.gnss.integrity.read@v1 | gnss (GNSS integrity) | gnss-euref-01, gnss-ga-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.adsb.read@v1 | traffic (Edge traffic) | feeder-adsb-01 | own-edge dump1090; opt-in; offline until ingest |
| gaia.ais.read@v1 | traffic (Edge traffic) | feeder-ais-01 | own-edge feeder; not Fintraffic public AIS |
| gaia.iot.read@v1 | iot (Edge IoT) | feeder-iot-01 | own-edge Tasmota/TTN/SenML; opt-in |
| gaia.events.read@v1 | events (Natural events) | eonet-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.spacewx.read@v1 | spacewx (Space weather) | swpc-01, swpc-solarwind-01, swpc-xray-01, donki-01 | NOAA SWPC Kp; Boulder pin, planetary index |
| gaia.lightning.read@v1 | lightning (Lightning) | glm-01 | GOES GLM CONUS; not Blitzortung |
| gaia.alerts.read@v1 | alerts (Weather alerts) | nws-alerts-01, naad-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.argo.read@v1 | argo (Argo floats) | argo-01 | official GDAC floats; cite DOI 10.17882/42182 |
| gaia.geomag.read@v1 | geomag (Geomagnetism) | usgs-geomag-01, usgs-geomag-brw, usgs-geomag-bsl, usgs-geomag-cmo +10 | USGS F only; not INTERMAGNET |
| gaia.flood.read@v1 | flood (Flood) | nws-flood-01, ea-flood-01, vic-meuse-01, vic-rhin-01 +18 | NWS CAP US and/or UK EA OGL England; not GloFAS; not an in-situ gauge |
| gaia.effis.read@v1 | effis (EFFIS fires) | effis-01 | Copernicus EFFIS EU, CC BY 4.0; not FIRMS |
| gaia.volcano.read@v1 | volcano (Volcanoes) | usgs-volcano-01 | USGS elevated volcanoes; not a global ash forecast |
| gaia.ais.public.read@v1 | ais (Public AIS) | fintraffic-ais-01, kystverket-ais-01 | Fintraffic CC BY 4.0 (FI) or Kystverket NLOD (NO); not own-edge gaia.ais.read |
| gaia.tsunami.read@v1 | tsunami (Tsunami alerts) | nws-tsunami-01, ptwc-01 | NWS CAP and/or PTWC Atom warning product, not a tide gauge; empty = offline |
| gaia.cyclone.read@v1 | cyclone (Tropical cyclones) | nhc-cyclone-01, jma-typhoon-01 | NHC/CPHC AL+EP+CP only; not JTWC; not EONET; empty season = offline |
| gaia.adsb.public.read@v1 | adsb (Public ADS-B) | adsb-lol-01 | ADSB.lol ODbL 1.0; isolate derived DB; not own-edge; no OpenSky/ADSBx fallback |
| gaia.smoke.read@v1 | smoke (Smoke) | hms-smoke-01 | full signed polygon rings + holes, not just centroids; qualitative density, not PM2.5 |
| gaia.water_quality.read@v1 | water_quality (Water quality) | usgs-wq-01 (bbox → complete qualified station registry) | fresh (48h default) paginated latest-continuous observations joined to the official USGS monitoring-locations registry; filters and per-series approval/qualifiers; one station = one coordinate |
| gaia.precipitation.read@v1 | precipitation (Precipitation) | imerg-01 + buyer lat/lon | any buyer coordinate; returned IMERG source cell; preliminary |
| gaia.radar.status.read@v1 | radar (NEXRAD status) | nexrad-status-01 (all WSR-88D sites) | all WSR-88D sites returned at their own coordinates; status, not reflectivity |
| gaia.sea_ice.read@v1 | sea_ice (Sea ice) | nsidc-ice-01 + buyer Arctic lat/lon | any Arctic buyer coordinate; returned exact 25-km cell; not for navigation |
| gaia.aviation.read@v1 | aviation (Aviation METAR) | metar-kjfk-01, metar-klga-01, metar-kbos-01, metar-kord-01 +10 | NOAA AWC METAR (U.S. PD); in-situ ASOS pin, not a TAF |
| gaia.road.read@v1 | road (Road weather) | fintraffic-road-01 | Fintraffic Digitraffic road weather CC BY 4.0; Finnish roads only |
| gaia.rail.read@v1 | rail (Rail traffic) | fintraffic-rail-01 | Fintraffic Digitraffic rail locations CC BY 4.0; Finnish rail only |
| gaia.drought.read@v1 | drought (Drought) | usdm-01 | U.S. Drought Monitor weekly state stats; attribute NDMC/USDA/NOAA/NASA |
| gaia.uv.read@v1 | uv (UV forecast) | epa-uv-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.energy.read@v1 | energy (Energy) | em-01, plug-sim-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.reservoir.read@v1 | reservoir (Reservoirs) | usace-keys-01, usace-pine-01, usace-deni-01, usace-huds-01 | operator-anchored device_id; LIVE only with provenance source |
| gaia.atmosphere.read@v1 | atmosphere (Atmosphere) | cams-* + buyer lat/lon | any buyer coordinate; CAMS data CC BY 4.0; commercial hosting required |
| gaia.dart.read@v1 | dart (DART gauges) | noaa-dart-01, dart-* (all 43 active) | all active stations in the NDBC directory; gauge, not a tsunami warning |
| gaia.radnet.read@v1 | radnet (EPA RadNet) | radnet-* (all 140 official monitors) | all 140 official EPA monitor coordinates; cite EPA RadNet |
| gaia.soil_moisture.read@v1 | soil (Soil moisture) | soil-* + buyer lat/lon | any buyer coordinate; returned CLMS source/query cell |
| gaia.solar.read@v1 | solar (Solar irradiation) | solar-* + buyer lat/lon | any buyer coordinate; returned NASA POWER source coordinate |
| gaia.snow.read@v1 | snow (Snowpack) | snow-* + buyer CONUS lat/lon | any buyer coordinate in CONUS; returned exact SNODAS cell |
| gaia.land_temperature.read@v1 | land_temperature (Land temperature) | lst-* + buyer lat/lon | any buyer coordinate; returned Sentinel-3 SLSTR source cell |
| gaia.power.price.read@v1 | power_price (Power price) | smard-price-de-lu, smard-price-at, smard-price-be, smard-price-no2 +11 | wholesale day-ahead price per bidding zone (SMARD, CC BY 4.0; 15 zones); not a retail tariff |
| gaia.imagery.read@v1 | imagery (Satellite imagery) | s2-l2a-01 + buyer lat/lon (5 showcase pins) | any land coordinate; one 10–20 m pixel of the latest cloud-free Sentinel-2 L2A scene; read indices with the scene class; contains modified Copernicus Sentinel data |

GAIA plumbing (not a map pin)

| SKU | artifact |
|---|---|
| gaia.window@v1 | N readings of one device_id in one invoke |
| gaia.verify@v1 | plausibility verdict as a sellable good |
| gaia.fleet.status@v1 | device registry incl. pinned pubkeys — free |
| gaia.place.resolve@v1 | place name or coordinate → one place and the reads that cover it (GeoNames, CC BY 4.0) — free |
| gaia.power.window@v1 | cheapest window of N hours in a bidding zone's published day-ahead prices, with the prices used and their SHA-256 |
| gaia.actuator.list@v1 | the operator's actuators: limits, relay state, pinned keys, kill switch — free |
| gaia.actuate@v1 | switch a plug on for N s or off; $0.05, paid only for the effect its own meter measures (pay-on-verified) |

ATLAS composites (atlas.modelmarket.dev) — billable decision artifacts.

| SKU | USD | artifact |
|---|---|---|
| atlas.watchbox.check@v1 | 0.02 | Evaluate an ATLAS watchbox (bbox + layers) against the live fleet snapshot |
| atlas.fire.weather@v1 | 0.08 | FIRMS and/or EFFIS + nearby weather; two lists; not a forecast |
| atlas.smoke.operations@v1 | 0.12 | point-in-polygon against the signed HMS ring + colocated PM2.5/AQI; refuses on a truncated inventory; not measured PM2.5 and not an evacuation order |
| atlas.situation.brief@v1 | 0.06 | defaults include flood/EFFIS/lightning/volcano/alerts/events/AIS/tsunami/cyclone/ADS-B; not spacewx/geomag/argo |
| atlas.nearest.read@v1 | 0.03 | Nearest LIVE ATLAS pin(s) to a lat/lon on allowlisted layers |
| atlas.point.read@v1 | 0.01 | Read one exact clickable ATLAS map object by stable point_id |
| atlas.geomag.window@v1 | 0.05 | SWPC planetary Kp → NOAA state/G-scale + nearest USGS observatory F; total field only, NOT a declination correction and not safety-of-life |
| atlas.pv.irradiance.record@v1 | 0.15 | NASA POWER daily all-sky vs clear-sky + CAMS aerosol/dust at the plant coordinate; a retrospective record of fact, NOT a yield forecast or a soiling-loss model |
| atlas.route.integrity@v1 | 0.25 | per-segment corridor brief: GNSS field + reported interference zones + AIS/ADS-B presence + hazard pins; reported interference is NOT proof of jamming, not safety-of-life |
| atlas.observability.attest@v1 | 0.10 | data-availability attestation: nearest NEXRAD + ARCHIVED status samples in a window; an archive gap is absence of evidence, NOT evidence the radar was down; U.S. only |
| atlas.gnss.degradation.read@v1 | 0.05 | GNSS integrity field for a point, bbox, or route |
| atlas.mesh.sample@v1 | 0.03 | Halton sample of a licensed in-situ mesh; not ECVRF; not Open-Meteo |
| atlas.field.consensus@v1 | 0.06 | robust consensus of LIVE in-situ readings; one broken station cannot move the number; not a forecast |
| atlas.field.posterior@v1 | 0.08 | spatial GP posterior of the current LIVE snapshot; interpolates now, not a forecast |
| atlas.field.shape@v1 | 0.06 | H0 persistence of LIVE in-situ pins; not Betti-1; not an AQI |

Map layers (49): weather=Weather; air=Air quality; tide=Tide; river=Rivers; marine=Marine; ghg=Greenhouse gas; grid=Grid carbon; quake=Earthquakes; energy=Energy; fire=Wildfire; radiation=Radiation; jamming=GNSS jamming; gnss=GNSS integrity; traffic=Edge traffic; events=Natural events; spacewx=Space weather; lightning=Lightning; alerts=Weather alerts; argo=Argo floats; geomag=Geomagnetism; iot=Edge IoT; flood=Flood; effis=EFFIS fires; volcano=Volcanoes; ais=Public AIS; tsunami=Tsunami alerts; cyclone=Tropical cyclones; adsb=Public ADS-B; smoke=Smoke; water_quality=Water quality; dart=DART gauges; precipitation=Precipitation; radar=NEXRAD status; atmosphere=Atmosphere; radnet=EPA RadNet; soil=Soil moisture; solar=Solar irradiation; snow=Snowpack; sea_ice=Sea ice; land_temperature=Land temperature; aviation=Aviation METAR; road=Road weather; rail=Rail traffic; drought=Drought; reservoir=Reservoirs; uv=UV forecast; power_price=Power price; imagery=Satellite imagery; actuator=Actuators

<!-- END GENERATED physical-capabilities -->

### Human / community / broadcast
- **ARGUS-3** (magic-ai-factory.com/argus/) — sole intended human UI; WARDEN MCP firewall
  (LUMEN); crypto off by default; install: curl …/install | bash.
- **DIOSCURI** — CASTOR (Telegram) + POLLUX (Discord); MNEMOSYNE KB; AEGIS firewall.
- **THEOROS** — Agent Sovereignty Canon; weekly #the-canon via DIOSCURI.
- **HELIOS** — yaml → voiced video → YouTube (@My-AI-Factory), private until approve.

### Capital / observability / learning
- **ACEX** + **Pulse Terminal** (magic-ai-factory.com/pulse/) — CapShares, lending, AMM.
- **Agent Lottery** (lottery.modelmarket.dev) — unbiasable oracle draws · machine UBI.
- **Alien Monitor** (monitor.modelmarket.dev/) — live 3D ecosystem graph + AI.
- **SKOPOS** (skopos.modelmarket.dev) — fleet nginx/Apache analytics, Security Center.
- **School / Courses** — edu.modelmarket.dev · aimarket-courses academies.
- **Ecosystem map / docs** — modeldev.modelmarket.dev · docs/ecosystem/knowledge-base.md
  · whitepaper docs/ecosystem/whitepaper/en.md · verify.modelmarket.dev (provenance).

### Trust & settlement (one line)
Byzantine hubs/agents assumed; bonded reputation; non-custodial channels; oracle
outputs verifiable without trusting the operator; Base/EVM USDC escrow + Solana paths.

<!-- BEGIN GENERATED ecosystem-components -->
### Component registry

Generated from scripts/satellite-map.yaml — do not hand-edit. GitHub org: alexar76.
Run: python3 scripts/sync_knowledge_base.py --write (54 components).

- acex: ACEX — Agent Capital Exchange: listings, CapShares, lending, and AMM for AI agents. · https://alexar76.github.io/aicom/
- ai-service-mesh: AI Service Mesh — autonomous agent discovery, verification, escrow, and payments. · https://service-mesh.modelmarket.dev/
- aicom (profile README): AI-Factory — autonomous pipeline that designs, builds, tests, and publishes products. · https://magic-ai-factory.com/
- aicom-landing: AI landing generator — one prompt → self-contained HTML in ~30-60s (MIT, 20 style presets). · https://magic-ai-factory.com/landing-page-generation/
- aicom-products: Selective catalog of full AI-Factory products (prod-*) — shell from monorepo, trees published on demand. · https://github.com/alexar76/aicom-products
- aicom-wiki (repo aicom.wiki): Documentation wiki for AI-Factory and the AIMarket ecosystem.
- aimarket-agent: Python client for discovering and invoking AIMarket hub capabilities. · https://alexar76.github.io/aicom/
- aimarket-bridges: AIMarket capabilities as native tools for LangChain/LangGraph, CrewAI, AutoGen and Microsoft Agent Framework — signed receipts, per-task budget caps, free trial. The adapter layer for agents built on someone else's framework. · https://modeldev.modelmarket.dev/bridges/
- aimarket-courses: 13 hands-on AIMarket academy courses — orchestration, oracles, MCP security, agent economy, GAIA/ATLAS, federation, PQC (en/ru/es/fr/zh). · https://alexar76.github.io/aimarket-courses/
- aimarket-desktop: 10 desktop & IDE apps for AIMarket — Flutter, Tauri, and VS Code in one Melos monorepo. · https://alexar76.github.io/aicom/
- aimarket-hub: AIMarket Hub — federated capability catalog, channels, invoke API, and plugins. · https://modelmarket.dev/
- aimarket-mcp: Ecosystem MCP gateway — web fetch/search + Metis verify behind one SSRF-hardened MCP endpoint (Streamable-HTTP). Consumed by Metis and ARGUS via the aimarket-web preset. · https://glama.ai/mcp/servers/alexar76/aimarket-mcp
- aimarket-oracle-gateway: MCP server: verifiable oracle services (Platon VRF, Chronos VDF, LUMEN reputation) for AI agents — pay-per-call over the AIMarket protocol, every result independently verifiable. · https://glama.ai/mcp/servers/alexar76/aimarket-oracle-gateway
- aimarket-playground: Zero-setup guided AIMarket golden path: GAIA invoke, Metis verification, signed Hub receipt, and Alien Monitor handoff. · https://play.modelmarket.dev/
- aimarket-plugins: 15 AIMarket hub plugins — TEE escrow, channels, reputation, safety, and more. · https://alexar76.github.io/aicom/
- aimarket-protocol: AIMarket Protocol v2 — open specs, JSON schemas, and test vectors. · https://alexar76.github.io/aicom/
- aimarket-school: AIMarket School — 13 free clip lessons (Try-it + Colab) that on-ramp into the academies. Live portal: edu.modelmarket.dev · https://edu.modelmarket.dev/
- aimarket-sdks: Official AIMarket client SDKs — Dart, TypeScript, and Rust. · https://alexar76.github.io/aicom/
- aimarket-widget: Embeddable AIMarket storefront widget — drop-in JS/CSS for any website. · https://modelmarket.dev/widget/demo
- alien-monitor: Alien Monitor — real-time 3D ecosystem pulse visualizer with AI assistant. · https://monitor.modelmarket.dev/
- argus: ARGUS-3 — wallet-native, security-hardened personal agent; demand-side reference client and the reference host for the WARDEN MCP firewall (@aimarket/warden, a separate package) plus native AIMarket consumer/provider. Owner-locked Telegram, multi-provider, autonomous offline. · https://magic-ai-factory.com/argus/
- argus-wiki (repo argus.wiki): Documentation wiki for ARGUS-3 — install, WARDEN, channels, economy, Arena.
- atlas: Planetary sensor map over GAIA (weather, air, fire, flood, lightning, alerts, EFFIS, volcano, GNSS jamming, and other LIVE/SIM layers) plus Hub-sold composites atlas.situation.brief@v1 (defaults to map layers), atlas.fire.weather@v1 (FIRMS and/or EFFIS), atlas.nearest.read@v1, atlas.watchbox.check@v1. ATLAS maps and sells geo artifacts; GAIA attests raw reads. · https://alexar76.github.io/atlas/
- attested-memory: Attested Memory — verifiable memory for AI agents: Memory Market (write, search, share), Truth Layer (evidence and contradictions) and Provenance Ledger (lineage, hybrid-signed receipts) around one Memory Unit contract, with an MCP endpoint. Self-hosted, Docker. · https://attestedmemory.net/
- basanos: Lydian touchstone for ecosystem Solidity. Emits an Ed25519-signed assurance pack (PASS/REVIEW/FAIL) pinned to a commit/tree digest. Learns detector order from allowlisted OSV/GHSA only — intel cannot add detectors or emit scoreBps. Not HEPHAESTUS (forge.modelmarket.dev is that landing), not AgentAuditPool, not MOMUS, not THEMIS. · https://basanos.modelmarket.dev · port 9470
- cite-desks: Cite desks — independent evidence desks on AIMarket rails. One parent repo: shared kernel plus Emberline (fire), Tideline (flood), Solrecord (PV), Seamark (Nordic AIS), Plinth (site) and Smokeproof (HMS smoke), each a nested project with its own README. Family landing: desk.modelmarket.dev. Not an AIMarket brand surface. · https://desk.modelmarket.dev/
- create-aimarket-agent: Standalone CLI that scaffolds tested AIMarket Protocol v2 capability providers with manifests and Docker packaging. · https://alexar76.github.io/create-aimarket-agent/
- dioscuri: DIOSCURI — one mind, two heavens. Twin community agents: CASTOR rides Telegram, POLLUX holds Discord. Shared GitHub-synced knowledge base (MNEMOSYNE) behind a prompt-injection firewall + moderation shield (AEGIS). · https://alexar76.github.io/dioscuri/
- dolos: DOLOS — dynamic EVM red team for the UNI bubble: fork-isolated exploit txs, Ed25519 findings, sandbox fix-loop only. · https://dolos.modelmarket.dev/
- domain-kit (repo domain-operator-kit): Independent domain operators: signed domains.*@v1 quotes, fixed markup, registration, renewal and DNS. Openprovider, Porkbun Sandbox or HTTP suppliers; x402 USDC on Base and a buyer-side Vercel connector. Pre-live: both sandbox pilots passed; production payments and Vercel remain unverified.
- emporion: Public-record facts and tools for agents that trade: EU VAT validity (VIES) with the consultation number, legal entities (GLEIF LEI), national company registers (Norway, France, Czech Republic, Finland), EU EORI numbers, domain registrations (RDAP), ECB reference rates, sanctions-list lookups (OFAC SDN, EU, and the UK list with the UN designations), business days in ~250 countries and on markets, Bitcoin-anchored timestamps (OpenTimestamps), web pages captured as evidence, and timers that call an agent back with a signed event — at a time or as a dead man's switch. Each answer is signed with its source, fetch time and SHA-256. The hub sells it at https://modelmarket.dev/providers/emporion. · https://emporion.modelmarket.dev · port 9351
- escrow-signer: HORKOS holds the only key authorized in AIMarketEscrow.authorizedHubs, so the Hub does not — one allowed selector, one escrow, one chain, and the buyer's own EIP-712 signature as the authority for every amount. · https://alexar76.github.io/escrow-signer/
- esim-kit (repo esim-operator-kit): Onboard any eSIM operator, including ones already selling. They offer travel eSIMs to people and AI agents on AIMarket rails and get paid however they already take payment. Storefront in 5 languages. Demo: esim.modelmarket.dev. · https://esim.modelmarket.dev/
- gaia: Physical oracle: attested gaia.*.read@v1 SKUs (weather, fire/FIRMS, lightning/GLM, flood/NWS CAP, EFFIS, volcano, EONET, SWPC, GNSS jamming, day-ahead power prices from SMARD, Sentinel-2 imagery at any land point, …) plus window/verify. gaia.place.resolve@v1 (free) turns any place name into coordinates and says which reads cover it; gaia.power.window@v1 finds the cheapest hours to run a load; gaia.actuate@v1 switches an operator's metering plug and is paid only for the effect its meter measures. LIVE only with provenance source; Hub search then invoke — not oracle_call. · https://iot.modelmarket.dev · port 9320
- helios: HELIOS — self-hosted broadcast pipeline for the AIMarket ecosystem. Template in, voiced video out, queued to YouTube — private by default until you approve. · https://alexar76.github.io/helios/
- hephaestus: The forge — compose capability chains from the live signed Hub catalogue, estimate cost and latency BEFORE spending, run pipelines through the factory executor, and keep a signed bill of materials with hop-level blame. Studio UI is hub-served; core library is framework-free. · https://modelmarket.dev/studio
- hestia: HESTIA — the hosted runtime: isolated, for AIMarket capability providers on the operator’s machines. Not a Hub catalogue, not a job board, not Factory. Agents appear only after a signed deploy onto this host. · https://hestia.modelmarket.dev · port 9480
- histor: HISTOR — public transparency log of MCP tool definitions: reads what remote MCP endpoints in the official registry advertise (never calls a tool), signs it as MTL/1 labels, appends them to an RFC 9162 Merkle log, and answers /check: is what a client received what was observed? Never calls a server safe. · https://alexar76.github.io/histor/
- linkedin-profile-coach (repo linked-in-profile-coach): LinkedIn Profile Coach — Flutter desktop/mobile app for 24 LinkedIn sections, AI draft, scoring, and .docx resume support. · https://alexar76.github.io/linked-in-profile-coach/
- logos: Read-only federation intelligence: periodic source snapshots across Hub, MOMUS, Treasury, SKOPOS and Metis, rolling z-score anomaly detection over them, and cross-system correlation. It observes and explains; it never acts on what it finds. · https://logos.modelmarket.dev · port 9460
- lottery: AI-Agent Oracle Lottery — an on-chain lottery that is an economic actor of the AI ecosystem: agents buy tickets, an unbiasable Platon+Chronos oracle beacon draws a LUMEN-reputation-weighted winner. · https://lottery.modelmarket.dev/
- metis: Cognitive verification tier: Understanding Council, fail-closed confidence gate, layered MoA, grounded verifier. Also available to MOMUS as an independent external verifier of a finding. · https://metis.modelmarket.dev
- momus: Adversarial-audit red team. Runs safe, read-only conformance probes against the ecosystem's own components and emits Ed25519-signed findings. It FINDS and SIGNS but can never pay itself — a separate Treasury key releases bounties, and only on independent verification. Honest outcomes: FINDING / NO_FINDING / INCONCLUSIVE (an unreachable target is neither a finding nor a pass). · https://momus.modelmarket.dev · port 9410
- oracles: Verifiable AI-economy oracles — 17 signed capabilities (Platon randomness, Chronos VDF, Lumen reputation, Turing, Fourier and more) on shared oracle-core. · https://oracles.modelmarket.dev/
- platon: Platon UMBRAL — educational cave app for oracle #1: 32D dynamical shadow oracle with live AIMarket backend and holographic cockpit. · https://oracles.modelmarket.dev/platon/umbral/
- profile (repo alexar76) (profile README): GitHub profile README — ecosystem map for alexar76. · https://github.com/alexar76
- pulse-terminal: Pulse Terminal — ACEX capital markets dashboard with live agent pricing. · https://magic-ai-factory.com/pulse/
- signal-hunt: Federation-native investigation game and educational laboratory over real Hub telemetry: observe measured symptoms, commit a diagnosis, prove it with a reproducible Brier-score verdict. Live data only — no seeded anomalies. · https://hunt.modelmarket.dev
- skopos: Fleet observability dashboard, and the CONDUCTOR of the remediation loop: it receives MOMUS's signed ticket over A2A, drives the AI-Factory to author a patch, asks MOMUS to re-test as the deploy gate, then signs a DeployOrder and publishes it for the addressed node agent to claim. It orders deploys; it never executes one. · https://skopos.modelmarket.dev
- themis: THEMIS — publish-time admission gate for AIMarket: signed approve/review/reject for AI-agent supply-chain procurement (not Metis, not WARDEN). · https://alexar76.github.io/themis/
- theoros: THEOROS — Agent Sovereignty Canon. High-tech theorist persona: seven precepts for verified agent economic actors, cosmic landing, weekly column via DIOSCURI #the-canon. · https://alexar76.github.io/theoros/
- treasury: The only key that can pay a red-team bounty. A separate role with its own key: MOMUS finds and signs, the Treasury verifies the signatures, recomputes the dedup identity, and releases the finder/fixer/conductor split (50/35/15). Default settlement is the simulated UNI vault; real on-chain payout needs a second, explicit opt-in beyond enabling crypto. · https://momus.modelmarket.dev/treasury · port 9411
- use-cases-portal: AIMarket use-cases portal — public wow, onboarding (See·Buy·Publish·Build·Invest), live rails, and 7 direction boards with 12 idea pages (3D previews). Static site, five languages, honest LIVE vs SIM. Live host use.modelmarket.dev; Pages landing (docs/landing/) at alexar76.github.io/use-cases-portal. · https://use.modelmarket.dev/
- warden: WARDEN — MCP security firewall: vets an MCP server's tool definitions against static-scan rules, a signed threat feed, origin and tool-def pinning before any tool reaches the model. Zero-dependency TypeScript library. · https://warden.modelmarket.dev
<!-- END GENERATED ecosystem-components -->

When the user asks what a sibling product is, answer from this brief (roles + public
URLs). Never invent live Hub/Factory metrics; for ATLAS readings use the snapshot only.
""".strip()


def ecosystem_brief() -> str:
    return ECOSYSTEM_BRIEF
