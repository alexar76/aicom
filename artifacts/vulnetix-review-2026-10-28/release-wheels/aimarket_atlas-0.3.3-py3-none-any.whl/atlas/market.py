"""AIMarket peer surface for ATLAS composite products.

ATLAS remains the map; these endpoints publish the three ship-first SKUs so Hub
federation can crawl them once seeded. Invoke is free on the public edge today
(same honesty as GAIA demo reads) — Hub escrow attaches when ATLAS is registered.
"""

from __future__ import annotations

from typing import Any

from . import __version__
from .config import get_settings
from .geo import utc_now
from .products import PRODUCT_CAPS
from .signing import get_signer


def _payment_terms() -> dict[str, Any]:
    """Whether priced capabilities are actually metered, and the free allowance."""
    from atlas import payment_gate

    window = payment_gate.quota_window()
    terms: dict[str, Any] = {
        "enforced": payment_gate.enforced(),
        "free_allowance": {
            "max_invokes_per_caller": payment_gate.max_per_caller(),
            "quota_window": window,
            "renews": window != "lifetime",
            "caller_header": payment_gate.VISITOR_HEADER,
        },
    }
    # The paid rail belongs in the manifest, not just in the 402 that refuses you. A buyer
    # deciding whether to build a product on ATLAS has to know BEFORE it starts that there
    # is a way past five calls an hour; the previous manifest advertised prices and a trial
    # and left the reader to discover that nothing here could take money.
    from atlas import credits

    terms["credits"] = {
        "enabled": credits.enabled(),
        "unit": "USD",
        "key_header": credits.KEY_HEADER,
        "account_url": "/ai-market/v2/accounts/me",
        "issued_by": "operator",
        "note": (
            "A credited account is charged the published price per call and is not subject "
            "to the free allowance. Refusals are not billed."
            if credits.enabled()
            else "Prepaid accounts are not switched on for this node."
        ),
    }
    if not payment_gate.enforced():
        terms["note"] = (
            "Prices are advertised but not charged yet: every invoke is served free. "
            "Build against the free allowance and expect 402 once metering is on."
        )
    elif credits.enabled():
        terms["note"] = (
            "Priced capabilities are metered. Anonymous callers get the free allowance; "
            "pay per call by sending a credit account key as "
            f"{credits.KEY_HEADER}. When neither is available the answer is 402 with the "
            "price and how to continue."
        )
    else:
        terms["note"] = (
            "Priced capabilities are metered. Send the caller header to hold your own "
            "allowance; when it is spent the answer is 402 with the price and how to pay."
        )
    return terms


def well_known() -> dict[str, Any]:
    settings = get_settings()
    base = (settings.public_url or "https://atlas.modelmarket.dev").rstrip("/")
    signer = get_signer()
    return {
        "name": "ATLAS — planetary sensor map & composite briefs",
        "protocol_versions": ["v2"],
        "protocol_version": "v2",
        "hub_version": __version__,
        "hub_name": "ATLAS",
        "hub_url": base,
        "manifest_url": f"{base}/ai-market/v2/manifest",
        "mcp_endpoint": f"{base}/ai-market/v2/invoke",
        "capabilities_count": len(PRODUCT_CAPS),
        "signer_public_key": signer.public_key_b64,
        # The price list was published without saying whether anyone is charged.
        # Say it: whether the meter is on, what the free allowance is, and whether
        # it comes back. A discovering agent can then plan instead of guessing.
        "payment": _payment_terms(),
        "description": (
            "Planetary MapLibre sensor map over GAIA relays, plus composite Hub SKUs: "
            "watchbox check, wildfire+weather desk note, cross-layer situation briefs, "
            "nearest LIVE pin by lat/lon, and exact reads for every clickable point_id. "
            "GNSS integrity fields answer point, bbox and route queries with explicit "
            "inventory/derived/reported-interference claim classes. "
            "LIVE only with provenance; refuse when coverage is empty."
        ),
        "categories": [
            "iot",
            "sensors",
            "physical-data",
            "geospatial",
            "risk-brief",
            "wildfire",
            "watchbox",
            "gnss-integrity",
        ],
        "ecosystem": {
            "product": "atlas.map",
            "related": ["gaia.gateway", "aimarket-hub", "alien-monitor"],
        },
    }


def manifest() -> dict[str, Any]:
    settings = get_settings()
    base = (settings.public_url or "https://atlas.modelmarket.dev").rstrip("/")
    signer = get_signer()
    tools = []
    for cap in PRODUCT_CAPS:
        tools.append(
            {
                **cap,
                "source_hub": base,
                "source_hub_name": "ATLAS",
                "invoke_url": f"{base}/ai-market/v2/invoke",
                "trust_score": 0.5,
            }
        )
    body: dict[str, Any] = {
        "protocol_version": "v2",
        "release_version": __version__,
        "generated_at": utc_now(),
        "base_url": base,
        "products_count": 1,
        "capabilities_count": len(tools),
        "total_capabilities": len(tools),
        "local_capabilities": len(tools),
        "federated_capabilities": 0,
        "hubs_indexed": 1,
        "tools": tools,
        "by_hub": {base: {"name": "ATLAS", "capabilities": len(tools)}},
    }
    body["signature"] = signer.sign_manifest(body)
    return body


__all__ = ["well_known", "manifest"]
