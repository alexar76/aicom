"""Anonymized invocation dataset exporter.

Weekly export of ai-market-corpus-week-N.jsonl:
    Anonymized task→capability→outcome→price tuples.

Privacy:
    - Product/capability IDs are SALTED SHA-256 (16 hex chars).
      Salt is loaded from AIMARKET_DATASET_SALT or generated per-deploy
      and persisted to data/dataset_salt — rainbow tables built against
      one deploy don't transfer to another.
    - No consumer identifying info
    - No PII in task text (scrubbed)
    - No wallet addresses
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import secrets
import time
from pathlib import Path
from typing import Any

from aimarket_hub.database import HubDatabase
from aimarket_hub._signing_key_storage import load_or_create_private_bytes

logger = logging.getLogger(__name__)

_SALT_FILE = Path(os.environ.get("AIMARKET_DATASET_SALT_PATH", "data/dataset_salt"))
COMPROMISED_SALT_SHA256 = frozenset({
    "8fe500034ccbf7c9cbc3ec2dc06fdd71f3ca7be59acfc3aad843c7b7d5c4ed1e",
})


def _validated_salt(salt: bytes) -> bytes:
    if not salt:
        raise RuntimeError("Dataset salt is empty; explicit privacy recovery is required")
    if hashlib.sha256(salt).hexdigest() in COMPROMISED_SALT_SHA256:
        raise RuntimeError(
            "Dataset salt was publicly exposed; explicit privacy recovery is required. No salt was rotated."
        )
    return salt


def _load_or_create_salt() -> bytes:
    """Load persistent dataset salt or generate a new one on first use.

    Salt must be stable across exports (so the same product gets the
    same hash week-over-week) but unguessable to outsiders.
    """
    env_salt = os.environ.get("AIMARKET_DATASET_SALT", "").strip()
    if env_salt:
        return _validated_salt(env_salt.encode())
    existed = _SALT_FILE.exists()
    salt = load_or_create_private_bytes(_SALT_FILE, lambda: secrets.token_bytes(32), _validated_salt)
    if not existed:
        logger.warning(
            "Generated new dataset salt at %s — back this up if you want "
            "anonymized IDs to stay stable across deploys.",
            _SALT_FILE,
        )
    return salt


_SALT = _load_or_create_salt()


def _anonymize_id(s: str) -> str:
    """Hash an ID with a per-deploy salt to a consistent but unlinkable string.

    16-char prefix = 64 bits of entropy after salting — rainbow tables
    against public namespaces (capability_id) become infeasible.
    """
    return hashlib.sha256(_SALT + s.encode()).hexdigest()[:16]


def _scrub_pii(text: str) -> str:
    """Remove PII patterns from text."""
    text = re.sub(r'\b[\w.-]+@[\w.-]+\.\w{2,}\b', '[email]', text)
    text = re.sub(r'\b\d{3}[-.]?\d{2}[-.]?\d{4}\b', '[ssn]', text)
    text = re.sub(r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b', '[card]', text)
    text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[ip]', text)
    return text


def export_dataset(
    db: HubDatabase,
    output_dir: str | Path = "data/datasets",
    *,
    week_number: int | None = None,
    limit: int = 10_000,
) -> Path:
    """Export anonymized invocation stats as JSONL.

    Args:
        db: Hub database to read from.
        output_dir: Where to write the file.
        week_number: ISO week number. Defaults to current week.
        limit: Max records to export.

    Returns:
        Path to the exported file.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if week_number is None:
        week_number = int(time.strftime("%W"))

    filename = f"ai-market-corpus-week-{week_number}.jsonl"
    path = output_dir / filename

    stats = db.recent_stats(limit=limit)
    exported = 0

    with open(path, "w", encoding="utf-8") as f:
        for row in stats:
            try:
                # Anonymize
                record: dict[str, Any] = {
                    "week": week_number,
                    "capability_id": _anonymize_id(row.get("capability_id", "")),
                    "product_id": _anonymize_id(row.get("product_id", "")),
                    "source_hub": _anonymize_id(row.get("source_hub", "local")),
                    "price_usd": row.get("price_usd", 0),
                    "latency_ms": row.get("latency_ms", 0),
                    "success": bool(row.get("success")),
                    "timestamp": row.get("timestamp", ""),
                    "protocol_version": "v2",
                }

                # Scrub any residual text
                if isinstance(record.get("capability_id"), str):
                    record["capability_id"] = _scrub_pii(record["capability_id"])

                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                exported += 1
            except Exception:
                continue

    logger.info("Dataset exported: %s (%d records)", path, exported)

    # Write README alongside
    readme_path = output_dir / f"README-week-{week_number}.md"
    readme_path.write_text(f"""# AI Market Corpus — Week {week_number}

**Format:** JSONL (one JSON object per line)
**Records:** {exported}
**Anonymization:** All IDs are SHA-256 hashed (12-char prefix). PII scrubbed.
**License:** CC-BY 4.0
**Generated by:** AIMarket Hub v2.0.0

## Schema

```json
{{
  "week": {week_number},
  "capability_id": "sha256hash12",
  "product_id": "sha256hash12",
  "source_hub": "sha256hash12",
  "price_usd": 0.40,
  "latency_ms": 8100,
  "success": true,
  "timestamp": "2026-05-21T12:00:00Z",
  "protocol_version": "v2"
}}
```

## Citation

```bibtex
@dataset{{aimarket-corpus-week-{week_number},
  title={{AI Market Corpus — Week {week_number}}},
  author={{AIMarket Hub}},
  year={time.strftime('%Y')},
  note={{Anonymized AI capability invocation records}},
  url={{https://modelmarket.dev/datasets}}
}}
```
""")

    return path


def schedule_weekly_export(db: HubDatabase, output_dir: str = "data/datasets") -> None:
    """Export once if this week's file doesn't exist yet (idempotent).

    Call this from a cron job or scheduler.
    """
    week = int(time.strftime("%W"))
    path = Path(output_dir) / f"ai-market-corpus-week-{week}.jsonl"
    if path.exists():
        logger.info("Week %d dataset already exported, skipping.", week)
        return
    export_dataset(db, output_dir, week_number=week)


def export_all_time(
    db: HubDatabase,
    output_dir: str | Path = "data/datasets",
) -> Path:
    """Export the full historical dataset (all-time)."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "ai-market-corpus-all-time.jsonl"

    stats = db.recent_stats(limit=100_000)
    exported = 0

    with open(path, "w", encoding="utf-8") as f:
        for row in stats:
            try:
                record = {
                    "capability_id": _anonymize_id(row.get("capability_id", "")),
                    "product_id": _anonymize_id(row.get("product_id", "")),
                    "source_hub": _anonymize_id(row.get("source_hub", "local")),
                    "price_usd": row.get("price_usd", 0),
                    "latency_ms": row.get("latency_ms", 0),
                    "success": bool(row.get("success")),
                    "timestamp": row.get("timestamp", ""),
                    "protocol_version": "v2",
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                exported += 1
            except Exception:
                continue

    logger.info("All-time dataset exported: %s (%d records)", path, exported)
    return path
