"""The HTTP transport on MCP 2026-07-28, beside the handshake it has always spoken.

A 2026-07-28 client sends no `initialize`: every request names its protocol version and
capabilities in `_meta` and mirrors version, method and tool name into HTTP headers. The full
envelope rules are pinned in aimarket-hub's tests of the same module; here: that this transport
routes the two eras apart and answers each as its revision says.
"""
from __future__ import annotations

import httpx
import pytest

from aimarket_mcp import modern, server
from tests.test_gateway import _parse_sse, _rpc

pytestmark = pytest.mark.usefixtures("local_http_opt_in")

V = "2026-07-28"
META = {
    "io.modelcontextprotocol/protocolVersion": V,
    "io.modelcontextprotocol/clientInfo": {"name": "pytest-modern", "version": "1"},
    "io.modelcontextprotocol/clientCapabilities": {},
}


def _client():
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url="http://127.0.0.1:9090")


async def _modern(client, method, params=None, *, headers=None, meta=META, req_id=1):
    body = dict(params or {})
    if meta is not None:
        body["_meta"] = meta
    sent = {"MCP-Protocol-Version": V, "Mcp-Method": method}
    if method == "tools/call" and isinstance(body.get("name"), str):
        sent["Mcp-Name"] = body["name"]
    for key, value in (headers or {}).items():
        if value is None:
            sent.pop(key, None)
        else:
            sent[key] = value
    message = {"jsonrpc": "2.0", "method": method, "params": body}
    if req_id is not None:
        message["id"] = req_id
    return await client.post("/mcp", json=message, headers=sent)


async def test_discover_answers_without_a_handshake():
    async with _client() as c:
        r = await _modern(c, "server/discover")
        assert r.status_code == 200 and r.headers["content-type"].startswith("application/json")
        assert "mcp-session-id" not in r.headers
        result = r.json()["result"]
        assert result["supportedVersions"] == [V, "2025-03-26"]
        assert result["capabilities"] == {"tools": {}}
        assert result["resultType"] == "complete"
        assert result["_meta"]["io.modelcontextprotocol/serverInfo"] == {
            "name": "aimarket-mcp", "version": server.SERVER_VERSION}
        assert result["ttlMs"] > 0 and result["cacheScope"] == "public"


async def test_tools_list_is_the_handshake_list_with_the_cache_fields():
    async with _client() as c:
        legacy = _parse_sse((await _rpc(c, "tools/list")).text)["result"]
        result = (await _modern(c, "tools/list")).json()["result"]
        assert result["tools"] == legacy["tools"]
        assert result["resultType"] == "complete" and result["ttlMs"] >= 0
        assert "resultType" not in legacy and "ttlMs" not in legacy


async def test_tools_call_runs_and_says_complete(monkeypatch):
    async def fake(arguments):
        return f"echo {arguments['q']}"

    monkeypatch.setitem(server.TOOLS_BY_NAME, "web_search", {**server.TOOLS_BY_NAME["web_search"], "handler": fake})
    async with _client() as c:
        r = await _modern(c, "tools/call", {"name": "web_search", "arguments": {"q": "x"}})
        assert r.status_code == 200
        result = r.json()["result"]
        assert result["content"] == [{"type": "text", "text": "echo x"}] and result["isError"] is False
        assert result["resultType"] == "complete" and "ttlMs" not in result
        unknown = await _modern(c, "tools/call", {"name": "no_such_tool", "arguments": {}})
        assert unknown.status_code == 200 and unknown.json()["error"]["code"] == -32602


async def test_the_refusals_carry_the_status_and_code_the_revision_assigns():
    async with _client() as c:
        meta = {**META, "io.modelcontextprotocol/protocolVersion": "2027-01-01"}
        r = await _modern(c, "tools/list", meta=meta, headers={"MCP-Protocol-Version": "2027-01-01"})
        assert r.status_code == 400 and r.json()["error"]["code"] == modern.UNSUPPORTED_PROTOCOL_VERSION
        assert r.json()["error"]["data"] == {"supported": [V, "2025-03-26"], "requested": "2027-01-01"}
        for headers in ({"MCP-Protocol-Version": None}, {"Mcp-Method": "tools/call"}):
            r = await _modern(c, "tools/list", headers=headers)
            assert r.status_code == 400 and r.json()["error"]["code"] == modern.HEADER_MISMATCH
        r = await _modern(c, "tools/call", {"name": "web_search", "arguments": {}}, headers={"Mcp-Name": "web_fetch"})
        assert r.status_code == 400 and r.json()["error"]["code"] == modern.HEADER_MISMATCH
        for method in ("initialize", "ping", "no/such"):
            r = await _modern(c, method)
            assert r.status_code == 404 and r.json()["error"]["code"] == -32601
        r = await _modern(c, "notifications/cancelled", {"requestId": 1}, req_id=None)
        assert r.status_code == 202 and r.content == b""


async def test_handshake_clients_are_not_disturbed():
    async with _client() as c:
        r = await _rpc(c, "initialize", {"protocolVersion": "2025-03-26"})
        assert r.headers["content-type"].startswith("text/event-stream") and r.headers.get("mcp-session-id")
        result = _parse_sse(r.text)["result"]
        assert result["protocolVersion"] == "2025-03-26" and "resultType" not in result
        r = await _rpc(c, "tools/list", headers={"MCP-Protocol-Version": "2025-03-26"})
        assert "resultType" not in _parse_sse(r.text)["result"]
        assert _parse_sse((await _rpc(c, "ping")).text)["result"] == {}
        assert (await c.get("/health")).json()["protocols"] == [V, "2025-03-26"]


def test_the_envelope_module_is_the_hubs():
    """One set of rules in two packages: the copy must not drift from the hub's file."""
    from pathlib import Path

    here = Path(modern.__file__).read_text()
    twin = Path(__file__).resolve().parents[2] / "aimarket-hub" / "aimarket_hub" / "mcp_modern.py"
    if not twin.exists():                    # an installed package, or the public mirror: nothing to compare
        pytest.skip("aimarket-hub is not checked out beside this package")
    note = ("\nThe same file ships in aimarket-hub as ``aimarket_hub/mcp_modern.py``; this package does not\n"
            "depend on the hub, so it carries its own copy. Keep the two in step.\n")
    assert here.count(note) == 1
    assert here.replace(note, "") == twin.read_text()
