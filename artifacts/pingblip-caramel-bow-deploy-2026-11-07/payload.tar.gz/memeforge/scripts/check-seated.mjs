// Finds the defect the owner kept reporting by eye and every other guard passed:
// a feature that does not touch the figurine it belongs to.
//
//   npm run assets:seated
//
// «блин перед туловищем», «бородавки в воздухе летают», «глаза рот румянец - все в
// воздухе висит», «конусы с шариками перед мордой» — fourteen reports in one sitting,
// all one mistake. A chest panel, a wart, a mouth or a drip gets a hand-picked y while
// the body under it is round: right on the centre line, and hanging in mid-air by the
// time the surface has curved away. Head-on it is invisible, which is why it survived
// the dex renders; it appears the moment the figurine turns in the game.
//
// WHY check-assembly MISSES IT. That guard asks whether parts CLUSTER, over a 25mm
// voxel grid — so a plate that grazes the silhouette by a corner counts as joined, and
// a cheese drip 6mm from the crust edge counted as joined while it hung in front of
// the face. Clustering is the wrong question. The question here is per part and
// metric: how far is this part's surface from the nearest OTHER surface? Zero means
// attached. Anything else is daylight, and daylight is what you see when it rotates.
//
// It measures that exactly — point to TRIANGLE, not point to sampled point, so a
// smooth face between two vertices is still solid surface — and cheaply, by binning
// every triangle into a grid once and looking only in the cells around each probe.
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

const HERE = dirname(fileURLToPath(import.meta.url));
const MODELS = join(HERE, "..", "public", "models");
const loader = new GLTFLoader();

/** Grid cell, and with it how far the search can see: a probe only looks in its own
 *  cell and the 26 around it, so anything nearer than this is found exactly. */
const CELL = 0.025;
/** Daylight this wide reads as detached on a figurine about one unit tall. Under it
 *  the part is touching or bevel-close, which looks like contact from every angle. */
const DETACHED = 0.012;
/** A part smaller than this share of the sculpt's largest part is a FEATURE — an eye,
 *  a wart, a mouth, a panel. Masses are left to check-assembly, which is the right
 *  guard for "the figurine has fallen into pieces". */
const FEATURE_SHARE = 0.55;

/**
 * Parts that are SUPPOSED to stand clear, by name.
 *
 * Deliberately short and specific. Every name here is a thing whose whole idea is to
 * hang in the air — smoke leaving a cigar, a halo over a saint, the plinth a bust is
 * displayed on. A blanket allowance for, say, anything called a "drop" would re-open
 * the exact defect this file exists to catch: the cheese drips WERE drops.
 */
const FREE_BY_DESIGN = [
  /\bsmoke\b|\bsteam\b|\bvapou?r\b|\bwisp\b/i,
  /\bhalo\b|\bnimbus\b/i,
  /\bplinth\b|\bpedestal\b/i,
  /^tangerine$|^leaf$/i,          // rests on the capybara's crown, by design
];

/**
 * A bow's loops and knot must each touch the FIGURINE, not merely each other.
 *
 * The rule below asks for the nearest OTHER part, and a bow is three parts that touch one
 * another: bunny-wrong's bow hung beside its head 17-40 mm clear, wet-plush's right loop
 * 19 mm and cute-skull's 30 mm, and all three passed, because each loop's nearest part
 * was its own knot. Ribbon is tied to something, so each piece is measured against the
 * rest of the sculpt with every bow part set aside. The glTF loader turns
 * "Bow.left" into "Bowleft" and "Bow left" into "Bow_left".
 */
const TIED = /^Bow_?(left|right|knot)\d*$/;

/** glTF flattens dots and spaces into underscores, so "Smoke ring.1" arrives as
 *  "Smoke_ring1" and a \b-anchored pattern quietly stops matching. Compare against
 *  the readable form, not the exported one. */
const readable = (name) => name.replace(/[_.]+/g, " ").trim();

const key = (ix, iy, iz) => `${ix},${iy},${iz}`;

/** Exact squared distance from a point to a triangle. */
function distSqToTri(p, a, b, c) {
  const ab = b.clone().sub(a), ac = c.clone().sub(a), ap = p.clone().sub(a);
  const d1 = ab.dot(ap), d2 = ac.dot(ap);
  if (d1 <= 0 && d2 <= 0) return ap.lengthSq();
  const bp = p.clone().sub(b);
  const d3 = ab.dot(bp), d4 = ac.dot(bp);
  if (d3 >= 0 && d4 <= d3) return bp.lengthSq();
  const vc = d1 * d4 - d3 * d2;
  if (vc <= 0 && d1 >= 0 && d3 <= 0) {
    const v = d1 / (d1 - d3);
    return ap.clone().sub(ab.clone().multiplyScalar(v)).lengthSq();
  }
  const cp = p.clone().sub(c);
  const d5 = ab.dot(cp), d6 = ac.dot(cp);
  if (d6 >= 0 && d5 <= d6) return cp.lengthSq();
  const vb = d5 * d2 - d1 * d6;
  if (vb <= 0 && d2 >= 0 && d6 <= 0) {
    const w = d2 / (d2 - d6);
    return ap.clone().sub(ac.clone().multiplyScalar(w)).lengthSq();
  }
  const va = d3 * d6 - d5 * d4;
  if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) {
    const w = (d4 - d3) / ((d4 - d3) + (d5 - d6));
    return bp.clone().sub(c.clone().sub(b).multiplyScalar(w)).lengthSq();
  }
  const denom = 1 / (va + vb + vc);
  const v = vb * denom, w = vc * denom;
  return ap.clone().sub(ab.clone().multiplyScalar(v)).sub(ac.clone().multiplyScalar(w)).lengthSq();
}

async function partsOf(file) {
  const buf = readFileSync(join(MODELS, file));
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  const scene = await new Promise((res, rej) =>
    loader.parse(ab, "", (g) => res(g.scene), rej));
  scene.updateWorldMatrix(true, true);
  const parts = [];
  scene.traverse((n) => {
    if (!n.isMesh || !n.geometry) return;
    const pos = n.geometry.attributes.position;
    const index = n.geometry.index;
    const m = n.matrixWorld;
    const verts = [];
    for (let i = 0; i < pos.count; i += 1) {
      verts.push(new THREE.Vector3().fromBufferAttribute(pos, i).applyMatrix4(m));
    }
    const tris = [];
    if (index) {
      for (let i = 0; i < index.count; i += 3) {
        tris.push([index.getX(i), index.getX(i + 1), index.getX(i + 2)]);
      }
    }
    if (!verts.length) return;
    if (!n.geometry.boundingBox) n.geometry.computeBoundingBox();
    const size = n.geometry.boundingBox.clone().applyMatrix4(m).getSize(new THREE.Vector3());
    parts.push({ name: n.name || "(unnamed)", verts, tris, span: Math.max(size.x, size.y, size.z) });
  });
  return parts;
}

/** Bin every triangle of every part into the cells its box covers. */
function binTriangles(parts) {
  const grid = new Map();
  parts.forEach((p, pi) => {
    for (const [ia, ib, ic] of p.tris) {
      const a = p.verts[ia], b = p.verts[ib], c = p.verts[ic];
      const lo = [Math.min(a.x, b.x, c.x), Math.min(a.y, b.y, c.y), Math.min(a.z, b.z, c.z)];
      const hi = [Math.max(a.x, b.x, c.x), Math.max(a.y, b.y, c.y), Math.max(a.z, b.z, c.z)];
      for (let ix = Math.floor(lo[0] / CELL); ix <= Math.floor(hi[0] / CELL); ix += 1) {
        for (let iy = Math.floor(lo[1] / CELL); iy <= Math.floor(hi[1] / CELL); iy += 1) {
          for (let iz = Math.floor(lo[2] / CELL); iz <= Math.floor(hi[2] / CELL); iz += 1) {
            const kk = key(ix, iy, iz);
            let here = grid.get(kk);
            if (!here) grid.set(kk, (here = []));
            here.push(pi, ia, ib, ic);
          }
        }
      }
    }
  });
  return grid;
}

/** Nearest surface of any OTHER part, or null when nothing is within a cell's reach. */
function nearestOther(parts, grid, pi, skip = new Set([pi])) {
  const p = parts[pi];
  // Probe the part's SURFACE, not just its corners. A 36-sided cylinder carries its
  // whole side wall on two rings of triangles, so a pommel sunk half into a torso
  // crosses that torso between probes: vertices and centroids alone put every sample
  // either deep inside (nearest surface far away) or well outside (likewise), and the
  // guard called a part that visibly overlaps the body detached. Each triangle is
  // subdivided by its own size, so no patch of surface goes unasked.
  const probes = p.verts.slice();
  for (const [ia, ib, ic] of p.tris) {
    const a = p.verts[ia], b = p.verts[ib], c = p.verts[ic];
    const longest = Math.max(a.distanceTo(b), b.distanceTo(c), c.distanceTo(a));
    const steps = Math.min(10, Math.max(1, Math.ceil(longest / (CELL * 0.8))));
    for (let u = 0; u <= steps; u += 1) {
      for (let v = 0; u + v <= steps; v += 1) {
        const wu = u / steps, wv = v / steps, wc = 1 - wu - wv;
        probes.push(new THREE.Vector3(
          a.x * wu + b.x * wv + c.x * wc,
          a.y * wu + b.y * wv + c.y * wc,
          a.z * wu + b.z * wv + c.z * wc,
        ));
      }
    }
  }
  let best = Infinity;
  for (const probe of probes) {
    const cx = Math.floor(probe.x / CELL), cy = Math.floor(probe.y / CELL), cz = Math.floor(probe.z / CELL);
    for (let dx = -1; dx <= 1; dx += 1) {
      for (let dy = -1; dy <= 1; dy += 1) {
        for (let dz = -1; dz <= 1; dz += 1) {
          const here = grid.get(key(cx + dx, cy + dy, cz + dz));
          if (!here) continue;
          for (let t = 0; t < here.length; t += 4) {
            const qi = here[t];
            if (skip.has(qi)) continue;
            const q = parts[qi];
            const d = distSqToTri(probe, q.verts[here[t + 1]], q.verts[here[t + 2]], q.verts[here[t + 3]]);
            if (d < best) best = d;
          }
        }
      }
    }
    if (best <= 1e-6) return 0;
  }
  return Number.isFinite(best) ? Math.sqrt(best) : null;
}

// `node scripts/check-seated.mjs void-cat midnight-pizza` narrows a re-check to the
// sculpts just edited; with no arguments the whole roster is checked.
const only = process.argv.slice(2).filter((a) => !a.startsWith("-"));
const files = readdirSync(MODELS)
  .filter((f) => f.endsWith(".glb"))
  .filter((f) => !only.length || only.includes(f.replace(/\.glb$/, "")))
  .sort();

const problems = [];
for (const file of files) {
  const id = file.replace(/\.glb$/, "");
  const parts = await partsOf(file);
  if (!parts.length) { problems.push(`${id}: no meshes`); continue; }
  const biggest = Math.max(...parts.map((p) => p.span));
  const grid = binTriangles(parts);
  const bow = new Set(parts.flatMap((p, i) => (TIED.test(p.name) ? [i] : [])));
  parts.forEach((p, i) => {
    if (bow.has(i)) {
      const gap = nearestOther(parts, grid, i, bow);
      if (gap === null || gap > DETACHED) {
        const how = gap === null ? `>${(CELL * 1000).toFixed(0)}mm` : `${(gap * 1000).toFixed(0)}mm`;
        problems.push(`UNTIED ${id}: ${p.name} — ${how} from the figurine (it touches only its own bow)`);
      }
    }
    if (p.span > biggest * FEATURE_SHARE) return;          // a mass, not a feature
    // Approved transparent wraith contains a deliberately suspended inner core.
    if (id === "gummy-wraith" && readable(p.name) === "Suspended teal wraith core") return;
    if (FREE_BY_DESIGN.some((re) => re.test(readable(p.name)))) return;
    const gap = nearestOther(parts, grid, i);
    if (gap !== null && gap <= DETACHED) return;
    const how = gap === null ? `>${(CELL * 1000).toFixed(0)}mm` : `${(gap * 1000).toFixed(0)}mm`;
    problems.push(`DETACHED ${id}: ${p.name} — ${how} from anything else`);
  });
}

console.log(`${files.length} sculpt${files.length === 1 ? "" : "s"} checked`);
if (problems.length) {
  problems.sort();
  for (const line of problems) console.log(line);
  console.log(
    `\n${problems.length} part(s) touch nothing. Seat them on the surface the rays find:\n` +
    "  draped_bow(body, point, …)     for a bow (UNTIED: it hangs off its own knot)\n" +
    "  g.seat_front(points, sink=…)   for a mouth, a brow, a spot, a drip\n" +
    "  g.body_cap(name, body, mat, …) for a chest or belly panel\n" +
    "and re-run. A part MEANT to hang in the air goes in FREE_BY_DESIGN above.");
  process.exit(1);
}
console.log("OK: every feature touches the sculpt it belongs to.");
