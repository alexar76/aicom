"""Generate the Chrome Gods and Sugar Riot mascot GLBs.

Run from Blender, for example:
    blender --background --python scripts/blender/generate_chrome_sugar.py
"""

import math
import os
import sys

import bmesh
import bpy
from mathutils import Vector

sys.path.insert(0, os.path.dirname(__file__))
import generate_raccoon as g


OUT_DIR = os.path.join(g.ROOT, "public", "models")


def cube(name, loc, scale, mat, rotation=(0, 0, 0), bevel=0.035):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rotation)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    mod = obj.modifiers.new("Edge radius", "BEVEL")
    mod.width = bevel
    mod.segments = 2
    return obj


def cone(name, loc, radii, depth, mat, rotation=(0, 0, 0), vertices=32):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radii[0],
        radius2=radii[1],
        depth=depth,
        location=loc,
        rotation=rotation,
    )
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    g.smooth(obj)
    mod = obj.modifiers.new("Edge polish", "BEVEL")
    mod.width = 0.012
    mod.segments = 2
    return obj


def front_disk(name, loc, radius, depth, mat, vertices=40, seat=True):
    """A disc lying flat against the front of whatever is already built there.

    Every caller used to hand it an absolute y, which is right at the centre line of a
    round body and wrong everywhere else: the shoulder rivets stood 23mm off the chrome
    and the percent dots 29mm off the orb. The y is now measured, and the disc is sunk
    by a third of its own depth so its back is inside the skin rather than resting on
    it. `seat=False` is for a disc that is not lying on anything — a free-standing
    plate, a coin held in a hand.
    """
    if seat:
        loc = g.seat_front([loc], sink=depth * 0.34,
                           ignore=g.FRONT_CLUTTER, label=name)[0]
    return g.cylinder(name, loc, radius, depth, mat, vertices, (math.pi / 2, 0, 0))


def eye_pair(prefix, z, spacing, size, socket, iris, mode="jewel", y=-0.31, ignore=g.FACE_BLOCKERS, seat=True):
    # Both eyes used to share ONE y. On a round face that is right on the centre line
    # and wrong at each eye: the cheek falls away, so the far edge of the eyeball lifts
    # off the skin and the pair reads as two beads hanging in front of the head. Each
    # side is now measured at its OWN x and carries the depth the author chose on the
    # centre line, so a nestled eye stays nestled and a proud one stays proud.
    # `seat=False` keeps a written y (Molar Breaker's last good face) instead of
    # letting the ray bury the sockets in the grape mass.
    black = g.material(f"{prefix}.black", (0.004, 0.006, 0.009), 0.18, 0.15, 0.6)
    white = g.material(f"{prefix}.glint", (1.0, 1.0, 0.98), 0.1, 0.0, 0.7)
    for side in (-1, 1):
        y_side = (
            g.seat_like(side * spacing, z, y, base_x=0.0,
                        ignore=ignore, label=f"{prefix}.{side}", span=size)
            if seat else y
        )
        g.uv(
            f"{prefix}.socket.{side}",
            (side * spacing, y_side + 0.025, z),
            (size * 1.3, size * 0.38, size * 1.35),
            socket,
            32,
            20,
        )
        if mode == "slit":
            g.uv(
                f"{prefix}.lens.{side}",
                (side * spacing, y_side - 0.01, z),
                (size * 0.74, size * 0.18, size),
                iris,
                28,
                18,
            )
            g.uv(
                f"{prefix}.slit.{side}",
                (side * spacing, y_side - 0.03, z),
                (size * 0.12, size * 0.06, size * 0.7),
                black,
                20,
                12,
            )
        elif mode == "dot":
            g.uv(
                f"{prefix}.dot.{side}",
                (side * spacing, y_side - 0.015, z),
                (size * 0.5, size * 0.15, size * 0.55),
                iris,
                24,
                16,
            )
        elif mode == "tired":
            g.uv(
                f"{prefix}.lens.{side}",
                (side * spacing, y_side - 0.01, z),
                (size * 0.8, size * 0.16, size * 0.58),
                iris,
                28,
                18,
            )
            g.curve(
                f"{prefix}.lid.{side}", [
                    (side * spacing - size * 0.75, y_side - 0.035, z + size * 0.12),
                    (side * spacing, y_side - 0.055, z + size * 0.3),
                    (side * spacing + size * 0.75, y_side - 0.035, z + size * 0.12),
                ],
                size * 0.08,
                black,
            )
        elif mode == "spiral":
            g.uv(
                f"{prefix}.lens.{side}",
                (side * spacing, y_side - 0.01, z),
                (size * 0.82, size * 0.17, size * 0.86),
                iris,
                28,
                18,
            )
            g.torus(
                f"{prefix}.spiral.{side}",
                g.seat_nearest([(side * spacing, y_side - 0.045, z)], proud=0.008,
                               ignore=("spiral",), label=f"{prefix}.spiral.{side}")[0],
                size * 0.4,
                size * 0.08,
                black,
                (math.pi / 2, 0, 0),
            )
        else:
            g.uv(
                f"{prefix}.jewel.{side}",
                (side * spacing, y_side - 0.01, z),
                (size * 0.76, size * 0.18, size * 0.86),
                iris,
                28,
                18,
            )
            g.uv(
                f"{prefix}.glint.{side}",
                g.seat_nearest([(side * spacing - size * 0.2, y_side - 0.035,
                                 z + size * 0.24)], proud=0.004,
                               ignore=("glint",), label=f"{prefix}.glint.{side}")[0],
                (size * 0.09,) * 3,
                white,
                16,
                10,
            )


def whole_eye_pair(prefix, z, spacing, size, socket, iris, y=-0.31, ignore=g.FACE_BLOCKERS):
    """One eyeball: a globe seated in the head, iris/pupil flush on that globe.

    `eye_pair(..., "slit")` stacked three discs along the look axis with fixed
    millimetre offsets. On Coil Serpent (size 0.064) that was:

        socket  y_side + 0.025   half-Y 0.0243   front ≈ y_side + 0.001
        lens    y_side - 0.010   half-Y 0.0115   front ≈ y_side - 0.022
        slit    y_side - 0.030   half-Y 0.0038   front ≈ y_side - 0.034

    Lens overlapped the socket by 0.9mm; the slit sat 4.6mm in front of the lens
    with daylight between them. That is the tower in the screenshot: a glossy
    bulge (the lime lens reading as sclera) and a pupil floating in front of it.

    This keeps the same seating y and the same front plane as the old lens, but
    the globe reaches back into the head and the iris/pupil are thin caps on
    that surface — inset or flush, never a third disc out in front.
    """
    sclera = g.material(f"{prefix}.sclera", (0.78, 0.80, 0.83), 0.16, 0.08, 0.55)
    ink = g.material(f"{prefix}.pupil", (0.004, 0.006, 0.009), 0.16, 0.15, 0.7)
    glint = g.material(f"{prefix}.glint", (1.0, 1.0, 0.98), 0.1, 0.0, 0.7)
    # Size-relative along -Y. Old slit used raw 10mm / 30mm, which is why a
    # 64mm eye grew a 35mm tower.
    socket_hy = size * 0.50
    sclera_hy = size * 0.68
    iris_hy = size * 0.08
    pupil_hy = size * 0.05
    for side in (-1, 1):
        y_side = g.seat_like(
            side * spacing, z, y, base_x=0.0,
            ignore=ignore, label=f"{prefix}.{side}", span=size,
        )
        # Recess behind the globe — a well, not a proud disc.
        g.uv(
            f"{prefix}.socket.{side}",
            (side * spacing, y_side + size * 0.28, z),
            (size * 1.22, socket_hy, size * 1.18),
            socket,
            32,
            20,
        )
        # Globe sunk so only a shallow cap shows; front matches the old lens.
        sclera_y = y_side + size * 0.35
        g.uv(
            f"{prefix}.sclera.{side}",
            (side * spacing, sclera_y, z),
            (size * 1.02, sclera_hy, size * 1.02),
            sclera,
            36,
            24,
        )
        sclera_front = sclera_y - sclera_hy
        # Thin lime cap: ~70% of its thickness lives inside the globe.
        iris_y = sclera_front + iris_hy * 0.70
        g.uv(
            f"{prefix}.iris.{side}",
            (side * spacing, iris_y, z),
            (size * 0.58, iris_hy, size * 0.62),
            iris,
            28,
            18,
        )
        # Slit sits in the iris, not in front of it.
        pupil_y = iris_y - iris_hy * 0.10
        g.uv(
            f"{prefix}.slit.{side}",
            (side * spacing, pupil_y, z),
            (size * 0.11, pupil_hy, size * 0.52),
            ink,
            20,
            12,
        )
        g.uv(
            f"{prefix}.glint.{side}",
            (side * spacing - size * 0.16, iris_y - iris_hy * 0.15, z + size * 0.18),
            (size * 0.07,) * 3,
            glint,
            14,
            10,
        )


def halo(name, loc, radius, mat, rotation=(math.pi / 2, 0, 0)):
    g.torus(name, loc, radius, radius * 0.055, mat, rotation)
    for side in (-1, 1):
        g.capsule(
            f"{name}.brace.{side}",
            (side * radius * 0.55, loc[1] + 0.02, loc[2] - radius * 0.8),
            (side * radius * 0.55, loc[1], loc[2] - radius * 0.35),
            radius * 0.025,
            mat,
        )


def mechanical_arm(prefix, side, shoulder, elbow, wrist, mat, joint, radius=0.065):
    g.capsule(f"{prefix}.upper.{side}", shoulder, elbow, radius, mat)
    g.uv(f"{prefix}.joint.{side}", elbow, (radius * 1.35,) * 3, joint, 28, 18)
    g.capsule(f"{prefix}.lower.{side}", elbow, wrist, radius * 0.82, mat)
    g.uv(f"{prefix}.hand.{side}", wrist, (radius * 1.2, radius * 0.8, radius), joint, 28, 18)


def wing(prefix, side, root, mat, rib, candy=False, clean_closure=False):
    x, y, z = root
    points = [
        (x, y, z),
        (x + side * 0.29, y + 0.015, z + 0.2),
        (x + side * 0.53, y + 0.02, z + 0.11),
        (x + side * 0.43, y - 0.005, z - 0.12),
        (x + side * 0.19, y - 0.015, z - 0.23),
    ]
    # Repeating the first knot on a cyclic Bezier makes AUTO handles at that
    # duplicate loop back through the centre of a hollow body such as Disk Angel.
    rim_points = points if clean_closure else points + [points[0]]
    g.curve(f"{prefix}.rim.{side}", rim_points, 0.035 if candy else 0.025, rib, True)
    for i in range(3):
        a = (x + side * (0.11 + i * 0.06), y, z + 0.04 - i * 0.08)
        b = (x + side * (0.39 + i * 0.045), y, z + 0.12 - i * 0.1)
        g.capsule(f"{prefix}.rib.{side}.{i}", a, b, 0.022, rib)
        g.uv(
            f"{prefix}.panel.{side}.{i}",
            ((a[0] + b[0]) / 2, y + 0.015, (a[2] + b[2]) / 2),
            (0.15, 0.025, 0.09),
            mat,
            28,
            16,
        ).rotation_euler[1] = side * (-0.35 + i * 0.15)


def sprinkle(prefix, loc, rotation, mat, length=0.1, seat=True):
    """A sprinkle lying on whatever it was scattered over.

    Wings face sideways and downward, so a forward ray finds nothing out there and the
    sprinkles kept the y they were written with — off the icing, in the air.
    """
    if seat:
        loc = g.seat_nearest([loc], proud=0.012, ignore=("sprinkle",), label=prefix)[0]
    g.cylinder(prefix, loc, 0.018, length, mat, 12, rotation)


def ellipsoid_front_y(center, scale, x, z, proud=0.0):
    """Front surface of an axis-aligned ellipsoid at x/z, minus a visible relief."""
    cx, cy, cz = center
    sx, sy, sz = scale
    radial = ((x - cx) / sx) ** 2 + ((z - cz) / sz) ** 2
    return cy - sy * math.sqrt(max(0.0, 1.0 - radial)) - proud


def on_ellipsoid(center, scale, point, proud=0.0):
    """Project a point onto an ellipsoid and step out along the outward normal.

    `stamp_on_ellipsoid` only knows the front (a y from x/z). Cheek blushes and
    sprinkles live on the flanks and the crown, where that y is the wrong
    question — the surface is sideways. This aims from the centre through
    `point` and lands on the skin, wherever that is.
    """
    cx, cy, cz = center
    sx, sy, sz = scale
    dx = (point[0] - cx) / sx
    dy = (point[1] - cy) / sy
    dz = (point[2] - cz) / sz
    r = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
    px, py, pz = cx + sx * dx / r, cy + sy * dy / r, cz + sz * dz / r
    normal = Vector((
        (px - cx) / (sx * sx),
        (py - cy) / (sy * sy),
        (pz - cz) / (sz * sz),
    ))
    normal.normalize()
    loc = Vector((px, py, pz)) + normal * proud
    return (loc.x, loc.y, loc.z), normal


def stamp_on_surface(center, scale, point, thick, clearance=0.001):
    """Thin plate on the ellipsoid at `point`'s surface, any side.

    Same pose as `stamp_on_ellipsoid`, but the landing is the real skin in
    the direction of `point`, not the front y at that x/z.
    """
    loc, normal = on_ellipsoid(center, scale, point, proud=0.0)
    loc = Vector(loc) + normal * (thick * 0.5 + clearance)
    rot = Vector((0.0, -1.0, 0.0)).rotation_difference(normal).to_euler()
    return (loc.x, loc.y, loc.z), (rot.x, rot.y, rot.z)


def stamp_on_ellipsoid(center, scale, x, z, thick, clearance=0.001):
    """Pose for a thin plate whose back sits on the front of an ellipsoid.

    A world-axis cube seated by y alone cuts into a round body on the inner
    edge and floats on the outer one — the gold percent plate grew into the
    chrome ball that way. Align the thin axis with the outward normal.

    `thick` is the cube() Y scale: size=1 then scale, so the plate's full
    thickness. Offset the centre by half of that so the back face is on
    the skin.
    """
    cx, cy, cz = center
    sx, sy, sz = scale
    y = ellipsoid_front_y(center, scale, x, z, proud=0.0)
    return stamp_on_surface(center, scale, (x, y, z), thick, clearance)


def on_stamp_front(obj, local_x, local_z, thick, proud=0.006):
    """World point on the front face of a thin plate, in the plate's own frame.

    After the stamp is tilted onto the chrome, a world-axis seat_front ray at
    the old x/z misses the plate and parks the glyph on the ball beside it.
    `thick` is the cube() Y scale — do not use world dimensions, which grow
    once the plate is rotated.
    """
    bpy.context.view_layer.update()
    local = Vector((local_x, -thick * 0.5 - proud, local_z))
    world = obj.matrix_world @ local
    return (world.x, world.y, world.z)


# --- Chrome Gods ---------------------------------------------------------


def build_mirror_idol():
    chrome = g.material("Mirror Idol chrome", (0.72, 0.76, 0.82), 0.08, 1.0, 0.65)
    dark = g.material("Mirror Idol seams", (0.035, 0.045, 0.06), 0.24, 0.86)
    cyan = g.material("Mirror Idol jewels", (0.18, 0.76, 1.0), 0.1, 0.45, 0.8)
    g.cylinder("Pedestal", (0, 0.06, -0.5), 0.39, 0.18, dark, 48)
    g.uv("Shoulder mantle", (0, 0, -0.12), (0.48, 0.25, 0.28), chrome, 48, 28)
    g.uv("Faceted head", (0, -0.015, 0.43), (0.34, 0.25, 0.42), chrome, 32, 20)
    cube("Face mirror", (0, -0.255, 0.43), (0.23, 0.035, 0.29), chrome, bevel=0.055)
    eye_pair("Idol", 0.49, 0.12, 0.075, dark, cyan)
    g.curve("Mouth seam", g.seat_front([(-0.12, -0.305, 0.3), (0, -0.32, 0.27), (0.12, -0.305, 0.3)], sink=0.005,
                                       ignore=g.FRONT_CLUTTER, label="Mouth seam"), 0.012, dark)
    for side in (-1, 1):
        cube(f"Temple panel.{side}", g.seat_front([(side * 0.27, -0.13, 0.48)], sink=0.004,
                                                  ignore=g.FRONT_CLUTTER, label=f"Temple panel.{side}")[0], (0.055, 0.13, 0.2), dark, (0, side * 0.22, 0), 0.018)
        front_disk(f"Shoulder rivet.{side}", g.seat_front([(side * 0.34, -0.235, -0.08)], sink=0.004,
                                                          ignore=g.FRONT_CLUTTER, label=f"Shoulder rivet.{side}")[0], 0.055, 0.025, cyan, 24)
    halo("Idol halo", (0, 0.08, 0.55), 0.48, chrome)


def build_liquid_blade():
    from redesigns_20261024.figures import BUILDERS
    return BUILDERS['liquid-blade']()


def build_orb_of_fees():
    chrome = g.material("Fees chrome", (0.48, 0.53, 0.61), 0.18, 0.88, 0.62)
    polish = g.material("Fees edge polish", (0.82, 0.87, 0.94), 0.1, 1.0, 0.72)
    dark = g.material("Fees grooves", (0.025, 0.032, 0.05), 0.3, 0.76)
    gold = g.material("Fees gold", (1.0, 0.58, 0.025), 0.2, 0.74, 0.56)
    paper = g.material("Fees receipt", (0.93, 0.9, 0.78), 0.32, 0.05, 0.45)
    red = g.material("Fees warning", (0.92, 0.055, 0.035), 0.22, 0.25, 0.58)

    # Offset, compressed armor masses make the silhouette read as a battered
    # fee machine instead of an untouched sphere.
    fee_body = ((-0.045, 0.03, 0.0), (0.47, 0.34, 0.48))
    g.uv("Offset fee body", fee_body[0], fee_body[1], chrome, 48, 32)
    g.uv("Flattened tariff side", (0.38, -0.015, 0.0), (0.16, 0.28, 0.36), dark, 32, 22)
    cube("Asymmetric fee bite", (0.425, -0.25, 0.04), (0.105, 0.045, 0.22), red, (0, -0.12, 0), 0.06)
    for i, z in enumerate((0.2, 0.04, -0.12)):
        g.uv(f"Bite notch.{i}", (0.47, -0.305, z), (0.09, 0.045, 0.07), dark, 24, 16)
    # A CIRCLE on an OVAL body cuts in at the wide axis and floats at the narrow one:
    # this body is 0.468 wide and 0.338 deep at the equator's height, so a 0.43 ring
    # sat 38mm inside the chrome across the flanks and 90mm off it front and back.
    # Laid on the silhouette the rays actually find instead.
    g.band_here("Tariff equator", -0.04, 0.022, polish,
                ignore=("Arm", "Hand", "Receipt", "Antenna", "Panel", "Slash", "Glyph"))

    # Percent / dollar stamps sit ON the chrome. The old 35mm cubes were seated
    # 4mm under the skin, so the gold block grew into the ball and the % slash
    # vanished — four dark blobs at the corners of a cube fused with the chrome.
    # Thin plates, tilted onto the skin; glyphs live in the plate's own frame.
    stamp_thick = 0.012
    percent_loc, percent_rot = stamp_on_ellipsoid(*fee_body, -0.17, 0.12, stamp_thick)
    percent = cube("Percent panel", percent_loc, (0.12, stamp_thick, 0.14), gold, percent_rot, 0.005)
    front_disk("Percent dot top", on_stamp_front(percent, -0.032, 0.045, stamp_thick), 0.024, 0.010, dark, 24, seat=False)
    front_disk("Percent dot bottom", on_stamp_front(percent, 0.032, -0.045, stamp_thick), 0.024, 0.010, dark, 24, seat=False)
    g.capsule(
        "Percent slash",
        on_stamp_front(percent, -0.042, -0.055, stamp_thick),
        on_stamp_front(percent, 0.042, 0.055, stamp_thick),
        0.012,
        dark,
    )
    dollar_loc, dollar_rot = stamp_on_ellipsoid(*fee_body, 0.14, -0.16, stamp_thick)
    dollar = cube("Dollar panel", dollar_loc, (0.12, stamp_thick, 0.13), paper, dollar_rot, 0.005)
    g.curve(
        "Dollar glyph",
        [
            on_stamp_front(dollar, 0.048, 0.068, stamp_thick),
            on_stamp_front(dollar, -0.042, 0.068, stamp_thick),
            on_stamp_front(dollar, -0.050, 0.0, stamp_thick),
            on_stamp_front(dollar, 0.042, -0.008, stamp_thick),
            on_stamp_front(dollar, 0.042, -0.068, stamp_thick),
            on_stamp_front(dollar, -0.052, -0.068, stamp_thick),
        ],
        0.014,
        dark,
    )
    g.capsule(
        "Dollar stem",
        on_stamp_front(dollar, 0.0, -0.088, stamp_thick),
        on_stamp_front(dollar, 0.0, 0.088, stamp_thick),
        0.010,
        dark,
    )

    # Receipt/meter head. The orb's crown is at z=0.51, so the housing is sunk into
    # it and carried on a visible neck: centred at 0.52 it perched on the sphere's
    # single top point with nothing joining the two, and the paper floated a further
    # 0.1 above that — three unrelated objects hovering over a ball.
    g.cylinder("Meter neck", (-0.03, -0.01, 0.40), 0.115, 0.30, chrome, 28)
    g.band_here("Meter neck collar", 0.50, 0.022, polish, ignore=("Arm", "Hand"))
    cube("Meter crown", (-0.03, 0.0, 0.60), (0.27, 0.2, 0.17), dark, (0, 0, -0.04), 0.055)
    # Dial, bezel and needle travelled together — 38mm in front of the crown they are
    # set into, so the whole meter face floated.
    front_disk("Meter dial", g.seat_front([(-0.03, -0.155, 0.60)], sink=0.004,
                                          ignore=g.FRONT_CLUTTER, label="Meter dial")[0], 0.105, 0.03, gold, 36)
    g.torus("Meter dial bezel", g.seat_front([(-0.03, -0.165, 0.60)], sink=0.004,
                                             ignore=g.FRONT_CLUTTER, label="Meter dial bezel")[0], 0.108, 0.016, polish, (math.pi / 2, 0, 0))
    needle = g.seat_front([(-0.03, -0.185, 0.60), (0.028, -0.185, 0.655)], sink=0.004,
                          ignore=g.FRONT_CLUTTER, label="Meter needle")
    g.capsule("Meter needle", needle[0], needle[1], 0.012, red)
    # Tear bar along the slot on the crown's top face, where a printer's actually is.
    cube("Receipt slot", g.seat_front([(-0.03, -0.06, 0.687)], sink=0.004,
                                      ignore=g.FRONT_CLUTTER, label="Receipt slot")[0], (0.23, 0.045, 0.022), dark, bevel=0.008)
    for i in range(5):
        cone(f"Receipt tear.{i}", (-0.13 + i * 0.05, -0.06, 0.703), (0.018, 0.003), 0.03, polish, vertices=10)
    # The strip feeds out of that slot: its lower edge starts inside the housing and
    # it curls forward, so it reads as paper coming off a roll rather than a card.
    cube("Receipt sheet", (-0.03, -0.075, 0.80), (0.19, 0.014, 0.17), paper, (0.26, 0, -0.03), 0.012)
    for i in range(3):
        cube(
            f"Receipt line.{i}", g.seat_nearest([(-0.045, -0.082 - i * 0.006, 0.855 - i * 0.055)], proud=0.0,
                             label=f"Receipt line.{i}")[0],
            (0.105 - i * 0.016, 0.006, 0.008),
            dark,
            (0.26, 0, -0.03),
            bevel=0.004,
        )

    # Short pincers cluster around the face like a coin-slot mechanism.
    for side in (-1, 1):
        shoulder = (side * 0.34, -0.14, -0.02)
        elbow = (side * 0.48, -0.27, -0.08)
        wrist = (side * 0.34, -0.42, -0.16)
        g.capsule(f"Coin pincer upper.{side}", shoulder, elbow, 0.045, polish)
        g.uv(f"Coin pincer joint.{side}", elbow, (0.065,) * 3, gold, 24, 16)
        g.capsule(f"Coin pincer lower.{side}", elbow, wrist, 0.038, chrome)
        for finger in (-1, 1):
            g.capsule(
                f"Coin slot finger.{side}.{finger}",
                wrist,
                (side * (0.23 + finger * 0.025), -0.46, -0.12 + finger * 0.065),
                0.022,
                gold,
            )


def build_winged_bolt():
    chrome = g.material("Bolt chrome", (0.7, 0.71, 0.74), 0.13, 0.94)
    dark = g.material("Bolt recess", (0.055, 0.06, 0.07), 0.3, 0.75)
    orange = g.material("Bolt orange", (1.0, 0.27, 0.035), 0.18, 0.55, 0.55)
    g.cylinder("Hex head", (0, 0, 0.42), 0.32, 0.28, chrome, 6)
    # One solid shaft ending in a short bevel. The old separate cone touched it
    # with its point and flared downward, like a bell hanging off the bolt.
    segments = 48
    shaft_profile = ((0.14, -0.615), (0.18, -0.565), (0.18, 0.295))
    verts = [
        (radius * math.cos(i * math.tau / segments),
         radius * math.sin(i * math.tau / segments), z)
        for radius, z in shaft_profile for i in range(segments)
    ]
    faces = []
    for ring in range(len(shaft_profile) - 1):
        for i in range(segments):
            j = (i + 1) % segments
            faces.append((ring * segments + i, ring * segments + j,
                          (ring + 1) * segments + j, (ring + 1) * segments + i))
    faces.extend((tuple(reversed(range(segments))),
                  tuple(range((len(shaft_profile) - 1) * segments, len(verts)))))
    mesh = bpy.data.meshes.new("Threaded shaft.mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(chrome)
    shaft = bpy.data.objects.new("Threaded shaft", mesh)
    bpy.context.collection.objects.link(shaft)
    g.smooth(shaft)
    for face in mesh.polygons[-2:]:
        face.use_smooth = False

    # A continuous right-hand screw thread with broad flanks and a narrow crest,
    # rather than separate collars or a round wire spring. Its roots intersect
    # the shaft, and both ends fade into the steel instead of ending in a stump.
    turns, pitch, steps = 5, 0.125, 320
    root_radius, crest_radius = 0.176, 0.207
    verts, faces = [], []
    for i in range(steps + 1):
        t = i / steps
        angle = -math.tau * turns * t
        z = 0.18 - turns * pitch * t
        fade = min(1.0, t * turns / 0.35, (1.0 - t) * turns / 0.35)
        fade = max(0.04, fade * fade * (3.0 - 2.0 * fade))
        crest = root_radius + (crest_radius - root_radius) * fade
        for radius, dz in ((root_radius, -0.04), (crest, -0.008),
                           (crest, 0.008), (root_radius, 0.04)):
            verts.append((radius * math.cos(angle), radius * math.sin(angle), z + dz))
    for i in range(steps):
        for j in range(4):
            k = (j + 1) % 4
            faces.append((i * 4 + j, i * 4 + k, (i + 1) * 4 + k, (i + 1) * 4 + j))
    faces.extend(((3, 2, 1, 0), tuple(range(steps * 4, steps * 4 + 4))))
    mesh = bpy.data.meshes.new("Thread.helix.mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(chrome)
    thread = bpy.data.objects.new("Thread.helix", mesh)
    bpy.context.collection.objects.link(thread)
    g.smooth(thread)
    for face in mesh.polygons[-2:]:
        face.use_smooth = False
    front_disk("Bolt face", (0, -0.16, 0.42), 0.23, 0.025, dark, 6)
    eye_pair("Bolt", 0.46, 0.1, 0.055, dark, orange, "dot", -0.19)
    wing("Bolt wing", -1, (-0.2, 0.02, 0.28), chrome, orange)
    wing("Bolt wing", 1, (0.2, 0.02, 0.28), chrome, orange)


def build_piston_saint():
    steel = g.material("Piston steel", (0.34, 0.36, 0.4), 0.16, 0.92)
    chrome = g.material("Piston polish", (0.78, 0.8, 0.84), 0.09, 1.0)
    dark = g.material("Piston seams", (0.045, 0.05, 0.06), 0.31, 0.78)
    violet = g.material("Piston jewel", (0.45, 0.55, 1.0), 0.1, 0.4, 0.8)
    g.cylinder("Crank base", (0, 0, -0.48), 0.38, 0.2, dark, 48)
    g.cylinder("Cylinder block", (0, 0, -0.03), 0.31, 0.76, steel, 48)
    g.cylinder("Piston crown", (0, 0, 0.45), 0.38, 0.2, chrome, 48)
    g.torus("Compression ring A", (0, 0, 0.2), 0.315, 0.018, dark)
    g.torus("Compression ring B", (0, 0, -0.14), 0.315, 0.018, dark)
    cube("Face panel", g.seat_front([(0, -0.3, 0.13)], sink=0.004,
                                    ignore=g.FRONT_CLUTTER, label="Face panel")[0], (0.22, 0.035, 0.2), dark, bevel=0.035)
    eye_pair("Piston", 0.18, 0.095, 0.064, dark, violet, "jewel", -0.34)
    for side in (-1, 1):
        mechanical_arm("Piston rod", side, (side * 0.3, 0, 0.12), (side * 0.5, -0.03, -0.05), (side * 0.42, -0.22, -0.29), chrome, violet, 0.055)
    # Keep the floating halo clear of the piston crown (top z=0.55).
    g.torus("Piston halo", (0, 0, 0.76), 0.34, 0.022, chrome, (0.15, 0, 0))


def build_disk_angel():
    pearl = g.material("Disk pearl", (0.84, 0.86, 0.9), 0.08, 1.0, 0.7)
    dark = g.material("Disk grooves", (0.07, 0.075, 0.1), 0.24, 0.82)
    violet = g.material("Disk angel violet", (0.35, 0.3, 1.0), 0.1, 0.55, 0.85)
    g.torus("Living disk", (0, 0, 0.08), 0.42, 0.13, pearl, (math.pi / 2, 0, 0))
    # The mould is a hollow halo. Its old hub and eyes filled the opening with
    # a second face. Keep the jewel eyes on the solid upper rim, with every layer
    # overlapping its support, and leave the complete central aperture empty.
    for side in (-1, 1):
        x = side * 0.37
        g.uv(f"Disk.eye.socket.{side}", (x, -0.128, 0.24), (0.055, 0.016, 0.056), dark, 32, 20)
        g.uv(f"Disk.eye.jewel.{side}", (x, -0.145, 0.24), (0.038, 0.010, 0.043), violet, 28, 18)
        g.uv(f"Disk.eye.glint.{side}", (x - 0.008, -0.154, 0.251), (0.0045,) * 3, pearl, 16, 10)
    wing("Disk wing", -1, (-0.33, 0.02, 0.14), pearl, violet, clean_closure=True)
    wing("Disk wing", 1, (0.33, 0.02, 0.14), pearl, violet, clean_closure=True)
    for side in (-1, 1):
        g.capsule(f"Disk leg.{side}", (side * 0.17, 0, -0.25), (side * 0.22, -0.08, -0.55), 0.045, dark)
        cube(f"Disk foot.{side}", (side * 0.22, -0.14, -0.58), (0.13, 0.18, 0.055), pearl, bevel=0.035)
    # Its rear nimbus also clears the opening rather than cutting across its top.
    halo("Disk halo", (0, 0.08, 0.70), 0.3, violet)


def build_coil_serpent():
    from redesigns_20261024.figures import BUILDERS
    return BUILDERS['coil-serpent']()


def build_mask_zero():
    black = g.material("Zero black chrome", (0.012, 0.014, 0.02), 0.1, 0.98, 0.7)
    silver = g.material("Zero silver", (0.86, 0.87, 0.9), 0.08, 1.0)
    recess = g.material("Zero recess", (0.001, 0.002, 0.004), 0.2, 0.35)
    g.cylinder("Zero plinth", (0, 0.04, -0.5), 0.38, 0.16, black, 48)
    g.uv("Zero shoulders", (0, 0, -0.12), (0.48, 0.23, 0.27), black, 44, 26)
    g.uv("Zero hood", (0, 0, 0.39), (0.34, 0.26, 0.43), black, 40, 24)
    cube("Zero faceplate", (0, -0.255, 0.42), (0.24, 0.035, 0.3), silver, bevel=0.09)
    # The plate's front is y=-0.2725. Embed the visor's back in it rather than
    # leaving 28.5mm of air, and set both eye slits on that one measured plane.
    # Seating one side at a time used the already-built opposite slit as a host,
    # producing different depths and burying half of both slits behind the visor.
    cube("Zero visor", (0, -0.274, 0.5), (0.2, 0.018, 0.075), recess, bevel=0.025)
    for side in (-1, 1):
        g.uv(f"Zero eye slit.{side}", (side * 0.052, -0.282, 0.5), (0.035, 0.008, 0.012), silver, 24, 16)
        cube(f"Cheek vent.{side}", g.seat_front([(side * 0.14, -0.3, 0.31)], sink=0.004,
                                                ignore=g.FRONT_CLUTTER, label=f"Cheek vent.{side}")[0], (0.055, 0.015, 0.08), recess, (0, 0, side * 0.2), 0.012)
        # Placed against the collar, not against the shoulder behind it — seating
        # this one sank it 57% into the plate it is supposed to clasp.
        front_disk(f"Collar lock.{side}", (side * 0.3, -0.205, -0.08), 0.06, 0.025,
                   silver, 24, seat=False)
    g.band_here("Zero collar", 0.02, 0.035, silver, ignore=("Arm", "Hand"))


# --- Sugar Riot ----------------------------------------------------------


def build_molar_breaker():
    purple = g.material("Molar Breaker grape vinyl", (0.48, 0.12, 0.78), 0.24, 0.08, 0.68)
    pink = g.material("Molar Breaker berry vinyl", (1.0, 0.16, 0.52), 0.22, 0.04, 0.7)
    cyan = g.material("Molar Breaker blue candy", (0.08, 0.73, 0.9), 0.24, 0.03, 0.66)
    cream = g.material("Molar Breaker tooth", (1.0, 0.88, 0.62), 0.31, 0.0, 0.56)
    dark = g.material("Molar Breaker mouth", (0.1, 0.012, 0.09), 0.42, 0.02)
    blush = g.material("Molar Breaker blush", (0.16, 0.02, 0.12), 0.38, 0.02, 0.45)
    tongue_mat = g.material("Molar Breaker tongue", (0.92, 0.14, 0.40), 0.28, 0.0, 0.62)

    # Two offset candy masses. One mouth in the crease: dark hole, pink only
    # as a thin lip at the gum line — not a steak the fangs sit in
    # («ну не надо язык кусать»).
    head = ((-0.03, 0.025, 0.24), (0.46, 0.34, 0.32))
    body = ((0.045, 0.025, -0.28), (0.4, 0.32, 0.22))
    g.uv("Molar Breaker upper mass", head[0], head[1], purple, 48, 30)
    g.uv("Molar Breaker lower mass", body[0], body[1], pink, 44, 28)
    g.uv("Lower jaw chin", (0.07, -0.17, -0.37), (0.34, 0.2, 0.15), purple, 36, 24)

    # Dark oval on the front of the crease — the hole. Tall enough that
    # both rows sit on its rims; the back goes into the candy so a 3/4
    # turn reads as a recess, not a grape stuck in the gap.
    g.uv("Mouth cavity", (0.01, -0.26, -0.055), (0.20, 0.10, 0.125), dark, 28, 18)
    # Thin berry gums on the poles. Pink is the rim, not the filling.
    g.uv("Upper lip", (0.01, -0.34, 0.078), (0.17, 0.018, 0.015), pink, 22, 14)
    g.uv("Lower lip", (0.01, -0.34, -0.188), (0.17, 0.018, 0.015), pink, 22, 14)
    # Tongue on the cavity's front, in the tip-gap — behind the fangs,
    # visible in the hole, too small to be a steak.
    g.uv("Tongue", (0.01, -0.34, -0.055), (0.07, 0.020, 0.015), tongue_mat, 20, 14)

    # In front of the tongue. Bases on the lips, tips into the dark,
    # clear of the tongue's Z so nothing is impaled.
    tooth_y = -0.36
    tooth_depth = 0.112
    for i in range(5):
        x = -0.16 + i * 0.08
        cone(
            f"Upper front tooth.{i}",
            (x, tooth_y, 0.028),
            (0.038, 0.011),
            tooth_depth,
            cream,
            (math.pi, 0, 0),
            16,
        )
        cone(
            f"Lower front tooth.{i}",
            (x, tooth_y, -0.138),
            (0.038, 0.011),
            tooth_depth,
            cream,
            (0, 0, 0),
            16,
        )
    eye_pair("Molar Breaker", 0.27, 0.14, 0.085, dark, cream, "jewel", -0.32, seat=False)

    # Cheek blushes. The rear shot's dark ovals were the old silhouette-bite
    # blobs parked beside the head; a prior pass only nudged the front discs
    # 40mm and left them FREE_BY_DESIGN. A flattened sphere whose centre sits
    # just inside the grape shows as an oval stain — paint, not a satellite.
    for i, point in enumerate((
        (-0.38, -0.12, 0.30),
        (-0.40, -0.10, 0.16),
        (-0.36, -0.08, 0.04),
        (0.34, -0.12, 0.22),
    )):
        loc, _ = on_ellipsoid(*head, point, proud=-0.028)
        g.uv(f"Cheek blush.{i}", loc, (0.075, 0.048, 0.062), blush, 24, 16)

    # Sprinkles (посыпка): the old candy stripes and patches. Same colours,
    # now stamped onto the mass they belong to so they touch instead of orbit.
    sprinkle_thick = 0.020
    for i, (host, point, sx, sz, mat) in enumerate((
        (head, (-0.22, -0.12, 0.48), 0.09, 0.028, pink),
        (head, (-0.04, -0.08, 0.52), 0.08, 0.026, cream),
        (head, (0.18, -0.10, 0.46), 0.09, 0.028, cyan),
        (head, (0.20, 0.22, 0.30), 0.05, 0.05, cream),
        (body, (-0.28, -0.06, -0.22), 0.08, 0.026, cyan),
        (body, (0.26, -0.08, -0.18), 0.08, 0.026, cream),
        (body, (0.16, 0.20, -0.20), 0.05, 0.05, pink),
    )):
        loc, rot = stamp_on_surface(*host, point, sprinkle_thick, clearance=0.0)
        cube(f"Candy sprinkle.{i}", loc, (sx, sprinkle_thick, sz), mat, rot, 0.016)

    # Stick and cyan disk stay at the last-good hold. The cream/pink rings sat
    # 45mm in front of the disk (the floating lollipop in 3/4) — park them on
    # the disk face, not seat_nearest onto the body.
    g.capsule("Swirl prop stick", (0.34, 0.0, -0.25), (0.58, -0.02, 0.16), 0.035, cream)
    front_disk("Swirl prop face", (0.59, -0.02, 0.27), 0.17, 0.08, cyan, 40, seat=False)
    for radius, mat in ((0.125, cream), (0.075, pink), (0.03, cream)):
        g.torus(f"Swirl prop ring.{radius}", (0.59, -0.06, 0.27), radius, 0.018, mat, (math.pi / 2, 0, 0))


def build_sour_worm():
    green = g.material("Sour worm lime", (0.16, 0.83, 0.28), 0.34, 0.0, 0.55)
    pink = g.material("Sour worm berry", (0.98, 0.27, 0.57), 0.32, 0.0, 0.6)
    sugar = g.material("Sour sugar", (0.95, 0.98, 0.76), 0.6)
    dark = g.material("Sour face", (0.05, 0.08, 0.025), 0.48)
    points = [(-0.32, 0.06, -0.48), (0.1, 0.03, -0.43), (0.3, 0, -0.18), (0.08, -0.02, 0.04), (-0.13, -0.03, 0.28), (0.02, -0.04, 0.55)]
    for i in range(len(points) - 1):
        g.capsule(f"Gummy segment.{i}", points[i], points[i + 1], 0.15, green if i % 2 else pink)
        for j in range(3):
            p = Vector(points[i]).lerp(Vector(points[i + 1]), (j + 1) / 4)
            g.uv(f"Sugar crystal.{i}.{j}", p + Vector((0, -0.135, 0)), (0.022,) * 3, sugar, 12, 8)
    g.uv("Sour worm head", (0.02, -0.04, 0.62), (0.27, 0.22, 0.22), green, 36, 24)
    eye_pair("Sour", 0.65, 0.11, 0.06, dark, sugar, "dot", -0.23)
    g.curve("Sour grimace", g.seat_front([(-0.12, -0.265, 0.55), (0, -0.29, 0.52), (0.13, -0.265, 0.55)], sink=0.005,
                                         ignore=g.FRONT_CLUTTER, label="Sour grimace"), 0.014, dark)


def build_cola_cube():
    cola = g.material("Cola caramel glass", (0.28, 0.07, 0.015), 0.21, 0.05, 0.65)
    amber = g.material("Cola amber", (0.82, 0.32, 0.045), 0.25, 0.02, 0.55)
    cream = g.material("Cola foam", (0.98, 0.9, 0.7), 0.52)
    dark = g.material("Cola recess", (0.04, 0.014, 0.006), 0.35)
    toffee = g.material("Cola toffee boots", (0.10, 0.028, 0.009), 0.29, 0.0, 0.45)
    glint = g.material("Cola eye glint", (1.0, 0.98, 0.9), 0.15)

    def soft_box(name, loc, size, material, bevel):
        obj = cube(name, loc, size, material, bevel=bevel)
        obj.modifiers["Edge radius"].segments = 6
        obj.modifiers["Edge radius"].harden_normals = True
        g.smooth(obj)
        normals = obj.modifiers.new("Candy face normals", "WEIGHTED_NORMAL")
        normals.keep_sharp = True
        return obj

    # Rounded candy edges around broad, clean cube faces. The amber field is a
    # shallow inlay; both smaller eyes fit inside it instead of straddling its rim.
    soft_box("Cola cube body", (0, 0, 0), (0.56, 0.44, 0.56), cola, 0.065)
    soft_box("Front label recess", (0, -0.219, 0.015),
             (0.42, 0.022, 0.32), amber, 0.008)

    # Compact cola foam, fused into ONE soft mass. Varied overlapping bubbles
    # replace the oversized flat ellipsoid and its mechanical row of studs.
    foam = [soft_box("Foam base", (0, 0.01, 0.305),
                     (0.60, 0.47, 0.13), cream, 0.06)]
    for i, (loc, size) in enumerate((
        ((-0.19, -0.10, 0.365), (0.10, 0.10, 0.09)),
        ((-0.03, -0.105, 0.395), (0.12, 0.11, 0.10)),
        ((0.16, -0.085, 0.375), (0.11, 0.10, 0.085)),
        ((-0.16, 0.09, 0.37), (0.11, 0.095, 0.10)),
        ((0.04, 0.09, 0.41), (0.13, 0.11, 0.095)),
        ((0.19, 0.10, 0.355), (0.095, 0.09, 0.085)),
        ((-0.19, -0.17, 0.305), (0.065, 0.055, 0.09)),
    )):
        foam.append(g.uv(f"Foam bubble.{i}", loc, size, cream, 36, 24))
    bpy.ops.object.select_all(action="DESELECT")
    for obj in foam:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = foam[0]
    bpy.ops.object.convert(target="MESH")
    bpy.ops.object.join()
    foam_cap = bpy.context.object
    foam_cap.name = "Foam cap"
    fuse = foam_cap.modifiers.new("Continuous cola foam", "REMESH")
    fuse.mode = "VOXEL"
    fuse.voxel_size = 0.007
    bpy.ops.object.modifier_apply(modifier=fuse.name)
    polish = foam_cap.modifiers.new("Soft foam skin", "SMOOTH")
    polish.factor = 0.6
    polish.iterations = 3
    bpy.ops.object.modifier_apply(modifier=polish.name)
    # Voxel fusion can leave microscopic enclosed shells between overlapping
    # bubbles. The foam is one mass: keep its exterior connected surface only.
    bm = bmesh.new()
    bm.from_mesh(foam_cap.data)
    unseen, islands = set(bm.verts), []
    while unseen:
        seed = unseen.pop()
        island, stack = {seed}, [seed]
        while stack:
            for edge in stack.pop().link_edges:
                for vertex in edge.verts:
                    if vertex in unseen:
                        unseen.remove(vertex)
                        island.add(vertex)
                        stack.append(vertex)
        islands.append(island)
    exterior = max(islands, key=len)
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if v not in exterior], context="VERTS")
    bm.to_mesh(foam_cap.data)
    bm.free()
    g.smooth(foam_cap)

    # Shallow inset candy eyes: each cream centre overlaps its dark socket, which
    # overlaps the face inlay. No stack of discs hanging in front of the body.
    for side in (-1, 1):
        x = side * 0.102
        g.uv(f"Cola.socket.{side}", (x, -0.226, 0.095),
             (0.063, 0.018, 0.065), dark, 40, 28)
        g.uv(f"Cola.dot.{side}", (x, -0.242, 0.082),
             (0.030, 0.010, 0.034), cream, 36, 24)
        g.uv(f"Cola.glint.{side}", (x - 0.009, -0.251, 0.094),
             (0.004, 0.0025, 0.004), glint, 16, 12)
    mouth = g.curve("Cola smile", [(-0.085, -0.234, -0.063),
                                  (-0.018, -0.234, -0.078),
                                  (0.052, -0.234, -0.072),
                                  (0.091, -0.234, -0.052)], 0.008, dark)
    mouth.data.use_fill_caps = True

    for side in (-1, 1):
        # Short bent arms with shoulders and wrists visibly sunk into their hosts.
        shoulder = (side * 0.245, -0.01, 0.07)
        elbow = (side * 0.335, -0.05, -0.015)
        wrist = (side * 0.37, -0.12, -0.075)
        g.capsule(f"Cola arm.upper.{side}", shoulder, elbow, 0.046, amber)
        g.uv(f"Cola elbow.{side}", elbow, (0.048,) * 3, amber, 28, 20)
        g.capsule(f"Cola arm.lower.{side}", elbow, wrist, 0.043, amber)
        g.uv(f"Cola hand.{side}", (side * 0.387, -0.145, -0.085),
             (0.062, 0.057, 0.059), cream, 36, 24)
        # Feet need load-bearing legs. The old nearest-surface placement left
        # 12mm of daylight: explicit ankles now overlap BOTH body and boots.
        g.capsule(f"Cola leg.{side}", (side * 0.145, -0.015, -0.235),
                  (side * 0.16, -0.055, -0.34), 0.056, cola)
        soft_box(f"Cola foot.{side}", (side * 0.16, -0.08, -0.36),
                 (0.21, 0.235, 0.11), toffee, 0.04)


def build_frost_imp():
    ice = g.material("Frost pearl", (0.72, 0.9, 1.0), 0.18, 0.08, 0.7)
    blue = g.material("Frost shadow", (0.17, 0.55, 0.82), 0.3, 0.05, 0.45)
    pink = g.material("Frost candy", (1.0, 0.29, 0.5), 0.25, 0.0, 0.6)
    dark = g.material("Frost pupils", (0.035, 0.09, 0.16), 0.4)
    g.uv("Imp squat torso", (0, 0, -0.05), (0.43, 0.32, 0.4), ice, 44, 28)
    g.uv("Imp head", (0, -0.03, 0.42), (0.38, 0.29, 0.31), ice, 44, 28)
    for side in (-1, 1):
        cone(f"Rooted ice horn.{side}", (side * 0.25, 0, 0.72), (0.14, 0.015), 0.35, blue, (0, side * 0.32, side * 0.15), 28)
        g.uv(f"Horn collar.{side}", (side * 0.30, -0.01, 0.70), (0.15, 0.115, 0.085), ice, 28, 18)
        g.capsule(f"Imp arm.{side}", (side * 0.34, -0.02, 0.19), (side * 0.48, -0.2, -0.05), 0.07, blue)
        g.uv(f"Imp foot.{side}", (side * 0.25, -0.2, -0.43), (0.22, 0.19, 0.09), pink, 32, 20)
    eye_pair("Frost", 0.48, 0.16, 0.09, blue, pink, "jewel", -0.3)
    for i in range(3):
        cone(f"Chest icicle.{i}", ((i - 1) * 0.1, -0.33, 0.05), (0.045, 0.008), 0.2, ice, (math.pi, 0, 0), 20)


def build_lollipop_golem():
    pink = g.material("Lollipop pink", (1.0, 0.25, 0.48), 0.22, 0.0, 0.72)
    cream = g.material("Lollipop cream", (1.0, 0.93, 0.82), 0.3, 0.0, 0.6)
    cyan = g.material("Lollipop jewel", (0.12, 0.8, 0.92), 0.16, 0.0, 0.72)
    dark = g.material("Lollipop sockets", (0.17, 0.025, 0.08), 0.42)
    g.cylinder("Candy stick torso", (0, 0, -0.19), 0.11, 0.7, cream, 32)
    front_disk("Spiral candy head", g.seat_front([(0, -0.03, 0.43)], sink=0.004,
                                                 ignore=g.FRONT_CLUTTER, label="Spiral candy head")[0], 0.37, 0.16, pink, 48)
    for r in (0.29, 0.2, 0.11):
        g.torus(f"Candy spiral.{r}", g.seat_front([(0, -0.13, 0.43)], sink=0.004,
                                                  ignore=g.FRONT_CLUTTER, label=f"Candy spiral.{r}")[0], r, 0.025, cream, (math.pi / 2, 0, 0))
    eye_pair("Lollipop", 0.48, 0.14, 0.07, dark, cyan, "jewel", -0.13)
    for side in (-1, 1):
        mechanical_arm("Candy arm", side, (side * 0.31, 0, 0.32), (side * 0.52, -0.03, 0.1), (side * 0.43, -0.2, -0.18), pink, cyan, 0.055)
        cube(f"Candy boot.{side}",
             g.seat_nearest([(side * 0.18, -0.08, -0.56)], proud=0.055,
                            ignore=("boot",), label=f"Candy boot.{side}")[0],
             (0.15, 0.17, 0.07), pink, bevel=0.05)


def _wing_oval(cx, cy, cz, rx, rz, n=12):
    return [
        (
            cx + rx * math.cos((i / n) * math.pi * 2),
            cy,
            cz + rz * math.sin((i / n) * math.pi * 2),
        )
        for i in range(n)
    ]


def build_sprinkle_moth():
    # Donut-moth: fat gummy grub, frosting wings with candy eyespots, club antennae.
    strawberry = g.material("Moth strawberry", (0.9, 0.22, 0.46), 0.3, 0.0, 0.5)
    frosting = g.material("Moth frosting", (1.0, 0.86, 0.9), 0.18, 0.0, 0.74)
    icing = g.material("Moth icing", (1.0, 0.95, 0.8), 0.26, 0.0, 0.55)
    cream = g.material("Moth cream", (0.99, 0.91, 0.78), 0.3, 0.0, 0.48)
    cyan = g.material("Moth cyan sprinkle", (0.08, 0.76, 0.92), 0.2, 0.0, 0.65)
    yellow = g.material("Moth yellow sprinkle", (1.0, 0.68, 0.05), 0.26)
    chocolate = g.material("Moth licorice", (0.1, 0.04, 0.02), 0.4)
    cocoa = g.material("Moth cocoa spot", (0.28, 0.1, 0.05), 0.35, 0.0, 0.4)
    iris = g.material("Moth candy iris", (0.1, 0.48, 0.66), 0.16, clearcoat=0.65)
    ivory = g.material("Moth sugar fang", (0.98, 0.92, 0.78), 0.26, clearcoat=0.3)

    g.uv("Abdomen", (0, 0.05, -0.3), (0.3, 0.24, 0.36), strawberry, 48, 32)
    g.uv("Abdomen tip", (0, 0.06, -0.58), (0.16, 0.14, 0.14), frosting, 32, 20)
    for i, (z, r, mat) in enumerate(((-0.12, 0.27, icing), (-0.3, 0.23, cream), (-0.46, 0.18, icing))):
        g.band_here(f"Icing belt.{i}", z, 0.034, mat, ignore=("Wing", "Leg", "Antenna"))

    g.uv("Thorax", (0, 0.0, 0.14), (0.32, 0.27, 0.26), frosting, 48, 32)
    g.uv("Thorax fuzz", (0, -0.06, 0.14), (0.34, 0.14, 0.2), strawberry, 36, 24)

    g.uv("Head", (0, -0.1, 0.4), (0.3, 0.26, 0.26), cream, 48, 32)
    g.uv("Cheeks", g.seat_front([(0, -0.3, 0.36)], sink=0.004,
                                ignore=g.FRONT_CLUTTER, label="Cheeks")[0], (0.24, 0.07, 0.14), frosting, 32, 20)
    eye_pair("Moth", 0.44, 0.14, 0.095, strawberry, iris, "jewel", -0.32)
    g.curve("Sugar grin", g.seat_front([(-0.12, -0.35, 0.3), (0, -0.38, 0.26), (0.12, -0.35, 0.3)], sink=0.005,
                                       ignore=g.FRONT_CLUTTER, label="Sugar grin"), 0.016, chocolate)
    for side in (-1, 1):
        cone(f"Sugar fang.{side}", (side * 0.06, -0.36, 0.28), (0.018, 0.005), 0.05, ivory, (math.pi * 0.92, 0, 0), 16)

    # Clubs go out to the sides, not through the top of the frame.
    for side in (-1, 1):
        g.capsule(f"Antenna stem.{side}", (side * 0.12, -0.14, 0.56), (side * 0.32, -0.2, 0.6), 0.028, chocolate)
        g.uv(f"Antenna club.{side}", (side * 0.38, -0.22, 0.6), (0.09, 0.05, 0.1), cyan if side < 0 else yellow, 24, 16)

    sprinkle_palette = (cyan, yellow, strawberry, cream, icing)
    for side in (-1, 1):
        g.uv(f"Forewing.{side}", (side * 0.58, 0.04, 0.18), (0.48, 0.038, 0.32), frosting, 40, 28)
        g.curve(f"Forewing icing.{side}", _wing_oval(side * 0.58, 0.02, 0.18, 0.44, 0.28), 0.026, icing, True)
        g.uv(f"Eyespot cocoa.{side}", g.seat_front([(side * 0.62, -0.01, 0.2)], sink=0.004,
                                                   ignore=g.FRONT_CLUTTER, label=f"Eyespot cocoa.{side}")[0], (0.14, 0.03, 0.14), cocoa, 28, 18)
        g.uv(f"Eyespot jewel.{side}", g.seat_front([(side * 0.62, -0.03, 0.2)], sink=0.004,
                                                   ignore=g.FRONT_CLUTTER, label=f"Eyespot jewel.{side}")[0], (0.08, 0.028, 0.08), cyan, 24, 16)
        g.uv(f"Hindwing.{side}", (side * 0.4, 0.03, -0.12), (0.32, 0.034, 0.2), icing, 36, 24)
        g.curve(f"Hindwing icing.{side}", _wing_oval(side * 0.4, 0.01, -0.12, 0.28, 0.16), 0.02, cream, True)
        for i in range(8):
            t = i / 7
            sprinkle(
                f"Wing sprinkle.{side}.{i}",
                (
                    side * (0.34 + t * 0.48),
                    -0.04 - (i % 2) * 0.02,
                    0.36 - t * 0.4 + (i % 3) * 0.03,
                ),
                (1.1, side * (0.3 + i * 0.25), 0.4 + i * 0.35),
                sprinkle_palette[i % 5],
                0.11,
            )

    for side in (-1, 1):
        for i, z in enumerate((0.12, -0.02, -0.2)):
            g.capsule(
                f"Licorice leg.{side}.{i}",
                (side * 0.12, 0.02, z),
                (side * (0.22 + i * 0.03), -0.24, z - 0.22),
                0.024,
                chocolate,
            )
            g.uv(
                f"Candy foot.{side}.{i}",
                (side * (0.24 + i * 0.03), -0.26, z - 0.26),
                (0.05, 0.034, 0.03),
                yellow if i != 1 else cyan,
                16,
                12,
            )


def caramel_bow(shoulders, ribbon, knot):
    z = -0.015
    # The ribbon narrows under the knot and flares toward its rounded ends.
    sections = (
        (0.022, 0.017, 0.019),
        (0.052, 0.022, 0.024),
        (0.092, 0.032, 0.028),
        (0.140, 0.052, 0.031),
        (0.176, 0.063, 0.029),
        (0.189, 0.060, 0.023),
        (0.199, 0.045, 0.015),
        (0.203, 0.024, 0.007),
    )
    around = 32
    for side, name in ((-1, "Bow.left"), (1, "Bow.right")):
        verts = []
        for x, half_height, half_depth in sections:
            for j in range(around):
                angle = j / around * math.tau
                height = math.sin(angle)
                pz = z + 0.06 * x + half_height * height
                py = ellipsoid_front_y(*shoulders, side * x, pz) + 0.003
                # A crease running out from the knot breaks up the front face.
                depth = half_depth * math.cos(angle)
                if depth > 0:
                    depth *= 1 - 0.45 * (1 - x / 0.203) * math.exp(-(height / 0.24) ** 2)
                verts.append((side * x, py - depth, pz))

        faces = [tuple(range(around))]
        for i in range(len(sections) - 1):
            a, b = i * around, (i + 1) * around
            for j in range(around):
                k = (j + 1) % around
                faces.append((a + j, b + j, b + k, a + k))
        faces.append(tuple(range(len(verts) - 1, len(verts) - around - 1, -1)))
        if side < 0:
            faces = [face[::-1] for face in faces]

        mesh = bpy.data.meshes.new(f"{name}.mesh")
        mesh.from_pydata(verts, [], faces)
        mesh.materials.append(ribbon)
        loop = bpy.data.objects.new(name, mesh)
        bpy.context.collection.objects.link(loop)
        g.smooth(loop)

    y = ellipsoid_front_y(*shoulders, 0, z)
    centre = cube("Bow.knot", (0, y - 0.011, z), (0.073, 0.058, 0.085), knot, bevel=0.022)
    centre.modifiers["Edge radius"].segments = 6
    g.smooth(centre)
    centre.modifiers.new("Knot face normals", "WEIGHTED_NORMAL").keep_sharp = True


def build_caramel_bust():
    # Classical bust silhouette with OPEN eyes — tired lids read as closed at thumbnail.
    caramel = g.material("Caramel ceramic", (0.68, 0.28, 0.04), 0.28, 0.0, 0.55)
    light = g.material("Caramel highlight", (0.98, 0.68, 0.35), 0.28, 0.0, 0.6)
    cream = g.material("Caramel cream", (1.0, 0.88, 0.68), 0.4)
    dark = g.material("Caramel feature", (0.16, 0.05, 0.01), 0.5)
    iris = g.material("Caramel iris", (0.45, 0.18, 0.04), 0.18, clearcoat=0.5)
    g.cylinder("Caramel plinth", (0, 0.04, -0.48), 0.4, 0.18, caramel, 48)
    shoulders = ((0, 0.02, -0.12), (0.52, 0.26, 0.28))
    g.uv("Caramel shoulders", *shoulders, caramel, 44, 28)
    g.uv("Neck", (0, 0, 0.12), (0.18, 0.16, 0.14), light, 32, 22)
    head = ((0, -0.02, 0.42), (0.36, 0.3, 0.38))
    g.uv("Sculpted caramel head", *head, light, 48, 32)
    g.uv("Caramel muzzle", (0, -0.3, 0.3), (0.22, 0.1, 0.14), cream, 32, 20)
    g.uv("Nose tip", g.seat_front([(0, -0.38, 0.34)], sink=0.004,
                                  ignore=g.FRONT_CLUTTER, label="Nose tip")[0], (0.06, 0.04, 0.05), caramel, 24, 16)
    eye_pair("Caramel", 0.48, 0.13, 0.09, cream, iris, "jewel", -0.3)
    g.curve("Caramel smile", g.seat_front([(-0.1, -0.34, 0.22), (0, -0.36, 0.2), (0.1, -0.34, 0.22)], sink=0.005,
                                          ignore=g.FRONT_CLUTTER, label="Caramel smile"), 0.012, dark)
    # Caramel flows ON the head. The old equal-radius, uncapped tubes stood
    # clear of the cheeks and read as two rods framing the face. Each closed
    # flattened section now follows the skull across its full width, with its
    # back embedded in the skin. The brow pool narrows into a stream and ends
    # in a rounded drop; neither end has a cut tube opening.
    for side, top, bottom in ((-1, 0.67, 0.265), (1, 0.655, 0.31)):
        along, around = 80, 20

        def drip_section(t):
            z = top + (bottom - top) * t
            x = side * (0.225 + 0.04 * math.sin(math.pi * t) + 0.028 * t)
            pool = math.exp(-((t - 0.14) / 0.13) ** 2)
            fade = math.sqrt(max(0.0, min(1.0, t / 0.07)))
            width = (0.010 + 0.016 * pool
                     + 0.0015 * math.sin(t * math.tau * 1.4)) * fade
            relief = (0.007 + 0.004 * pool) * fade
            if t > 0.82:
                # A rounded lower hemisphere, not a second pointed leaf.
                swell = min(1.0, (t - 0.82) / 0.09)
                swell = swell * swell * (3.0 - 2.0 * swell)
                width = 0.011 + 0.014 * swell
                relief = 0.007 + 0.009 * swell
                if t > 0.91:
                    end_round = math.sqrt(max(0.0, 1.0 - ((t - 0.91) / 0.09) ** 2))
                    width, relief = 0.025 * end_round, 0.016 * end_round
            return x, z, width, relief

        x, z, _, _ = drip_section(0.0)
        verts = [(x, ellipsoid_front_y(*head, x, z) + 0.003, z)]
        for i in range(1, along):
            x, z, width, relief = drip_section(i / along)
            for j in range(around):
                angle = j / around * math.tau
                px = x + width * math.cos(angle)
                py = (ellipsoid_front_y(*head, px, z) + 0.003
                      - relief * math.sin(angle))
                verts.append((px, py, z))
        x, z, _, _ = drip_section(1.0)
        end = len(verts)
        verts.append((x, ellipsoid_front_y(*head, x, z) + 0.003, z))
        faces = []
        for j in range(around):
            k = (j + 1) % around
            faces.append((0, 1 + k, 1 + j))
        for i in range(along - 2):
            a, b = 1 + i * around, 1 + (i + 1) * around
            for j in range(around):
                k = (j + 1) % around
                faces.append((a + j, a + k, b + k, b + j))
        last = 1 + (along - 2) * around
        for j in range(around):
            k = (j + 1) % around
            faces.append((last + j, last + k, end))
        mesh = bpy.data.meshes.new(f"Caramel drip.{side}.mesh")
        mesh.from_pydata(verts, [], faces)
        mesh.materials.append(caramel)
        drip = bpy.data.objects.new(f"Caramel drip.{side}", mesh)
        bpy.context.collection.objects.link(drip)
        g.smooth(drip)
    caramel_bow(shoulders, cream, caramel)


def build_zap_pebble():
    magenta = g.material("Zap Pebble magma", (0.76, 0.035, 0.32), 0.25, 0.05, 0.6)
    pink = g.material("Zap Pebble glow", (1.0, 0.2, 0.55), 0.18, 0.1, 0.72)
    yellow = g.material("Zap Pebble yellow", (1.0, 0.78, 0.06), 0.26, 0.0, 0.6)
    dark = g.material("Zap Pebble cracks", (0.16, 0.012, 0.07), 0.48)
    body_center = (0, 0, 0.05)
    body_scale = (0.4, 0.34, 0.38)
    shards = [
        (body_center, body_scale),
        ((-0.27, 0.01, 0.2), (0.2, 0.2, 0.25)),
        ((0.29, 0.02, 0.14), (0.21, 0.2, 0.28)),
        ((0.02, 0.02, 0.43), (0.24, 0.21, 0.25)),
    ]
    for i, (loc, scale) in enumerate(shards):
        g.uv(f"Pop rock mass.{i}", loc, scale, magenta if i % 2 else pink, 20, 12)
    shard_depth = 0.28
    for i, (x, z) in enumerate(((-0.29, 0.44), (0.31, 0.42), (-0.39, -0.08), (0.38, -0.13), (0.05, 0.68))):
        tilt = (i - 2) * 0.2
        cone(
            f"Anchored sugar shard.{i}",
            (x, 0, z),
            (0.1, 0.012),
            shard_depth,
            yellow,
            (0, tilt, 0),
            18,
        )
        # The old root was always placed straight down in world Z, even when its
        # shard leaned. Its 0.10 depth also exactly matched the cone's 0.10 base,
        # so a near-coplanar yellow crescent leaked through the pink socket when the
        # figurine turned around. Put the socket on the actual tilted base centre,
        # align it with that axis, and give it a genuine lip around the cone.
        axis = (math.sin(tilt), 0, math.cos(tilt))
        root_center = (
            x - axis[0] * shard_depth / 2,
            0,
            z - axis[2] * shard_depth / 2,
        )
        root = g.uv(
            f"Shard root.{i}",
            root_center,
            (0.135, 0.125, 0.09),
            magenta,
            20,
            12,
        )
        root.rotation_euler[1] = tilt
    eye_pair("Zap Pebble", 0.23, 0.15, 0.075, dark, yellow, "spiral", -0.32)
    # This used to be a planar curve at y=-0.36..-0.39. The pebble's actual face at
    # these x/z positions is only y=-0.25..-0.32, leaving up to 13cm of daylight that
    # became obvious as soon as the turntable showed a profile. Conform every control
    # point to the body ellipsoid and leave 8mm proud: enough relief to read, while the
    # 18mm tube remains physically buried in the face from every angle.
    grin_xz = [(-0.18, -0.08), (-0.05, -0.14), (0.08, -0.07), (0.2, -0.12)]
    grin = [
        (x, ellipsoid_front_y(body_center, body_scale, x, z, 0.008), z)
        for x, z in grin_xz
    ]
    g.curve("Explosion grin", grin, 0.018, dark)
    for side in (-1, 1):
        # 34mm of daylight between each foot and the pebble above it.
        g.uv(f"Pop foot.{side}", (side * 0.21, -0.12, -0.35), (0.19, 0.17, 0.09), yellow, 28, 18)


BUILDERS = {
    "mirror-idol": build_mirror_idol,
    "liquid-blade": build_liquid_blade,
    "orb-of-fees": build_orb_of_fees,
    "winged-bolt": build_winged_bolt,
    "piston-saint": build_piston_saint,
    "disk-angel": build_disk_angel,
    "coil-serpent": build_coil_serpent,
    "mask-zero": build_mask_zero,
    "molar-breaker": build_molar_breaker,
    "sour-worm": build_sour_worm,
    "cola-cube": build_cola_cube,
    "frost-imp": build_frost_imp,
    "lollipop-golem": build_lollipop_golem,
    "sprinkle-moth": build_sprinkle_moth,
    "caramel-bust": build_caramel_bust,
    "zap-pebble": build_zap_pebble,
}


if __name__ == "__main__":
    separator = sys.argv.index("--") if "--" in sys.argv else -1
    requested_ids = sys.argv[separator + 1:] if separator >= 0 else []
    unknown_ids = [mascot_id for mascot_id in requested_ids if mascot_id not in BUILDERS]
    if unknown_ids:
        raise SystemExit(f"Unknown mascot ID(s): {', '.join(unknown_ids)}")
    selected_ids = requested_ids or BUILDERS.keys()
    for mascot_id in selected_ids:
        builder = BUILDERS[mascot_id]
        g.reset()
        builder()
        g.export(os.path.join(OUT_DIR, f"{mascot_id}.glb"))
        g.report_unseated()
