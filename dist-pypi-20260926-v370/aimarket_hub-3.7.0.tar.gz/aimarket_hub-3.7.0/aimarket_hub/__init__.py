"""AIMarket Hub v3.7.0 — Federation reference implementation.

Apache-2.0 licensed. Crawls, indexes, searches, and routes AI capabilities
across the AIMarket Protocol network.
"""

__version__ = "3.7.0"
