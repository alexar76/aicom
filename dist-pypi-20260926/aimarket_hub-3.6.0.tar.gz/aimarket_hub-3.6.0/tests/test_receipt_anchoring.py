"""A work receipt issued by the hub ends up provable in HISTOR's receipts log — for real.

Two real systems: this hub with its provenance plugin, and HISTOR's `ReceiptLog` on its own
database. The only thing replaced is the network between them (HTTP is routed into HISTOR's
ASGI app). So a signature format that drifted between the two — the plugin signing different
bytes from the ones HISTOR verifies — fails here, not in production.
"""
from __future__ import annotations

import base64
import hashlib

import pytest

pytest.importorskip("aimarket_provenance")
pytest.importorskip("histor.receipts")

from awr import canonicalize  # noqa: E402

from tests._mandate_kit import ECHO, funded_account, hub, list_static  # noqa: E402


@pytest.fixture
def histor_log(tmp_path):
    from histor.db import open_backend
    from histor.keys import issuer_key
    from histor.migrations import apply_migrations
    from histor.receipts import ReceiptLog
    from histor.store import Store

    backend = open_backend(tmp_path / "histor.sqlite3")
    apply_migrations(backend)
    store = Store(backend)
    key = issuer_key(tmp_path / "histor.key", create=True)
    log = ReceiptLog(store, key, set())
    yield log, key
    backend.close()


def _outbox(client):
    for plugin in client.app_ref.state.plugins.plugins:
        if getattr(plugin, "name", "") == "provenance":
            return plugin, plugin._anchors
    raise AssertionError("provenance plugin not loaded")


def test_an_issued_receipt_is_anchored_and_provable(monkeypatch, tmp_path, histor_log):
    log, histor_key = histor_log
    with hub(monkeypatch, tmp_path, AIMARKET_HISTOR_URL="https://histor.test") as (client, db):
        plugin, outbox = _outbox(client)
        assert outbox is not None and outbox.enabled
        # HISTOR accepts exactly this hub's receipt key, as an operator would configure it.
        log.issuers = frozenset({outbox._key.did})

        class _Resp:
            def __init__(self, status, body):
                self.status_code, self._body, self.text = status, body, str(body)

            def json(self):
                return self._body

        def post(url, payload):
            assert url == "https://histor.test/api/v1/receipts/anchors"
            return _Resp(200, {"results": log.submit(payload["anchors"])})

        outbox._post = post

        list_static(db, price=0.004)
        _, api_key = funded_account(client, db, 1.0)
        r = client.post("/ai-market/v2/invoke", headers={"X-API-Key": api_key}, json=ECHO)
        assert r.status_code == 200, r.text
        receipt = r.json()["provenance_receipt"]
        digest = receipt["digest_sri"]

        pending = client.get(f"/ai-market/v2/p/provenance/anchor/{receipt['receipt_id']}").json()
        assert pending["status"] == "pending"
        assert outbox.flush_once()["anchored"] == 1
        state = client.get(f"/ai-market/v2/p/provenance/anchor/{receipt['receipt_id']}").json()
        assert state["status"] == "anchored" and state["leaf_index"] == 0
        assert state["proof_url"].endswith(digest)

        # The proof, checked as an outsider would: the anchor names this receipt's digest and
        # the hub's key, and it hashes to the leaf the signed head covers.
        proof = log.proof(digest)
        assert proof["anchor"]["receiptDigest"] == digest
        assert proof["anchor"]["issuer"] == outbox._key.did
        from histor import merkle
        from histor.logbook import verify_document
        from histor.receipts import RECEIPT_STH_TYPE

        assert verify_document(proof["sth"], histor_key.did, RECEIPT_STH_TYPE)
        leaf = merkle.leaf_hash(canonicalize(proof["anchor"]))
        assert merkle.verify_inclusion(leaf, proof["leaf_index"], proof["tree_size"],
                                       [bytes.fromhex(h) for h in proof["audit_path"]],
                                       bytes.fromhex(proof["sth"]["rootHash"]))
        # and the receipt document itself really has that digest
        document = client.get(receipt["receipt_url"]).json()
        document = document.get("receipt", document)
        assert "sha256-" + base64.b64encode(hashlib.sha256(canonicalize(document)).digest()).decode() == digest


def test_histor_down_never_touches_an_invoke(monkeypatch, tmp_path):
    with hub(monkeypatch, tmp_path, AIMARKET_HISTOR_URL="https://histor.test") as (client, db):
        _, outbox = _outbox(client)

        def down(url, payload):
            raise ConnectionError("histor unreachable")

        outbox._post = down
        list_static(db, price=0.004)
        _, api_key = funded_account(client, db, 1.0)
        r = client.post("/ai-market/v2/invoke", headers={"X-API-Key": api_key}, json=ECHO)
        assert r.status_code == 200
        counts = outbox.flush_once()
        assert counts["failed"] == 1
        state = outbox.status(r.json()["provenance_receipt"]["digest_sri"])
        assert state["status"] == "pending" and state["attempts"] == 1
        assert "unreachable" in state["last_error"]


def test_anchoring_is_off_without_a_histor_url(monkeypatch, tmp_path):
    monkeypatch.delenv("AIMARKET_HISTOR_URL", raising=False)
    with hub(monkeypatch, tmp_path) as (client, db):
        _, outbox = _outbox(client)
        assert outbox is None
