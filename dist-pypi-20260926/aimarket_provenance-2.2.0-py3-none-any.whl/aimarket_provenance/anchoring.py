"""Anchoring work receipts in HISTOR's receipts log.

A receipt this hub issues is a promise only this hub has signed. Anchoring puts its DIGEST —
never its content — into a public, append-only Merkle log run by someone else (HISTOR, see
``histor/histor/receipts.py``), so that:

* a buyer can later prove the receipt existed at the time it says, to anyone, without trusting
  this hub (an inclusion proof against a head HISTOR signed);
* this hub cannot afterwards deny, backdate or quietly replace a receipt it issued.

What leaves the hub is exactly four facts, signed with the receipts' own key: the receipt's
digest, the issuer's ``did:key``, the issue time, and the anchor type. Not the buyer, the price,
the input or the output.

Delivery is an outbox: issuing a receipt only inserts a row, and a background thread sends
pending rows in batches. HISTOR being down, slow or unreachable therefore never touches an
invoke — the rows wait and the thread retries with backoff. Off unless
``AIMARKET_HISTOR_URL`` is set.
"""
from __future__ import annotations

import base64
import logging
import os
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)

ANCHOR_TYPE = "histor.receipt-anchor/v1"
BATCH = 100
MAX_ATTEMPTS = 50

_OUTBOX_DDL = """
    CREATE TABLE IF NOT EXISTS provenance_anchor_outbox (
        receipt_digest TEXT PRIMARY KEY,
        issued_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        attempts INTEGER NOT NULL DEFAULT 0,
        leaf_index INTEGER,
        last_error TEXT NOT NULL DEFAULT '',
        created_at TEXT DEFAULT (datetime('now')),
        anchored_at TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_anchor_outbox_status ON provenance_anchor_outbox(status, created_at);
"""


def histor_url() -> str:
    return os.environ.get("AIMARKET_HISTOR_URL", "").strip().rstrip("/")


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def sign_anchor(key: Any, *, receipt_digest: str, issued_at: str) -> dict[str, Any]:
    """Byte-for-byte the document HISTOR verifies (histor.logbook.sign_document): Ed25519 by
    the issuer's did:key over the RFC 8785 bytes of every member except ``signature``."""
    from awr import canonicalize

    body = {"type": ANCHOR_TYPE, "issuer": key.did, "receiptDigest": receipt_digest, "issuedAt": issued_at}
    signature = key.sign(canonicalize(body))
    return {**body, "signature": {
        "alg": "Ed25519",
        "verificationMethod": f"{key.did}#{key.did.split(':')[-1]}",
        "value": _b64url(signature),
    }}


class AnchorOutbox:
    def __init__(self, backend: Any, signing_key: Any, *, url: str = "", flush_s: float = 30.0,
                 post: Any = None) -> None:
        self._db = backend
        self._key = signing_key
        self.url = (url or histor_url()).rstrip("/")
        self.flush_s = max(1.0, float(flush_s))
        self._post = post  # injectable for tests; defaults to httpx
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._db.executescript(_OUTBOX_DDL)
        self._db.commit()

    @property
    def enabled(self) -> bool:
        return bool(self.url)

    def enqueue(self, receipt_digest: str, issued_at: str | None = None) -> None:
        if not self.enabled or not receipt_digest:
            return
        stamp = issued_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self._db.execute(
            "INSERT INTO provenance_anchor_outbox (receipt_digest, issued_at) VALUES (?, ?) "
            "ON CONFLICT DO NOTHING",
            (receipt_digest, stamp),
        )
        self._db.commit()

    def status(self, receipt_digest: str) -> dict[str, Any] | None:
        row = self._db.execute(
            "SELECT receipt_digest, status, attempts, leaf_index, last_error, anchored_at "
            "FROM provenance_anchor_outbox WHERE receipt_digest = ?",
            (receipt_digest,),
        ).fetchone()
        if not row:
            return None
        out = {k: row[k] for k in ("receipt_digest", "status", "attempts", "leaf_index", "anchored_at")}
        if row["last_error"]:
            out["last_error"] = row["last_error"]
        if self.url:
            out["log"] = self.url
            if row["status"] == "anchored":
                out["proof_url"] = f"{self.url}/api/v1/receipts/proof?digest={receipt_digest}"
        return out

    def flush_once(self) -> dict[str, int]:
        """Send one batch. Returns counts; never raises."""
        counts = {"sent": 0, "anchored": 0, "refused": 0, "failed": 0}
        if not self.enabled:
            return counts
        rows = self._db.execute(
            "SELECT receipt_digest, issued_at FROM provenance_anchor_outbox "
            "WHERE status = 'pending' AND attempts < ? ORDER BY created_at LIMIT ?",
            (MAX_ATTEMPTS, BATCH),
        ).fetchall()
        if not rows:
            return counts
        anchors = [sign_anchor(self._key, receipt_digest=r["receipt_digest"], issued_at=r["issued_at"]) for r in rows]
        counts["sent"] = len(anchors)
        try:
            post = self._post
            if post is None:
                import httpx

                def post(url: str, payload: dict) -> Any:
                    return httpx.post(url, json=payload, timeout=20.0)
            response = post(f"{self.url}/api/v1/receipts/anchors", {"anchors": anchors})
            if response.status_code != 200:
                raise RuntimeError(f"HISTOR answered {response.status_code}: {str(response.text)[:200]}")
            results = response.json().get("results") or []
        except Exception as exc:  # noqa: BLE001 - a transport failure is a retry, never a crash
            for r in rows:
                self._db.execute(
                    "UPDATE provenance_anchor_outbox SET attempts = attempts + 1, last_error = ? "
                    "WHERE receipt_digest = ? AND status = 'pending'",
                    (str(exc)[:300], r["receipt_digest"]),
                )
            self._db.commit()
            counts["failed"] = len(rows)
            logger.warning("anchoring: HISTOR unreachable, %d receipt(s) wait: %s", len(rows), exc)
            return counts
        for result in results:
            digest = result.get("receipt_digest")
            if result.get("status") in ("logged", "duplicate"):
                self._db.execute(
                    "UPDATE provenance_anchor_outbox SET status = 'anchored', leaf_index = ?, "
                    "anchored_at = datetime('now'), last_error = '' WHERE receipt_digest = ?",
                    (result.get("leaf_index"), digest),
                )
                counts["anchored"] += 1
            else:
                # A refusal is a verdict about this anchor, not a transient fault: retrying the
                # same signed bytes cannot change it. Kept visible, not retried.
                self._db.execute(
                    "UPDATE provenance_anchor_outbox SET status = 'refused', last_error = ? "
                    "WHERE receipt_digest = ?",
                    (str(result.get("reason") or "refused")[:300], digest),
                )
                counts["refused"] += 1
        self._db.commit()
        return counts

    # -- the background sender -------------------------------------------------------

    def start(self) -> None:
        if not self.enabled or self._thread is not None:
            return
        self._thread = threading.Thread(target=self._run, name="provenance-anchor-outbox", daemon=True)
        self._thread.start()
        logger.info("anchoring receipts to %s every %.0fs", self.url, self.flush_s)

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        delay = self.flush_s
        while not self._stop.wait(delay):
            try:
                counts = self.flush_once()
            except Exception as exc:  # noqa: BLE001
                logger.error("anchoring: flush raised: %s", exc)
                counts = {"failed": 1, "sent": 0}
            # Back off while HISTOR is failing, return to the normal pace once it answers.
            delay = min(delay * 2, 600.0) if counts.get("failed") else self.flush_s
