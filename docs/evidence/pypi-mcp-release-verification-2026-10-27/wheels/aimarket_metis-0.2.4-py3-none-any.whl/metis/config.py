"""Configuration for metis."""

from __future__ import annotations

from metis.env_compat import migrate_legacy_env

migrate_legacy_env()

from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from metis.economy.config import EconomyConfig
from metis.knowledge.config import KnowledgeConfig
from metis.mcp.config import MCPServerConfig
from metis.observability.config import ObservabilityConfig
from metis.security.ratelimit import RateLimitConfig


DEFAULT_REQUEST_TIMEOUT_SECONDS = 600.0


class ProviderKind(str, Enum):
    OPENAI_COMPAT = "openai_compat"
    OLLAMA = "ollama"
    ANTHROPIC = "anthropic"
    MOCK = "mock"  # test-only — blocked unless allow_test_provider=true


class ModelSlot(BaseModel):
    name: str
    provider: ProviderKind = ProviderKind.OPENAI_COMPAT
    model: str
    base_url: str = "http://localhost:11434/v1"
    api_key: str = "ollama"
    temperature: float = 0.7
    max_tokens: int = 4096
    node_id: Optional[str] = None
    supports_vision: Optional[bool] = None  # None → auto-detect from model name
    extra_headers: dict = {}  # extra HTTP headers (e.g. OpenRouter HTTP-Referer / X-Title)
    #: Leave `temperature` out of the request entirely. Some reasoning models refuse the
    #: parameter (OpenRouter's model list does not advertise `temperature` for
    #: openai/gpt-6-sol or anthropic/claude-sonnet-5), and a juror whose every call 400s
    #: is a juror that silently abstains on every verdict.
    omit_temperature: bool = False
    #: Extra fields merged into the request body (e.g. OpenRouter's
    #: `reasoning: {"effort": "medium"}`). Never overrides model or messages.
    extra_body: dict = {}


class JurorSlot(BaseModel):
    """One seat on the /v1/verify jury (see metis/verify/jury.py).

    A juror is an explicit, operator-chosen model: it is never capability-gated (the gate
    would promote every seat to the strongest model and collapse the vendor diversity
    that is the whole point of a jury), never given the operator identity block (jurors
    answer in strict JSON), and its key comes from the environment like a module seat's.
    """

    model: str
    provider: ProviderKind = ProviderKind.OPENAI_COMPAT
    base_url: Optional[str] = None      # None → the runtime's base_url
    api_key_env: Optional[str] = None
    api_key: Optional[str] = None
    #: Who made the model, when the id itself does not say (an unprefixed id such as
    #: `deepseek-v4-pro` on a vendor's own endpoint is inferred from its family name).
    vendor: Optional[str] = None
    temperature: Optional[float] = None  # None → RuntimeConfig.jury_temperature
    omit_temperature: bool = False
    #: Merged into every request this juror sends — e.g. turn reasoning ON for a
    #: model that only thinks when asked. A juror checking arithmetic without
    #: thinking accepted wrong answers (docs/jury-3-vs-5.md).
    extra_body: Optional[dict] = None
    max_tokens: Optional[int] = None
    extra_headers: Optional[dict] = None


class ModuleSlotConfig(BaseModel):
    """Per-brain-module LLM endpoint configuration."""

    provider: Optional[ProviderKind] = None
    model: Optional[str] = None
    base_url: Optional[str] = None
    api_key_env: Optional[str] = None
    api_key: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    node_id: Optional[str] = None
    supports_vision: Optional[bool] = None
    extra_headers: Optional[dict] = None


class RouteMode(str, Enum):
    FAST = "fast"
    THINKING = "thinking"
    AGENT = "agent"
    COUNCIL = "council"


class DGPDConfig(BaseModel):
    """Disagreement-Gated Pipeline Depth — skip expensive layers on agreement."""

    enabled: bool = True
    agreement_threshold: float = 0.85
    force_full_depth_keywords: List[str] = Field(
        default_factory=lambda: [
            "delete",
            "execute",
            "password",
            "api key",
            "secret",
            "production",
            "deploy",
        ]
    )


class SecurityConfig(BaseModel):
    max_user_input_chars: int = 100_000
    max_tool_output_chars: int = 50_000
    max_request_body_bytes: int = 512_000
    request_timeout_seconds: float = Field(
        default=DEFAULT_REQUEST_TIMEOUT_SECONDS,
        ge=10.0,
        le=DEFAULT_REQUEST_TIMEOUT_SECONDS,
    )
    enforce_injection_scan: bool = True
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)
    cors_origins: List[str] = Field(default_factory=list)
    mtls_cert_path: Optional[str] = None
    mtls_key_path: Optional[str] = None
    mtls_ca_path: Optional[str] = None


class RuntimeConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="METIS_", env_file=".env", extra="ignore")

    production: bool = False
    allow_test_provider: bool = False

    base_model: str = "qwen3:8b"
    base_url: str = "http://localhost:11434/v1"
    api_key: str = "ollama"
    #: Read the base slot's key from the environment instead of writing it into the config.
    #:
    #: Per-MODULE slots have always had `api_key_env`; the top level did not, so a deployment
    #: that wrote it here got a silently ignored line and fell back to `api_key` — which
    #: defaults to the literal "ollama". A live prod.yaml carried BOTH: an ignored
    #: `api_key_env: OPENROUTER_API_KEY` and a pasted DeepSeek key pointed at openrouter.ai.
    #: Every module that fell through to the base slot answered 401, while modules with their
    #: own `api_key_env` worked — so /health was green and every completion failed.
    api_key_env: Optional[str] = None
    provider: ProviderKind = ProviderKind.OLLAMA

    default_route: RouteMode = RouteMode.COUNCIL
    thinking_samples: int = 3
    thinking_temperature: float = 0.8
    max_agent_iterations: int = 5
    max_verify_retries: int = 3
    #: Wall-clock cap on a single council member's generation, in seconds.
    #:
    #: Layer 1 runs its proposers concurrently, so the layer costs whatever its SLOWEST
    #: member costs. One skeptic once took 400s while the logician and the pragmatist
    #: finished in 33s — the layer billed 400s of the caller's budget for a proposal that
    #: was not better for having taken twelve times longer. Past this cap the straggler is
    #: dropped and the layer proceeds on whoever answered.
    role_timeout_seconds: float = 150.0
    #: Wall-clock budget for a whole council run, in seconds. None = no budget (run to
    #: completion), which is only safe when the caller waits forever.
    #:
    #: The council retries up to `max_verify_retries` times. Without a budget it starts a
    #: round it cannot finish and the caller's deadline kills it mid-round — so a run that
    #: HAD an aggregated answer at minute 14 handed back nothing at minute 20. With a budget
    #: it stops starting rounds it cannot finish and returns its best answer so far, marked
    #: unverified. Set this BELOW the caller's timeout, not equal to it.
    council_budget_seconds: Optional[float] = None
    enable_grounded_verify: bool = True  # execute answer code to ground verify_score
    enable_multimodal: bool = True       # pass images to a vision-capable slot when present
    max_images: int = 5                  # hard cap on images accepted per request
    vision_timeout_seconds: float = 30.0  # hard cap on the perception call (fail over to text)
    vision_retries: int = 3               # retries within the budget (free vision endpoints are flaky)
    identity: str = ""                    # operator self-knowledge prepended to EVERY system prompt
    #                                       (who Metis is, its ecosystem, services, tools). "" → standalone,
    #                                       no injection. Set via METIS_IDENTITY env or the `identity:` YAML key.
    confidence_threshold: float = 0.7
    confidence_hard_floor: float = 0.35
    enforce_confidence_gate: bool = True

    council_models: List[ModelSlot] = Field(default_factory=list)
    modules: Dict[str, ModuleSlotConfig] = Field(default_factory=dict)
    enforce_heterogeneous_agents: bool = False
    min_unique_council_models: int = 2
    #: Distinct VENDORS (the prefix of `vendor/model`, or the family of an unprefixed id)
    #: the council and the MoA seats must span. Counting (model, endpoint) pairs alone let
    #: three sizes of one lineage pass as a diverse council. 1 = no vendor requirement.
    min_unique_council_vendors: int = 1

    # Capability gate — keep a randomly-plugged-in weak model from dragging the council down.
    # High-leverage roles (aggregator/verifier/synthesizer) go to the strongest configured
    # model; models below the floor lose their vote as proposers. No-op for single-model
    # setups. See metis/agents/capability.py and docs/benchmarks/.
    enforce_capability_gate: bool = True
    council_capability_floor: float = 60.0     # below this a model can't be a proposer/parser
    min_aggregator_capability: float = 75.0    # advisory: warn if the strongest is still below this
    capability_file: Path = Path("data/capability.json")  # measured scores from `metis calibrate`
    #: Seat the judge on a different vendor than the models that WRITE the answer it
    #: audits (the base model on fast/thinking, the MoA aggregator on the council). The
    #: gate used to promote the judge and the aggregator to the same strongest model, so on
    #: the council route one model wrote the Pay-on-Verified verdict and then audited it.
    judge_distinct_vendor: bool = True

    # Jury — /v1/verify as a vote across vendors (metis/verify/jury.py). Empty roster = off.
    jury_models: List[JurorSlot] = Field(default_factory=list)
    #: Every juror must come from a different vendor, and there must be at least this many.
    jury_min_vendors: int = Field(default=3, ge=2)
    #: Route EVERY /v1/verify request through the jury when a roster is configured, whatever
    #: `route` the caller sent (the hub sends fast/council by price). Off: only an explicit
    #: `route: "jury"` convenes it.
    jury_default_for_verify: bool = False
    jury_temperature: float = Field(default=0.1, ge=0.0, le=2.0)
    #: Wall-clock cap per juror. A juror that misses it abstains; it does not hold the jury.
    jury_timeout_seconds: float = Field(default=120.0, gt=0.0)

    memory_dir: Path = Path("data/memory")
    enable_long_term_memory: bool = True
    rag_top_k: int = 5

    enable_code_interpreter: bool = False
    enable_web_search: bool = True
    web_search_url: str = "https://html.duckduckgo.com/html/"
    code_timeout_seconds: int = 10
    sandbox_use_subprocess: bool = True

    enable_mcp_tools: bool = False
    mcp_servers: List[MCPServerConfig] = Field(default_factory=list)
    mcp_ecosystem_presets: List[str] = Field(default_factory=list)
    enable_ecosystem_invoke: bool = False  # let the agent pay-per-call AIMarket hub capabilities

    dgpd: DGPDConfig = Field(default_factory=DGPDConfig)
    economy: EconomyConfig = Field(default_factory=EconomyConfig)
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)
    knowledge: KnowledgeConfig = Field(default_factory=KnowledgeConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)

    escalate_model: Optional[str] = None
    escalate_url: Optional[str] = None

    distributed: bool = False
    cluster_config: Optional[Path] = None

    def model_post_init(self, __context: Any) -> None:
        from metis.security.ssrf import validate_url
        self.web_search_url = validate_url(self.web_search_url)
        if self.production and not self.api_key_env_set():
            pass  # api_key from env in production via METIS_API_KEY

    @model_validator(mode="after")
    def _jury_roster_is_a_jury(self) -> "RuntimeConfig":
        """Refuse to start with a roster that is not a jury.

        Two seats from one vendor are that vendor voting twice, and a roster below the
        vendor minimum cannot produce the independence a verdict is sold on. Both are
        configuration errors, and a verifier that moves money must fail at startup rather
        than serve verdicts that look like a vote and are not one.
        """
        if self.jury_models:
            from metis.verify.jury import roster_problems

            problems = roster_problems(self.jury_models, self.jury_min_vendors)
            if problems:
                raise ValueError("jury_models: " + "; ".join(problems))
        return self

    def resolved_api_key(self) -> str:
        """The base slot's key: the environment first, the literal only as a fallback.

        A key in a config file is a key in a backup, a bind mount and a git history. The env
        wins so a deployment never has to paste one — and when `api_key_env` names a variable
        that is empty, that is said out loud rather than silently becoming "ollama".
        """
        import logging
        import os

        if self.api_key_env:
            value = os.environ.get(self.api_key_env, "").strip()
            if value:
                return value
            logging.getLogger(__name__).error(
                "api_key_env names %s but it is empty — falling back to the literal api_key, "
                "which defaults to 'ollama' and will be refused by any real provider",
                self.api_key_env)
        return self.api_key

    def api_key_env_set(self) -> bool:
        import os
        return bool(
            os.environ.get("METIS_API_KEY")
            or os.environ.get("SUPERBRAIN_API_KEY")
            or os.environ.get("COGNITIVE_API_KEY")
        )

    @classmethod
    def from_yaml(cls, path: str | Path) -> RuntimeConfig:
        with open(path) as f:
            data: dict[str, Any] = yaml.safe_load(f) or {}
        dgpd = data.get("dgpd", {})
        if "enable_dgpd" in data:
            dgpd.setdefault("enabled", data.pop("enable_dgpd"))
        if "dgpd_agreement_threshold" in data:
            dgpd.setdefault("agreement_threshold", data.pop("dgpd_agreement_threshold"))
        if dgpd:
            data["dgpd"] = dgpd
        reliability = data.get("reliability")
        if reliability:
            data.setdefault("observability", {})["reliability"] = reliability
            data.pop("reliability", None)
        return cls(**data)

    def resolved_mcp_servers(self) -> List[MCPServerConfig]:
        from metis.mcp.discovery import ecosystem_presets
        servers = list(self.mcp_servers)
        if self.mcp_ecosystem_presets:
            servers.extend(ecosystem_presets([p for p in self.mcp_ecosystem_presets if p]))
        return servers

    def resolved_council_models(self) -> List[ModelSlot]:
        """Resolve council slots; enforce >=min_unique_council_models (Yang et al. 2026)."""
        from metis.agents.diversity import check_council_diversity, diversify_temperatures
        from metis.modules.registry import COUNCIL_ROLES, ModuleRegistry

        registry = ModuleRegistry(self)
        if self.modules or self.council_models:
            slots = [registry.resolve_slot(role) for role in COUNCIL_ROLES]
        else:
            slots = [
                ModelSlot(name="parser_a", provider=self.provider, model=self.base_model, base_url=self.base_url, api_key=self.resolved_api_key(), temperature=0.5),
                ModelSlot(name="parser_b", provider=self.provider, model=self.base_model, base_url=self.base_url, api_key=self.resolved_api_key(), temperature=0.7),
                ModelSlot(name="parser_c", provider=self.provider, model=self.base_model, base_url=self.base_url, api_key=self.resolved_api_key(), temperature=0.9),
                ModelSlot(name="red_team", provider=self.provider, model=self.base_model, base_url=self.base_url, api_key=self.resolved_api_key(), temperature=0.6),
                ModelSlot(name="synthesizer", provider=self.provider, model=self.base_model, base_url=self.base_url, api_key=self.resolved_api_key(), temperature=0.3),
            ]
        check_council_diversity(
            slots, enforce=self.enforce_heterogeneous_agents,
            min_unique_models=self.min_unique_council_models,
            min_unique_vendors=self.min_unique_council_vendors,
        )
        if not self.enforce_heterogeneous_agents:
            slots = diversify_temperatures(slots)
        return slots

    def base_slot(self) -> ModelSlot:
        return ModelSlot(name="base", provider=self.provider, model=self.base_model,
                         base_url=self.base_url, api_key=self.resolved_api_key())
