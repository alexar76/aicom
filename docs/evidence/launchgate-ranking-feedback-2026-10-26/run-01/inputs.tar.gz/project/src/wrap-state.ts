import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { FilePinStore, pinRevision } from './pin-store.js';
import { readState, writeState, withStateLock } from './state.js';
import { Warden, pinToolsHash, serverIdentityHash, displaySafe } from './index.js';
import type { McpServerRef, ToolDef, WardenPolicy, WardenVerdict } from './types.js';
import type { ThreatFeed } from './threat-feed.js';
import { diffToolDefinitions, formatDefinitionDiff, formatOriginLines, launchSpec, plainVersion } from './review-diff.js';

export interface Observation {
  server: McpServerRef;
  /** Absent when vetLaunch refused to start the new command. */
  tools?: ToolDef[];
  policy: WardenPolicy;
  revoked?: boolean;
  /** serverInfo from the initialize result, when the proxy recorded it: shown in a review, never trusted. */
  serverInfo?: { name?: string; version?: string };
}

/** A bounded copy of the child's self-reported metadata, never an installed-artifact identity. */
export function observedServerInfo(value: unknown): Observation['serverInfo'] {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const raw = value as Record<string, unknown>, out: NonNullable<Observation['serverInfo']> = {};
  for (const key of ['name', 'version'] as const) {
    const text = raw[key];
    // In Unicode mode this matches only unpaired UTF-16 surrogates, not valid non-BMP code points.
    // Optional metadata must not poison the full-pin RFC 8785 revision used by review CAS.
    if (typeof text === 'string' && text.length <= 200 && !/[\uD800-\uDFFF]/u.test(text)) out[key] = text;
  }
  return Object.keys(out).length ? out : undefined;
}
/** A refusal WARDEN decided, as opposed to a check that could not run (timeout, lock, child error). */
export class WardenBlock extends Error {}

export function observationPath(dir: string, id: string): string {
  return join(dir, 'wrap', createHash('sha256').update(id).digest('hex') + '.json');
}
export function observationRevision(value: Observation | undefined): string {
  return createHash('sha256').update(JSON.stringify(value) ?? 'null').digest('hex');
}
export async function observe(dir: string, value: Observation): Promise<void> {
  const path = observationPath(dir, value.server.id);
  await withStateLock(path, async () => {
    const previous = await readState<Observation>(path);
    const tools = value.tools ?? (previous?.revoked && serverIdentityHash(previous.server) === serverIdentityHash(value.server) ? previous.tools : undefined);
    await writeState(path, { ...value, tools, revoked: previous?.revoked });
  });
}

/** One lock spans TOFU's read/vet/approve, as well as human review's final CAS. */
export async function vetAndPin(dir: string, server: McpServerRef, tools: ToolDef[], policy: WardenPolicy,
  store: FilePinStore, warden: Warden, feed: ThreatFeed, auditOnly: boolean, isCurrent: () => boolean, record: (v: WardenVerdict) => void,
  serverInfo?: Observation['serverInfo']): Promise<WardenVerdict> {
  const path = observationPath(dir, server.id);
  return withStateLock(path, async () => {
    const previous = await readState<Observation>(path);
    await writeState(path, { server, tools, policy, revoked: previous?.revoked, ...(serverInfo ? { serverInfo } : {}) });
    const verdict = await warden.vet(server, tools);
    record(verdict);
    if (!auditOnly && !isCurrent()) throw new WardenBlock('tools changed, blocked by WARDEN during verification');
    if (previous?.revoked && !auditOnly) throw new WardenBlock('Approval revoked; inspect pins status and approve before reconnecting');
    if (!auditOnly && !policy.requireApproval && verdict.allow && policy.pinToolDefs && !previous?.revoked && !await store.getPin(server.id)) {
      // Use the published approve API with a CAS adapter: other hosts may share this store.
      const firstContact = Warden.create({ policy, threatFeed: feed,
        store: { getPin: id => store.getPin(id),
          putPin: pin => store.replace(server.id, null, { ...pin, ...(serverInfo ? { serverInfo } : {}) }) } });
      await firstContact.approve(server, tools, 'automatic');
    }
    return verdict;
  });
}

export function describeReview(previous: Awaited<ReturnType<FilePinStore['getPin']>>, current: Observation | undefined): string {
  const oldTools = previous?.tools ?? [];
  const newTools = current?.tools ?? oldTools;
  const lines = [`Previous identity: ${previous?.identityHash ?? '(none)'}`,
    `Observed identity: ${current ? serverIdentityHash(current.server) : '(none)'}`,
    `Launch: ${current ? JSON.stringify(current.server) : '(none)'}`];
  if (current && !current.tools) lines.push('Launch was blocked; tool definitions below are the PREVIOUS snapshot, not fetched from the new command.');
  // Where a change came from: the version the server reports and whether the launch command pins one.
  lines.push(...formatOriginLines(current ? launchSpec(current.server) : undefined, plainVersion(previous?.serverInfo?.version),
    plainVersion(current?.serverInfo?.version), !!previous && !!current?.tools && previous.toolsHash !== pinToolsHash(newTools)));
  // What changed, field by field, first; the full definitions follow for the record.
  lines.push(...formatDefinitionDiff(diffToolDefinitions(oldTools, newTools)));
  if (JSON.stringify(oldTools) !== JSON.stringify(newTools)) lines.push('Full definitions of the tools that differ:');
  for (const name of new Set([...oldTools, ...newTools].map(t => t.name))) {
    const old = oldTools.find(t => t.name === name), next = newTools.find(t => t.name === name);
    if (JSON.stringify(old) !== JSON.stringify(next)) {
      if (old) lines.push('- ' + JSON.stringify(old));
      if (next) lines.push('+ ' + JSON.stringify(next));
    }
  }
  lines.push(`Previous tools: ${previous?.toolsHash ?? '(none)'}`, `Observed tools: ${pinToolsHash(newTools)}`,
    `Revoked: ${current?.revoked === true}`);
  return lines.map(line => displaySafe(line, 2_000_000)).join('\n');
}
export { pinRevision };
