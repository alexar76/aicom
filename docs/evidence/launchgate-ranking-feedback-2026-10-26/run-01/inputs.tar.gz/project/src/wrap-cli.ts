import { readFile } from 'node:fs/promises';
import { RESULT_POLICIES, type ResultPolicy } from './result-screen.js';
import { createHash, createPublicKey } from 'node:crypto';
import { createInterface } from 'node:readline/promises';
import { join } from 'node:path';
import { asPolicy } from './mcp-tools.js';
import { defaultStateDir, readState, withStateLock, writeState } from './state.js';
import { FilePinStore, pinRevision } from './pin-store.js';
import { Warden, ThreatFeed, pinToolsHash, serverIdentityHash, displaySafe } from './index.js';
import { observationPath, observationRevision, describeReview } from './wrap-state.js';
import type { Observation } from './wrap-state.js';
import type { McpServerRef, WardenLogger, WardenPolicy } from './types.js';
import { parseJsonStrict } from './jcs.js';
import { screenObservation } from './flow-guard.js';

export interface WrapOptions {
  mode: 'wrap' | 'pins'; action?: string; id?: string; command?: string; args: string[];
  stateDir: string; policy: WardenPolicy; feed?: string; feedKey?: string; verdictLog?: string; auditOnly: boolean;
  /** What happens to a tool result whose text reads as instructions to the model (result-screen.ts). */
  results: ResultPolicy;
  /** The server's name for the flow guard (`--flow NAME`): its calls are `mcp__NAME__tool` to the guard's
   *  policy, and every call and result goes through the same guard the Claude Code plugin runs. */
  flow?: string;
  /** Explicit same-server observation used before/after GUI approval; unsupported snapshots refuse execution. */
  screenRead?: string;
  screenReadInput?: Record<string, unknown>;
  /** Require the trusted server's one-use revision/target CAS; never fall back to a raw GUI call. */
  screenAtomic?: boolean;
  /** A call that needs a person's yes — a tool matching `policy.sensitiveToolPatterns`, or a send the flow guard asks
   *  about: `elicit` asks through the client's own form (MCP elicitation) when the client offers one and refuses
   *  otherwise; `refuse` always refuses it. */
  ask: AskPolicy;
}
export const ASK_POLICIES = ['elicit', 'refuse'] as const;
export type AskPolicy = typeof ASK_POLICIES[number];
export async function parseWrapArgs(argv: string[]): Promise<WrapOptions> {
  const mode = argv.shift();
  if (mode !== 'wrap' && mode !== 'pins') throw new Error('Usage: warden-mcp wrap [--flow NAME] [flags] -- command [args] | pins status|approve|revoke --id ID');
  const opts: WrapOptions = { mode, args: [], stateDir: defaultStateDir(), policy: asPolicy(undefined), auditOnly: false, results: 'warn', ask: 'elicit' };
  if (mode === 'pins') {
    opts.action = argv.shift();
    if (!['status', 'approve', 'revoke'].includes(opts.action ?? '')) throw new Error('pins requires status, approve or revoke');
  }
  const seen = new Set<string>();
  while (argv.length) {
    const flag = argv.shift()!;
    if (flag === '--' && mode === 'wrap') { opts.command = argv.shift(); opts.args = argv; break; }
    if (seen.has(flag)) throw new Error(`Duplicate flag ${flag}`);
    seen.add(flag);
    if (flag === '--audit-only' && mode === 'wrap') { opts.auditOnly = true; continue; }
    if (flag === '--screen-atomic' && mode === 'wrap') { opts.screenAtomic = true; continue; }
    if (flag === '--require-approval' && mode === 'wrap') { continue; }
    const allowed = mode === 'wrap' ? ['--id', '--state-dir', '--policy', '--feed', '--feed-key', '--verdict-log', '--results', '--flow', '--ask', '--screen-read', '--screen-read-input'] : ['--id', '--state-dir', '--feed', '--feed-key'];
    if (!allowed.includes(flag)) throw new Error(`Unknown flag ${flag}`);
    const value = argv.shift();
    if (!value || value.startsWith('--')) throw new Error(`Missing value for ${flag}`);
    switch (flag) {
      case '--id':
        if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(value)) throw new Error('--id must be a slug (1–128 letters, digits, ., _ or -)');
        opts.id = value; break;
      case '--state-dir': opts.stateDir = value; break;
      case '--feed': opts.feed = value; break;
      case '--feed-key': opts.feedKey = value; break;
      case '--verdict-log': opts.verdictLog = value; break;
      case '--flow':
        // The name joins `mcp__NAME__tool`: a slug with no double underscore, so the tool part stays unambiguous.
        if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(value) || value.includes('__')) throw new Error('--flow must be a server name (letters, digits, ., _ or -, no "__")');
        opts.flow = value; break;
      case '--screen-read':
        if (!/^[A-Za-z][A-Za-z0-9_.-]{0,99}$/.test(value)) throw new Error('--screen-read requires one exact observation tool');
        opts.screenRead = value; break;
      case '--screen-read-input': {
        if (value.length > 1024) throw new Error('--screen-read-input is too large');
        const input = parseJsonStrict(value);
        if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('--screen-read-input must be an object');
        opts.screenReadInput = input as Record<string, unknown>; break;
      }
      case '--ask':
        if (!(ASK_POLICIES as readonly string[]).includes(value)) throw new Error('--ask must be elicit or refuse');
        opts.ask = value as AskPolicy; break;
      case '--results':
        if (!(RESULT_POLICIES as readonly string[]).includes(value)) throw new Error('--results must be off, warn or block');
        opts.results = value as ResultPolicy; break;
      case '--policy': {
        const raw = JSON.parse(await readFile(value, 'utf8'));
        // asPolicy preserves compatibility for MCP callers; CLI files must not silently repair bad types.
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('policy must be an object');
        for (const key of Object.keys(raw)) if (!['blockAtSeverity', 'pinToolDefs', 'allowUnknownServers', 'sensitiveToolPatterns', 'requireApproval', 'capabilityBindings'].includes(key)) throw new Error(`Unknown policy field ${key}`);
        for (const key of ['pinToolDefs', 'allowUnknownServers', 'requireApproval']) if (key in raw && typeof raw[key] !== 'boolean') throw new Error(`policy.${key} must be boolean`);
        if ('blockAtSeverity' in raw && typeof raw.blockAtSeverity !== 'string') throw new Error('policy.blockAtSeverity must be a severity');
        if ('sensitiveToolPatterns' in raw && (!Array.isArray(raw.sensitiveToolPatterns) || !raw.sensitiveToolPatterns.every((v: unknown) => typeof v === 'string'))) throw new Error('policy.sensitiveToolPatterns must be strings');
        opts.policy = asPolicy(raw); break;
      }
    }
  }
  if (mode === 'wrap' && !opts.command) throw new Error('wrap requires -- command [args]');
  if (opts.screenReadInput && !opts.screenRead) throw new Error('--screen-read-input requires --screen-read');
  if (opts.screenRead && (!opts.flow || !screenObservation(`mcp__${opts.flow}__${opts.screenRead}`, opts.screenReadInput ?? {}))) throw new Error('--screen-read requires --flow and a supported observation schema (empty input, or a generic controller with only a read action)');
  if (opts.screenAtomic && (!opts.screenRead || opts.auditOnly)) throw new Error('--screen-atomic requires --flow and --screen-read in enforcing mode');
  if (seen.has('--require-approval')) opts.policy.requireApproval = true;
  if (mode === 'pins' && !opts.id) throw new Error('pins requires --id');
  if (opts.feed) {
    const url = new URL(opts.feed);
    if (!['https:', 'http:'].includes(url.protocol)) throw new Error('--feed requires an HTTP(S) URL');
  }
  if (opts.feedKey) {
    if (!/^(?:[a-fA-F0-9]{2})+$/.test(opts.feedKey) || createPublicKey({ key: Buffer.from(opts.feedKey, 'hex'), format: 'der', type: 'spki' }).asymmetricKeyType !== 'ed25519') throw new Error('--feed-key must be an Ed25519 SPKI DER hex key');
  }
  return opts;
}
export function wrapServer(opts: WrapOptions): McpServerRef {
  const id = opts.id ?? createHash('sha256').update(JSON.stringify([opts.command, opts.args])).digest('hex');
  return { id, name: id, transport: 'stdio', command: opts.command!, args: opts.args };
}
export function wrapLogger(auditOnly = false): WardenLogger {
  const write = (message: string) => process.stderr.write(`warden: ${auditOnly ? 'AUDIT-ONLY ' : ''}${displaySafe(message, 8192)}\n`);
  const logger: WardenLogger = { debug: () => {}, info: () => {}, warn: write, error: write, child: () => logger };
  return logger;
}
export async function loadWrapFeed(opts: WrapOptions): Promise<ThreatFeed> {
  const log = wrapLogger(opts.auditOnly);
  const feed = new ThreatFeed({ feedPublicKey: opts.feedKey, stateDir: opts.stateDir, log });
  await feed.load(opts.feed);
  if (opts.feed && feed.status.stale) log.warn('Remote feed unavailable or stale; using retained records and built-in floor');
  return feed;
}
export async function runPins(opts: WrapOptions): Promise<void> {
  if (!process.stdin.isTTY) throw new Error('pins requires a human terminal (TTY on stdin); refusing non-interactive review');
  const id = opts.id!, path = observationPath(opts.stateDir, id), store = new FilePinStore(join(opts.stateDir, 'pins'));
  const { previous, current } = await withStateLock(path, async () => ({ previous: await store.getPin(id), current: await readState<Observation>(path) }));
  process.stdout.write(describeReview(previous, current) + '\n');
  if (opts.action === 'status') return;
  if (opts.action === 'approve' && !current) throw new Error('No observed definitions; run wrap first');
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  let answer: string;
  try { answer = await rl.question(`Type ${opts.action} ${id} to confirm: `); }
  finally { rl.close(); }
  if (answer !== `${opts.action} ${id}`) throw new Error('Not confirmed; pin unchanged');
  const feed = await loadWrapFeed(opts);
  await withStateLock(path, async () => {
    if (observationRevision(await readState<Observation>(path)) !== observationRevision(current)) throw new Error('Observed definitions changed since review; inspect status again');
    if (opts.action === 'revoke') {
      // Persist denial before deleting the pin, so a crash cannot accidentally enable TOFU.
      // A pin taken without a wrap observation (approve_mcp_server, another host) gets a
      // minimal one: without it the next wrap would see no denial and re-pin on first contact.
      await writeState(path, current ? { ...current, revoked: true }
        : { server: { id, name: id, transport: 'stdio' }, policy: opts.policy, revoked: true } satisfies Observation);
      await store.replace(id, pinRevision(previous));
    } else {
      const tools = current!.tools ?? previous?.tools;
      if (!tools) throw new Error('No reviewed tool snapshot available');
      const policy = asPolicy(current!.policy);
      // Re-approval removes only pin drift; the other gates still have to pass.
      const warden = Warden.create({ policy: { ...policy, requireApproval: false }, threatFeed: feed, store: { getPin: async () => undefined, putPin: async () => {} } });
      const verdict = await warden.vet(current!.server, tools);
      if (!verdict.allow) throw new Error(`Approval blocked: ${verdict.findings.map(f => f.code).join(', ')}`);
      await store.replace(id, pinRevision(previous), { serverId: id, tools, toolsHash: pinToolsHash(tools), toolsHashVersion: 2,
        identityHash: serverIdentityHash(current!.server), toolNames: tools.map(t => t.name).sort(), approvedAt: new Date().toISOString(), approvalMode: 'operator',
        ...(current!.serverInfo ? { serverInfo: current!.serverInfo } : {}) });
      await writeState(path, { ...current, revoked: false });
    }
  });
  process.stdout.write(`${opts.action}: ${displaySafe(id)}\n`);
}
