// ─────────────────────────────────────────────────────────────────────────────
// WARDEN — the MCP security firewall: protocol types
//
// Everything a host needs to talk to WARDEN lives in this file, and nothing
// here depends on a particular agent. Two of these interfaces are host-supplied
// seams rather than data — `PinStore` (where approvals are remembered) and
// `WardenLogger` (where findings are written) — deliberately narrowed to what
// the gates actually call, so a host can satisfy them with a Map and a no-op.
// ─────────────────────────────────────────────────────────────────────────────

export type JSONSchema = Record<string, unknown>;

/** An MCP tool as its server advertises it — the primary attack surface. */
export interface ToolDef {
  /** Preserve extension fields from tools/list; they are untrusted and pinned too. */
  [field: string]: unknown;
  title?: string;
  outputSchema?: JSONSchema;
  annotations?: Record<string, unknown>;
  name: string;
  description: string;
  inputSchema: JSONSchema;
}

export interface McpServerRef {
  id: string;
  name: string;
  transport: "stdio" | "sse" | "http";
  command?: string;
  args?: string[];
  url?: string;
  env?: Record<string, string>;
  /** Optional catalog this server was discovered from. */
  catalog?: string;
}

export type Severity = "info" | "low" | "medium" | "high" | "critical";

export interface WardenFinding {
  gate: string;
  severity: Severity;
  /** Stable machine code, e.g. "TOOL_DEF_INJECTION". */
  code: string;
  message: string;
  /** Optional tool the finding refers to. */
  tool?: string;
  /**
   * Report-only: this finding NEVER blocks a connection and never costs a tool,
   * at ANY `blockAtSeverity` setting. It is still reported. Whether it affects a
   * gate's score is the gate's decision — the static scanner excludes advisory
   * hits from its score, the pinning gate still rates an unpinned server 0.9.
   *
   * The tier is data, not a consequence of severity, because severity answers
   * "how much attention" and tiering answers "is this a defect at all". A tool
   * whose schema takes an `api_key` is worth pointing at and is not a defect;
   * expressing that by lowering its severity would have made it blocking again
   * for anyone who tightened `blockAtSeverity`.
   */
  advisory?: boolean;
}

export interface WardenVerdict {
  allow: boolean;
  /** 0..1 composite safety score (1 = safe). */
  score: number;
  /** The gate that produced the final decision, if blocked. */
  decidedBy?: string;
  findings: WardenFinding[];
  /** Per-tool decisions when partial allow is in play. */
  allowedTools: string[];
  blockedTools: string[];
  /**
   * Which rule tables produced these findings. A recorded scan is only
   * reproducible together with them: the same server can score differently
   * under a later ruleset, and without the version and digest there is no way
   * to tell that apart from the server having changed.
   */
  rulesets: { staticScan: RulesetRef };
}

/** Identifies an exact rule table: a human version plus a digest of its content. */
export interface RulesetRef {
  /** Monotonic version of the rule table. */
  version: string;
  /** `sha256-<base64>` over the canonical serialization of every rule. */
  digest: string;
}

/** What a gate sees: the server + its advertised tools + accumulating state. */
export interface WardenGateInput {
  server: McpServerRef;
  tools: ToolDef[];
  /** Findings accumulated by earlier gates. */
  prior: WardenFinding[];
  policy: WardenPolicy;
}

export interface WardenGateResult {
  findings: WardenFinding[];
  /** Per-gate score contribution 0..1 (1 = this gate is satisfied). */
  score: number;
  /** If true, short-circuit the chain and block immediately. */
  fatal?: boolean;
}

export interface WardenGate {
  readonly name: string;
  evaluate(input: WardenGateInput): Promise<WardenGateResult>;
}

/** Operator supplied, bound to launch identity and the full reviewed definition snapshot. */
export interface CapabilityBinding {
  serverId: string;
  identityHash: string;
  toolsHash: string;
  tools: Record<string, Array<'private' | 'untrusted' | 'outbound'>>;
}

export interface WardenPolicy {
  capabilityBindings?: CapabilityBinding[];
  /** Block the whole connection if any finding >= this severity. */
  blockAtSeverity: Severity;
  /** Tool names that always require explicit user approval before running. */
  sensitiveToolPatterns: string[];
  /**
   * Allow connecting to servers the operator never declared — that is, servers
   * the host discovered from a remote catalog, which carry
   * `McpServerRef.catalog`. `false` is fail-closed: only servers the operator
   * listed explicitly may connect.
   *
   * This knob used to mean "has no reputation score yet", which no deployment
   * could satisfy: nothing ever passed trust edges to the reputation oracle, so
   * every server came back unvouched and `false` blocked all of them. Catalog
   * provenance is a fact the host actually holds locally, needs no network, and
   * cannot deadlock — a declared server is always known.
   */
  allowUnknownServers: boolean;
  /** Re-approval required if a server's tool defs change after pinning. */
  pinToolDefs: boolean;
  /** Admit only an explicitly approved v2 snapshot. Automatic/legacy pins do not count. */
  requireApproval?: boolean;
}

/** A pinned snapshot of a server's tools, used for drift detection. */
export interface PinnedServer {
  serverId: string;
  /** sha256 over the canonical tool-def set. */
  toolsHash: string;
  /** v2 includes all advertised fields; plain three-field definitions retain their digest. */
  toolsHashVersion?: number;
  approvedAt: string;
  /** Missing on legacy pins. TOFU is deliberately distinguishable from operator review. */
  approvalMode?: "operator" | "automatic";
  toolNames: string[];
  /** Definitions retained for operator review; do not supply live credentials. */
  tools?: ToolDef[];
  /**
   * sha256 over the server's launch identity — transport, command, args, url,
   * name — as it stood when the user approved it.
   *
   * Tool-def pinning catches a server that changes what it advertises. It does
   * not catch a server that keeps the advertisement and changes the program
   * behind it: same id, same tools, different `command`. For an operator-declared
   * server that is a local config edit and not much of a threat. For a server
   * discovered from a remote **catalog** it is one, because the catalog decides
   * the command and can repoint an already-approved id at a new one.
   *
   * Optional because pins written before this field existed do not have it, and a
   * missing value must not be read as a change. Re-approving fills it in.
   */
  identityHash?: string;
  /**
   * What the server said about itself in its initialize result when the operator approved it (`serverInfo`), as the
   * client passed it. The server's own word: shown next to a review so a reviewer can see a version change, never
   * hashed or trusted.
   */
  serverInfo?: { name?: string; version?: string };
}

/**
 * Where approvals are remembered between runs — the only persistence WARDEN
 * needs. Narrow on purpose: any store with these two methods works, including a
 * Map for tests. Without durable pins, drift detection degrades to "every
 * server is seen for the first time, every time".
 */
export interface PinStore {
  getPin(serverId: string): Promise<PinnedServer | undefined>;
  putPin(p: PinnedServer): Promise<void>;
}

/**
 * Which surface a threat pattern is meaningful against:
 * - `server` — the server's identity/config only (id, name, url, command, args).
 * - `tool` — the advertised tool definitions only (name, description, inputSchema).
 * - `any` — both. This is the default when a record omits `scope`.
 */
export type ThreatScope = "server" | "tool" | "any";

/** A signed threat-intel record about a known-bad server/tool. */
export interface ThreatRecord {
  /** Pattern matched against server identity and/or tool definitions per `scope`. */
  pattern: string;
  severity: Severity;
  code: string;
  reason: string;
  source: string;
  /** Match surface; defaults to `"any"` when absent. */
  scope?: ThreatScope;
}

export type LogLevel = "debug" | "info" | "warn" | "error";

/**
 * Where WARDEN writes. Structurally identical to most host loggers, so an
 * existing one usually satisfies it as-is; `silentLogger()` is provided for
 * hosts that have none.
 */
export interface WardenLogger {
  debug(msg: string, ...a: unknown[]): void;
  info(msg: string, ...a: unknown[]): void;
  warn(msg: string, ...a: unknown[]): void;
  error(msg: string, ...a: unknown[]): void;
  child(scope: string): WardenLogger;
}
