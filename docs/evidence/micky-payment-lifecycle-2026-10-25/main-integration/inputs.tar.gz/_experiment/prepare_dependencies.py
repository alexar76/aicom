
from collections import defaultdict
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import tomllib
from pip._vendor.packaging.markers import Marker

assert sys.version_info[:2] == (3, 11), sys.version
assert platform.system() == 'Linux'
lock = tomllib.loads(Path('/work/uv.lock').read_text())
packages = defaultdict(list)
for package in lock['package']:
    packages[package['name']].append(package)
root = [p for p in packages['aimarket-hub'] if p.get('source', {}).get('editable') == '.']
assert len(root) == 1
root = root[0]
pending = list(root.get('dependencies', [])) + [
    {'name': 'pytest'}, {'name': 'pytest-asyncio'}, {'name': 'pytest-httpx'},
]
selected = {}
active_extras = defaultdict(set)
walked = {}

def applies(edge, extras):
    marker = edge.get('marker')
    return not marker or any(Marker(marker).evaluate({'extra': extra}) for extra in {'', *extras})

while pending:
    edge = pending.pop()
    name = edge['name']
    assert name != 'aimarket-hub', 'Never install a second Hub over current source'
    choices = packages[name]
    if edge.get('version'):
        choices = [p for p in choices if p['version'] == edge['version']]
    assert len(choices) == 1, (name, [p['version'] for p in choices])
    package = choices[0]
    assert package.get('source', {}).get('registry') == 'https://pypi.org/simple', package['source']
    active_extras[name].update(edge.get('extra', []))
    selected[name] = package
    extras = frozenset(active_extras[name])
    if name in walked and walked[name] == extras:
        continue
    walked[name] = extras
    dependencies = list(package.get('dependencies', []))
    for extra in extras:
        dependencies.extend(package.get('optional-dependencies', {}).get(extra, []))
    pending.extend(d for d in dependencies if applies(d, extras))

lines = []
resolved = []
for name, package in sorted(selected.items()):
    assert re.fullmatch(r'[A-Za-z0-9_.-]+', name)
    assert re.fullmatch(r'[A-Za-z0-9_.+!-]+', package['version'])
    hashes = sorted({wheel['hash'] for wheel in package.get('wheels', [])})
    assert hashes, (name, 'No wheel hash in lockfile; refusing an sdist build')
    assert all(re.fullmatch(r'sha256:[0-9a-f]{64}', value) for value in hashes)
    lines.append(name + '==' + package['version'] + ' ' + ' '.join('--hash=' + value for value in hashes))
    resolved.append({'name': name, 'version': package['version'],
                     'active_extras': sorted(active_extras[name]), 'wheel_hashes': hashes})
Path('/out/requirements.lock.txt').write_text('\n'.join(lines) + '\n')
Path('/out/dependency-selection.json').write_text(json.dumps({
    'source': '/work/uv.lock', 'root': 'aimarket-hub runtime plus dev test dependencies',
    'root_source_version_string': root['version'], 'installed_current_hub': False,
    'python': sys.version, 'platform': platform.platform(),
    'packages': resolved,
}, indent=2) + '\n')
subprocess.run([
    sys.executable, '-m', 'pip', '--isolated', '--disable-pip-version-check', 'install',
    '--index-url', 'https://pypi.org/simple', '--only-binary=:all:', '--no-deps',
    '--require-hashes', '--no-cache-dir', '--target', '/deps', '-r', '/out/requirements.lock.txt',
], check=True)
print(json.dumps({'selected_packages': len(resolved), 'status': 'installed_locked_wheels'}))
