
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
installed = sorted(({'name': d.metadata['Name'], 'version': d.version}
                    for d in importlib.metadata.distributions(path=['/deps'])), key=lambda p: p['name'].lower())
freeze = subprocess.check_output([sys.executable, '-m', 'pip', '--isolated',
                                  '--disable-pip-version-check', 'freeze', '--path', '/deps'], text=True)
Path('/out/pip-freeze.txt').write_text(freeze)
Path('/out/runtime.json').write_text(json.dumps({
    'python': sys.version, 'platform': platform.platform(), 'sqlite': sqlite3.sqlite_version,
    'dependency_packages': installed, 'hub_source_sha256': {
        str(p.relative_to('/work')): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(Path('/work/aimarket_hub').rglob('*.py'))},
    'current_source_not_published_wheel': True,
}, indent=2) + '\n')
