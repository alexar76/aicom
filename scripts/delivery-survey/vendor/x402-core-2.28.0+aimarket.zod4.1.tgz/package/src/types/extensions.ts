import type { VerifyResponse, SettleResponse } from "./facilitator";
import type {
  PaymentRequiredContext,
  SettleResultContext,
  VerifyContext,
  VerifyResultContext,
  VerifyFailureContext,
  SettleContext,
  SettleFailureContext,
  VerifiedPaymentCanceledContext,
  SkipHandlerDirective,
} from "../server/x402ResourceServer";
import type { ResourceServerTransportExtensionHooks } from "../http/x402HTTPResourceServer";
export type {
  HTTPResourceServerExtensionHooks,
  ResourceServerTransportExtensionHooks,
} from "../http/x402HTTPResourceServer";

export type {
  PaymentRequiredContext,
  SettleResultContext,
  VerifyContext,
  VerifyResultContext,
  VerifyFailureContext,
  SettleContext,
  SettleFailureContext,
  VerifiedPaymentCanceledContext,
};

export interface FacilitatorExtension {
  key: string;
}

/**
 * Per-extension verify/settle hooks. Contexts are **read-only** for core protocol fields; use
 * **abort** / **recover** return values instead of mutating `paymentPayload`, `requirements`, etc.
 */
export interface ResourceServerExtensionHooks {
  onBeforeVerify?: (
    declaration: unknown,
    context: VerifyContext,
  ) => Promise<
    | void
    | { abort: true; reason: string; message?: string }
    | { skip: true; result: VerifyResponse }
  >;
  onAfterVerify?: (
    declaration: unknown,
    context: VerifyResultContext,
  ) => Promise<
    | void
    | { skipHandler: true; response?: SkipHandlerDirective }
    | { abort: true; reason: string; message?: string }
  >;
  onVerifyFailure?: (
    declaration: unknown,
    context: VerifyFailureContext,
  ) => Promise<void | { recovered: true; result: VerifyResponse }>;
  onBeforeSettle?: (
    declaration: unknown,
    context: SettleContext,
  ) => Promise<
    | void
    | { abort: true; reason: string; message?: string }
    | { skip: true; result: SettleResponse }
  >;
  onAfterSettle?: (declaration: unknown, context: SettleResultContext) => Promise<void>;
  onSettleFailure?: (
    declaration: unknown,
    context: SettleFailureContext,
  ) => Promise<void | { recovered: true; result: SettleResponse }>;
  onVerifiedPaymentCanceled?: (
    declaration: unknown,
    context: VerifiedPaymentCanceledContext,
  ) => Promise<void>;
}

export interface ResourceServerExtension {
  key: string;
  /**
   * Names of fields under the extension's `info` that are dynamic - regenerated
   * on every PaymentRequired response (e.g. nonces, timestamps) - rather than
   * static committed terms. Dynamic fields are excluded from client echo
   * validation. Defaults to none (all info fields treated as static / strict).
   */
  dynamicInfoFields?: string[];
  enrichDeclaration?: (declaration: unknown, transportContext: unknown) => unknown;
  /**
   * Return value merges into `extensions[key]`. In-place edits to `accepts` are allowlisted only
   * (see server `assertAcceptsAllowlistedAfterExtensionEnrich`): vacant `payTo` / `amount` / `asset`
   * may be filled; locked values and `scheme` / `network` / `maxTimeoutSeconds` / baseline `extra`
   * entries are immutable. `extra.paymentFlow` and `extra.assetTransferMethod` are
   * protocol-reserved and must not be added or changed during enrichment.
   */
  enrichPaymentRequiredResponse?: (
    declaration: unknown,
    context: PaymentRequiredContext,
  ) => Promise<unknown>;
  /**
   * Return value merges into `settleResult.extensions[key]`. Facilitator fields (`success`,
   * `transaction`, `network`, etc.) must not be changed; only `extensions` is merged from the hook.
   */
  enrichSettlementResponse?: (
    declaration: unknown,
    context: SettleResultContext,
  ) => Promise<unknown>;
  /** Installed on `registerExtension`; runs only when `declaredExtensions[key]` is defined. */
  hooks?: ResourceServerExtensionHooks;
  /** Transport-specific hooks scoped to declared extension keys. */
  transportHooks?: ResourceServerTransportExtensionHooks;
}
