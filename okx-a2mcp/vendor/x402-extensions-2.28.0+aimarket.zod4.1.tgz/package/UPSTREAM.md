# Local Zod migration

Original: @x402/extensions@2.28.0

Registry integrity: sha512-M3SVxO8DJnx7gpok/ODQp803jr21s1XrCMholNw0hSgOVvSPRksfTZ+CUNfJwteNaHmaAxGjPelXWBhTCMD9oQ==

Repository: https://github.com/x402-foundation/x402

Every original runtime and source-map byte is retained. Package metadata migrates the compatible Zod APIs to Zod 4.6.7 and adds the transparent local version suffix. The extensions SIWx schema declarations are regenerated for Zod 4 in both ESM/CJS formats; the matching runtime schema is unchanged. Build-time development dependencies/scripts are omitted from this runtime archive. Apache-2.0 license retained. Rebuild with security/vendor/build.mjs and verify with --check.
